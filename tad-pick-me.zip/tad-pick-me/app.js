/* =========================================================
 * Data (loaded from employees.json)
 * Shape: { departments: [{ name, members: [{id,name,position,div,inPool}] }], makers: [{id,name,position}] }
 * ========================================================= */
const MAKER_POSITIONS = new Set(['協理', '專案協理', '專案經理']);
const TOP_TIER_POSITIONS = new Set(['經理']);
const MID_TIER_POSITIONS = new Set(['資深副理', '副理', '襄理']);
const BASE_TIER_POSITIONS = new Set(['高級專員', '中級專員']);

let DATA = { departments: [], makers: [] };

// Shorten DIV_FULL_NAME for display, e.g. "科技應用發展部應用設計科" -> "應用設計科"
function shortDeptName(full) {
  if (!full) return '其他';
  const m = full.match(/([^部]+科)$/);
  if (m) return m[1];
  // If it's "科技應用發展部" itself (no sub-dept), label as 部室
  return full;
}

async function loadData() {
  const response = await fetch('./employees.json');
  const list = await response.json();

  const deptMap = new Map(); // short name -> {name, members:[]}
  const makers = [];
  list.forEach(raw => {
    const e = {
      id: raw.EMP_ID,
      name: raw.EMP_NAME,
      position: raw.POSITION_NAME,
      div: raw.DIV_FULL_NAME
    };
    if (MAKER_POSITIONS.has(e.position)) {
      makers.push(e);
      return; // excluded from pool
    }
    const shortName = shortDeptName(e.div);
    if (!deptMap.has(shortName)) deptMap.set(shortName, { name: shortName, fullName: e.div, members: [] });
    deptMap.get(shortName).members.push(e);
  });

  // Keep only dept groups that have members
  const departments = Array.from(deptMap.values()).filter(d => d.members.length > 0);
  DATA = { departments, makers };
}

/* =========================================================
 * Utils
 * ========================================================= */
const $ = id => document.getElementById(id);
const rand = (min, max) => Math.random() * (max - min) + min;
const randInt = (min, max) => Math.floor(rand(min, max + 1));
const pickN = (arr, n) => {
  const copy = arr.slice();
  const out = [];
  n = Math.min(n, copy.length);
  for (let i = 0; i < n; i++) {
    const idx = randInt(0, copy.length - 1);
    out.push(copy.splice(idx, 1)[0]);
  }
  return out;
};
const allMembers = () => DATA.departments.flatMap(d => d.members.map(m => ({...m, dept: d.name})));
const allTickerEntries = () => [
  ...DATA.makers.map(m => ({ ...m, maker: true })),
  ...allMembers().map(m => ({ ...m, maker: false }))
];
// Build price map for both makers (for ticker) and pool members
function getAllForPrices() {
  return [...DATA.makers, ...allMembers()];
}
const fmtPrice = p => p.toFixed(2);
const fmtPct = p => (p >= 0 ? '+' : '') + p.toFixed(2) + '%';
const pad2 = n => n.toString().padStart(2, '0');

/* =========================================================
 * Clock + ticker
 * ========================================================= */
function startClock() {
  const tick = () => {
    const d = new Date();
    $('clock').textContent = `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
  };
  tick();
  setInterval(tick, 1000);
}

// each member gets a consistent synthetic base price (also makers, for ticker)
function generateBasePrices() {
  const out = {};
  getAllForPrices().forEach(m => {
    const seed = parseInt(m.id, 10) || 100;
    const base = 30 + ((seed * 37) % 400); // 30~430
    const change = ((seed * 13) % 200 - 100) / 10; // -10%~+10%
    out[m.id] = {
      base: base + Math.random() * 2,
      change: change + (Math.random() * 2 - 1)
    };
  });
  return out;
}
let PRICES = {};

function renderTicker() {
  const track = $('tickerTrack');
  const entries = allTickerEntries();
  const items = entries.map(m => {
    if (m.maker) {
      // 作手 special badge
      return `<span class="ticker-item ticker-maker">📌 作手 ${m.id} ${m.name}（${m.position}）</span>`;
    }
    const p = PRICES[m.id];
    if (!p) return '';
    const price = p.base;
    const pct = p.change;
    const up = pct >= 0;
    const arrow = up ? '▲' : '▼';
    const cls = up ? 'ticker-up' : 'ticker-down';
    return `<span class="ticker-item">${m.id} ${m.name} <span class="${cls}">${arrow}${fmtPrice(price)} ${fmtPct(pct)}</span></span>`;
  });
  // duplicate to ensure scroll coverage
  track.innerHTML = items.join('') + items.join('');
}

function renderTickerWinnersOnly(winners) {
  const track = $('tickerTrack');
  const items = winners.map(w => {
    return `<span class="ticker-item">🏆 ${w.id} ${w.name} <span class="ticker-up">▲${fmtPrice(w.finalPrice)} +10.00%</span> 漲停鎖死</span>`;
  });
  // repeat many times
  const all = [];
  for (let i = 0; i < 6; i++) all.push(...items);
  track.innerHTML = all.join('');
}

/* =========================================================
 * Page 1 render
 * ========================================================= */
function mkSparkline(seed) {
  // Simple mini sparkline svg
  const pts = [];
  let v = 10 + (seed % 5);
  for (let i = 0; i < 20; i++) {
    v += Math.sin(i + seed) * 1.2 + (Math.random() - 0.5);
    pts.push(v);
  }
  const min = Math.min(...pts), max = Math.max(...pts);
  const w = 100, h = 22;
  const coords = pts.map((p, i) => {
    const x = (i / (pts.length - 1)) * w;
    const y = h - ((p - min) / (max - min || 1)) * h;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const up = pts[pts.length - 1] > pts[0];
  const color = up ? '#E8313A' : '#1DB897';
  return `<svg class="kline" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
    <polyline points="${coords}" fill="none" stroke="${color}" stroke-width="1.2" stroke-linejoin="round"/>
  </svg>`;
}

function renderPage1() {
  // Order time
  const now = new Date();
  $('orderTime').textContent = `${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(now.getSeconds())}`;

  // Total count
  const all = allMembers();
  $('totalCount').textContent = `共 ${all.length} 檔 · 作手 ${DATA.makers.length} 名`;

  // Member list — dept tabs
  const ml = $('memberList');
  const tabsHtml = DATA.departments.map((d, i) =>
    `<button class="member-dept-tab${i===0?' active':''}" onclick="switchMemberTab(${i})">${d.name.replace(/科$/, '')}</button>`
  ).join('');
  const panesHtml = DATA.departments.map((d, i) => {
    const rows = d.members.map(m => {
      const p = PRICES[m.id];
      const up = p.change >= 0;
      const cls = up ? 'up-color' : 'down-color';
      const arrow = up ? '▲' : '▼';
      return `<div class="member-row">
        <div><span class="member-id">${m.id}</span>${m.name}<span style="color:var(--text2);font-size:11px;margin-left:6px;">${m.position}</span></div>
        <div class="member-price ${cls}" style="padding:2px 6px;border-radius:4px;">${arrow}${fmtPrice(p.base)}</div>
      </div>`;
    }).join('');
    return `<div class="member-dept-pane${i===0?' show':''}" id="memberPane${i}">${rows}</div>`;
  }).join('');
  ml.innerHTML = `<div class="member-dept-tabs">${tabsHtml}</div>${panesHtml}`;

  // Dept qty blocks — two modes
  const totalMembers = all.length;
  const blocks = $('deptQtyBlocks');
  blocks.innerHTML = `
    <div class="mode-toggle">
      <button class="mode-tab active" id="modeTabGlobal" onclick="switchMode('global')">🌐 全部統一抽</button>
      <button class="mode-tab" id="modeTabDept" onclick="switchMode('dept')">📂 依科別設定</button>
    </div>

    <!-- Global mode -->
    <div class="mode-panel show" id="modePanelGlobal">
      <div class="global-pool-block">
        <div>
          <div class="global-pool-title">科技應用發展部</div>
          <div class="global-pool-sub">全體商品池 ${totalMembers} 檔，不分科別隨機抽選</div>
        </div>
        <input class="qty-input" type="number" min="1" max="${totalMembers}" value="1" id="globalQtyInput">
      </div>
    </div>

    <!-- Per-dept mode -->
    <div class="mode-panel" id="modePanelDept">
      ${DATA.departments.map((d, i) => `
        <div class="dept-block">
          <div>
            <div class="dept-name">${d.name}</div>
            <div class="dept-count">商品池 ${d.members.length} 檔</div>
          </div>
          <input class="qty-input" type="number" min="0" max="${d.members.length}" value="1" data-dept="${i}">
        </div>
      `).join('')}
    </div>
  `;
}

// current mode
let DRAW_MODE = 'global'; // 'global' | 'dept'

function switchMode(mode) {
  DRAW_MODE = mode;
  $('modeTabGlobal').classList.toggle('active', mode === 'global');
  $('modeTabDept').classList.toggle('active', mode === 'dept');
  $('modePanelGlobal').classList.toggle('show', mode === 'global');
  $('modePanelDept').classList.toggle('show', mode === 'dept');
}

function switchMemberTab(idx) {
  document.querySelectorAll('.member-dept-tab').forEach((t, i) => t.classList.toggle('active', i === idx));
  document.querySelectorAll('.member-dept-pane').forEach((p, i) => p.classList.toggle('show', i === idx));
}

/* =========================================================
 * Submit / result resolution
 * ========================================================= */
let RESULT = null; // { byDept: [{deptName, winners: [{id,name,finalPrice,volume,high}]}], allWinners: [...] }
let PENDING_QTY = {}; // captured at submit time: { mode, globalN? } | { mode, deptQtys? }
let BAOPAN = null;    // { group: 'top'|'mid'|'base', weight: number, positions: Set<string>, label: string }

// Returns { mode: 'global'|'dept', globalN?: number, deptQtys?: number[] }
function captureQty() {
  if (DRAW_MODE === 'global') {
    const input = $('globalQtyInput');
    const all = allMembers();
    let n = parseInt(input ? input.value : '1', 10) || 1;
    n = Math.max(1, Math.min(all.length, n));
    return { mode: 'global', globalN: n };
  } else {
    const deptQtys = DATA.departments.map((d, i) => {
      const input = document.querySelector(`.qty-input[data-dept="${i}"]`);
      let n = parseInt(input ? input.value : '1', 10) || 0;
      n = Math.max(0, Math.min(d.members.length, n));
      return n;
    });
    return { mode: 'dept', deptQtys };
  }
}

// weighted sampling without replacement
function weightedPickN(members, n, weights) {
  // weights: Map<id, number>, default 1.0
  const pool = members.map(m => ({
    m,
    w: Math.max(0.0001, weights.get(m.id) || 1.0)
  }));
  const out = [];
  n = Math.min(n, pool.length);
  for (let k = 0; k < n; k++) {
    const total = pool.reduce((s, x) => s + x.w, 0);
    let r = Math.random() * total;
    let pickedIdx = 0;
    for (let i = 0; i < pool.length; i++) {
      r -= pool[i].w;
      if (r <= 0) { pickedIdx = i; break; }
    }
    out.push(pool[pickedIdx].m);
    pool.splice(pickedIdx, 1);
  }
  return out;
}

function resolveResult() {
  const allWinners = [];
  // Build weights map from BaoPan selection
  const weights = new Map();
  if (BAOPAN) {
    allMembers().forEach(m => {
      if (BAOPAN.positions.has(m.position)) weights.set(m.id, BAOPAN.weight);
    });
  }

  const toWinner = (w, deptName) => {
    const base = PRICES[w.id].base;
    const finalPrice = base * 1.10;
    return { id: w.id, name: w.name, position: w.position, base, finalPrice,
             volume: randInt(8000, 99000), high: finalPrice, dept: deptName };
  };

  if (PENDING_QTY.mode === 'global') {
    const n = PENDING_QTY.globalN;
    const pool = allMembers(); // all dept members flattened
    const picked = weightedPickN(pool, n, weights).map(w => toWinner(w, w.dept));
    allWinners.push(...picked);
    // group by dept for display
    const byDeptMap = new Map();
    picked.forEach(w => {
      if (!byDeptMap.has(w.dept)) byDeptMap.set(w.dept, []);
      byDeptMap.get(w.dept).push(w);
    });
    const byDept = DATA.departments
      .map(d => ({ deptName: d.name, winners: byDeptMap.get(d.name) || [] }))
      .filter(g => g.winners.length > 0);
    return { byDept, allWinners };
  } else {
    const byDept = [];
    DATA.departments.forEach((d, i) => {
      const n = PENDING_QTY.deptQtys[i] || 0;
      if (n === 0) return;
      const winners = weightedPickN(d.members, n, weights).map(w => toWinner(w, d.name));
      byDept.push({ deptName: d.name, winners });
      allWinners.push(...winners);
    });
    return { byDept, allWinners };
  }
}

/* =========================================================
 * Page 2 : Trading animation
 * ========================================================= */
let tradingInterval = null;
let timerInterval = null;   // hoisted so togglePause can clear it
let timerT = 300;           // shared timer value
let animating = false;
const cardRefs = new Map();

let activeDeptIdx = 0;

function renderPage2() {
  activeDeptIdx = 0;

  // Build dept tab bar
  const tabsBar = $('deptTabsBar');
  tabsBar.innerHTML = DATA.departments.map((d, i) =>
    `<button class="dept-tab${i===0?' active':''}" id="deptTab${i}" onclick="switchDeptTab(${i})">${d.name} <span style="opacity:0.7;font-weight:400;">${d.members.length}</span></button>`
  ).join('');

  // Build per-dept panels
  const container = $('tradingStocks');
  container.innerHTML = DATA.departments.map((d, i) => {
    const cards = d.members.map(m => {
      const seed = parseInt(m.id, 10) || 1;
      const p = PRICES[m.id];
      const up = p.change >= 0;
      return `<div class="stock-card shake" data-id="${m.id}" data-dept="${d.name}" data-position="${m.position}">
        <div class="stock-name-row">
          <div>
            <div class="stock-id">${m.id} · ${m.position}</div>
            <div class="stock-name">${m.name}</div>
          </div>
          <div class="stock-arrow ${up?'up-color':'down-color'}" data-role="arrow">${up?'▲':'▼'}</div>
        </div>
        <div class="stock-price ${up?'up-color':'down-color'}" data-role="price">${fmtPrice(p.base)}</div>
        <div class="stock-change ${up?'up-color':'down-color'}" data-role="change">${fmtPct(p.change)}</div>
        <div class="stock-volume">
          <span>量 <span data-role="vol">${randInt(50,999)}</span></span>
          <span data-role="bid">委買 ${randInt(10,99)}</span>
        </div>
        ${mkSparkline(seed)}
      </div>`;
    }).join('');
    return `<div class="dept-panel${i===0?' active':''}" id="deptPanel${i}">
      <div class="dept-section">
        <h3><span class="dept-tag">${d.name}</span><span style="font-size:12px;color:var(--text2);font-weight:400;">${d.members.length} 檔</span></h3>
        <div class="stock-grid">${cards}</div>
      </div>
    </div>`;
  }).join('');

  cardRefs.clear();
  container.querySelectorAll('.stock-card').forEach(card => {
    const id = card.dataset.id;
    cardRefs.set(id, {
      card,
      price: card.querySelector('[data-role=price]'),
      change: card.querySelector('[data-role=change]'),
      arrow: card.querySelector('[data-role=arrow]'),
      vol: card.querySelector('[data-role=vol]'),
      bid: card.querySelector('[data-role=bid]'),
      hotCount: 0,
      basePrice: PRICES[id].base
    });
    card.addEventListener('click', () => openStockModal(id));
  });
}

function switchDeptTab(idx) {
  activeDeptIdx = idx;
  document.querySelectorAll('.dept-tab').forEach((t, i) => t.classList.toggle('active', i === idx));
  document.querySelectorAll('.dept-panel').forEach((p, i) => p.classList.toggle('active', i === idx));
}

// After winners revealed, highlight tabs that have winners
function markWinnerTabs() {
  const winnerIds = new Set(RESULT.allWinners.map(w => w.id));
  DATA.departments.forEach((d, i) => {
    const hasWinner = d.members.some(m => winnerIds.has(m.id));
    const tab = $(`deptTab${i}`);
    if (tab && hasWinner) tab.classList.add('has-winner');
  });
}

function onCardClick(id) {
  if (!animating) return;
  const ref = cardRefs.get(id);
  if (!ref) return;
  ref.hotCount++;
  // bump animation
  ref.card.classList.remove('bump');
  void ref.card.offsetWidth;
  ref.card.classList.add('bump');

  // volume surge
  const curVol = parseInt(ref.vol.textContent, 10) || 0;
  ref.vol.textContent = curVol + randInt(50, 200);

  // bid badge
  const badge = document.createElement('div');
  badge.className = 'bid-badge';
  badge.textContent = '+委買';
  ref.card.appendChild(badge);
  setTimeout(() => badge.remove(), 800);

  if (ref.hotCount >= 3) ref.card.classList.add('hot');
}

function tickPrices() {
  cardRefs.forEach((ref, id) => {
    const delta = (Math.random() - 0.5) * 2; // -1~+1
    const newPrice = Math.max(1, ref.basePrice + delta * 3);
    const pct = ((newPrice - ref.basePrice) / ref.basePrice) * 100 + (Math.random() - 0.5) * 8;
    const up = pct >= 0;
    ref.price.textContent = fmtPrice(newPrice);
    ref.price.className = `stock-price ${up?'up-color':'down-color'}`;
    ref.change.textContent = fmtPct(pct);
    ref.change.className = `stock-change ${up?'up-color':'down-color'}`;
    ref.arrow.textContent = up ? '▲' : '▼';
    ref.arrow.className = `stock-arrow ${up?'up-color':'down-color'}`;
  });
}

/* =========================================================
 * Bell sound via Web Audio API
 * ========================================================= */
let audioCtx = null;
function getAudio() {
  if (!audioCtx) {
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) { return null; }
  }
  return audioCtx;
}
function playBell() {
  const ctx = getAudio();
  if (!ctx) return;
  const now = ctx.currentTime;
  // main bell tone (A5 ~ 880Hz) with harmonics
  const freqs = [880, 1320, 1760];
  const gains = [0.35, 0.15, 0.08];
  freqs.forEach((f, i) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(f, now);
    osc.frequency.exponentialRampToValueAtTime(f * 0.98, now + 1.5);
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(gains[i], now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 2);
  });
}
function playClick() {
  const ctx = getAudio();
  if (!ctx) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(1200, now);
  g.gain.setValueAtTime(0.15, now);
  g.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
  osc.connect(g); g.connect(ctx.destination);
  osc.start(now); osc.stop(now + 0.1);
}

/* =========================================================
 * Particles
 * ========================================================= */
function spawnParticles(cardEl) {
  const rect = cardEl.getBoundingClientRect();
  const colors = ['#ffd700', '#ffae00', '#ff6b72', '#fff176', '#ffffff'];
  for (let i = 0; i < 20; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.background = colors[i % colors.length];
    p.style.left = (rect.left + rect.width / 2) + 'px';
    p.style.top = (rect.top + rect.height / 2) + 'px';
    p.style.position = 'fixed';
    p.style.zIndex = 9999;
    p.style.boxShadow = '0 0 8px currentColor';
    document.body.appendChild(p);
    const angle = (Math.PI * 2 * i) / 20 + Math.random() * 0.5;
    const dist = rand(80, 180);
    const dx = Math.cos(angle) * dist;
    const dy = Math.sin(angle) * dist;
    p.animate([
      { transform: 'translate(0,0) scale(1)', opacity: 1 },
      { transform: `translate(${dx}px,${dy}px) scale(0.2)`, opacity: 0 }
    ], { duration: 1200 + Math.random() * 400, easing: 'cubic-bezier(0.2,0.6,0.3,1)' }).onfinish = () => p.remove();
  }
}

/* =========================================================
 * Flow
 * ========================================================= */
function showPage(n) {
  [1,2,3].forEach(i => $(`page${i}`).classList.toggle('active', i === n));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showModal(title, body, cb) {
  $('modalTitle').textContent = title;
  $('modalBody').textContent = body;
  $('modal').classList.add('show');
  $('modalBtn').onclick = () => {
    $('modal').classList.remove('show');
    cb && cb();
  };
}

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// sleep that pauses when IS_PAUSED is true — only counts elapsed time when not paused
async function sleepPausable(ms) {
  let elapsed = 0;
  let last = Date.now();
  while (elapsed < ms) {
    await sleep(100);
    const now = Date.now();
    if (!IS_PAUSED) {
      elapsed += now - last;
    }
    last = now;
  }
}

async function runTradingAnimation() {
  animating = true;
  IS_PAUSED = false;
  $('ticker').classList.add('fast');
  $('newsTicker').classList.add('show');
  startNewsTicker();
  startFeedLoop();
  enableBaopanPanel();
  $('stageText').textContent = '盤中撮合中 · 委買委賣撮合';

  // timer countdown style — uses module-level timerInterval so togglePause can stop it
  timerT = 300;
  const timerEl = $('tradingTimer');
  function startTimerTick() {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      timerT = Math.max(0, timerT - 1);
      timerEl.textContent = `${pad2(Math.floor(timerT/60))}:${pad2(timerT%60)}`;
    }, 1000);
  }
  startTimerTick();

  // price tick loop
  tradingInterval = setInterval(tickPrices, 200);

  // wait ~3s then warning
  await sleepPausable(3000);

  await new Promise(resolve => {
    showModal(
      '⚠️ 交易異常警示',
      '偵測到多檔個股出現異常委買量，主管機關即時介入監控中，請靜待系統結算...',
      resolve
    );
  });

  // continue 3-5s
  $('stageText').textContent = '主管機關監控中 · 準備收盤';
  await sleepPausable(rand(3000, 5000));

  // === Resolve result NOW (護盤期結束, 加權已定) ===
  RESULT = resolveResult();

  // Lock-in: fade losers, reveal winners
  clearInterval(timerInterval); timerInterval = null;
  timerEl.textContent = '13:30';
  $('stageText').textContent = '🔒 收盤鎖定中...';
  closeStockModal();
  disableBaopanPanel();
  // Disable pause during lock-in
  IS_PAUSED = false;
  const pauseBtn = $('pauseBtn');
  if (pauseBtn) { pauseBtn.disabled = true; pauseBtn.textContent = '⏸ 暫停'; pauseBtn.classList.remove('paused'); }
  $('pausedOverlay').classList.remove('show');
  markWinnerTabs();

  const winnerIds = new Set(RESULT.allWinners.map(w => w.id));
  const loserRefs = [];
  cardRefs.forEach((ref, id) => {
    if (!winnerIds.has(id)) loserRefs.push(ref);
    else ref.card.classList.remove('shake');
  });

  // fade losers in batches
  // shuffle order
  loserRefs.sort(() => Math.random() - 0.5);
  const batchSize = Math.max(3, Math.ceil(loserRefs.length / 12));
  for (let i = 0; i < loserRefs.length; i += batchSize) {
    for (let j = i; j < Math.min(i + batchSize, loserRefs.length); j++) {
      loserRefs[j].card.classList.add('fade-out');
    }
    await sleep(180);
  }

  await sleep(300);

  // reveal winners
  clearInterval(tradingInterval);
  $('stageText').textContent = '🏁 收盤結算完成';
  playBell();

  RESULT.allWinners.forEach((w, i) => {
    const ref = cardRefs.get(w.id);
    if (!ref) return;
    setTimeout(() => {
      ref.card.classList.add('winner');
      ref.price.textContent = fmtPrice(w.finalPrice);
      ref.price.className = 'stock-price up-color';
      ref.change.textContent = '+10.00%';
      ref.change.className = 'stock-change up-color';
      ref.arrow.textContent = '▲';
      ref.arrow.className = 'stock-arrow up-color';

      const tag = document.createElement('div');
      tag.className = 'limit-up-tag';
      tag.textContent = '漲停 +10%';
      ref.card.appendChild(tag);

      spawnParticles(ref.card);
    }, i * 180);
  });

  await sleep(RESULT.allWinners.length * 180 + 2000);

  // ticker switches to winners only — same speed as page 1 (default 320s)
  renderTickerWinnersOnly(RESULT.allWinners);
  $('ticker').classList.remove('fast');
  $('marketStatus').textContent = '收盤';
  $('marketStatus').style.background = '#fff0f0';
  $('marketStatus').style.color = 'var(--up)';

  await sleep(1500);

  // goto page 3
  stopFeedLoop();
  showPage(3);
  renderPage3();
  animating = false;
}

function renderPage3() {
  const now = new Date();
  $('resultDate').textContent = `${now.getFullYear()}/${pad2(now.getMonth()+1)}/${pad2(now.getDate())} · 收盤時間 13:30`;
  const content = $('resultContent');

  const deptGroups = RESULT.byDept.filter(grp => grp.winners.length > 0);
  const numCols = deptGroups.length || 1;
  // Dynamically set columns so all winning depts are always in one row
  content.style.gridTemplateColumns = `repeat(${numCols}, 1fr)`;

  content.innerHTML = deptGroups.map(grp => {
    const cards = grp.winners.map(w => `
      <div class="result-card">
        <div class="result-member-id">${w.id}${w.position ? ' · ' + w.position : ''}</div>
        <div class="result-member-name">${w.name}</div>
        <div style="font-family:'SF Mono',monospace;font-size:18px;font-weight:800;color:var(--up);">$${fmtPrice(w.finalPrice)}</div>
        <div style="font-size:10px;color:var(--up);font-weight:700;margin-top:1px;">▲ +10.00% 漲停鎖死</div>
        <div style="font-size:10px;color:#d97706;font-weight:700;margin-top:6px;padding:4px 6px;background:#fff9e6;border-radius:5px;text-align:center;">🍱 欽點共進午餐</div>
      </div>
    `).join('');
    return `<div class="result-dept">
      <div class="result-dept-title">
        <span class="dept-tag">${grp.deptName}</span>
        <span style="font-size:11px;color:var(--text2);font-weight:400;">中選 ${grp.winners.length} 檔</span>
      </div>
      <div class="result-cards">${cards}</div>
    </div>`;
  }).join('');
}

function reset() {
  PRICES = generateBasePrices();
  RESULT = null;
  PENDING_QTY = {};
  BAOPAN = null;
  DRAW_MODE = 'global';
  IS_PAUSED = false;
  if (tradingInterval) { clearInterval(tradingInterval); tradingInterval = null; }
  if (timerInterval)   { clearInterval(timerInterval);   timerInterval = null; }
  stopNewsTicker();
  stopFeedLoop();
  const feedEl = $('newsFeed'); if (feedEl) feedEl.innerHTML = '';
  closeStockModal();
  $('newsTicker').classList.remove('show');
  const pauseBtn = $('pauseBtn');
  if (pauseBtn) { pauseBtn.disabled = false; pauseBtn.textContent = '⏸ 暫停'; pauseBtn.classList.remove('paused'); }
  $('pausedOverlay').classList.remove('show');
  resetBaopanPanel();
  $('ticker').classList.remove('fast');
  $('marketStatus').textContent = '盤中即時';
  $('marketStatus').style.background = '';
  $('marketStatus').style.color = '';
  renderTicker();
  renderPage1();
  showPage(1);
}

/* =========================================================
 * News ticker (fake headlines)
 * ========================================================= */
const NEWS_TEMPLATES = [
  { tag: '快訊', cls: 'flash', text: '法人報告指出，{name} 本季表現超出預期，外資持續加碼' },
  { tag: '獨家', cls: 'exclusive', text: '消息人士透露，作手本週將親自宴請旗下潛力股，{name} 呼聲最高' },
  { tag: '警示', cls: 'warn', text: '主管機關對 {name} 發函要求說明近期異常委買量' },
  { tag: '分析', cls: 'analysis', text: '技術面來看，{name} 已突破關鍵壓力區，短線強勢' },
  { tag: '獨家', cls: 'exclusive', text: '{name} 私下透露「還沒準備好」，市場解讀分歧' },
  { tag: '快訊', cls: 'flash', text: '{name} 今日被目擊精神狀態極佳，法人解讀為強烈利多' },
  { tag: '警示', cls: 'warn', text: '{name} 近期出現異常委賣，主力疑似悄悄出場，請留意' },
  { tag: '分析', cls: 'analysis', text: '與會人士指出，{name} 在關鍵時刻表現沉穩，後市看漲' }
];
let newsIdx = 0;
let newsTimer = null;

function nextNews() {
  const pool = allMembers();
  if (!pool.length) return;
  const subject = pool[randInt(0, pool.length - 1)];
  const tpl = NEWS_TEMPLATES[newsIdx % NEWS_TEMPLATES.length];
  newsIdx++;
  const subjectText = `${subject.id} ${subject.name}`;
  const bodyText = tpl.text.replace('{name}', subjectText);
  const track = $('newsTrack');
  track.innerHTML = `
    <span class="news-live-dot"></span>
    <span class="news-brand">CATHAY LIVE</span>
    <span class="news-tag ${tpl.cls}">${tpl.tag}</span>
    <span class="news-text">${bodyText}</span>
  `;
}
function startNewsTicker() {
  stopNewsTicker();
  newsIdx = 0;
  nextNews();
  newsTimer = setInterval(nextNews, 4000);
}
function stopNewsTicker() {
  if (newsTimer) { clearInterval(newsTimer); newsTimer = null; }
}

/* =========================================================
 * Pause / Resume
 * ========================================================= */
let IS_PAUSED = false;

function togglePause() {
  IS_PAUSED = !IS_PAUSED;
  const btn = $('pauseBtn');
  const overlay = $('pausedOverlay');
  const timerEl = $('tradingTimer');
  if (IS_PAUSED) {
    clearInterval(tradingInterval); tradingInterval = null;
    clearInterval(timerInterval);   timerInterval = null;
    stopNewsTicker();
    btn.textContent = '▶ 繼續';
    btn.classList.add('paused');
    overlay.classList.add('show');
  } else {
    tradingInterval = setInterval(tickPrices, 200);
    // restart timer from where it left off
    if (timerEl && timerEl.textContent !== '13:30') {
      timerInterval = setInterval(() => {
        timerT = Math.max(0, timerT - 1);
        timerEl.textContent = `${pad2(Math.floor(timerT/60))}:${pad2(timerT%60)}`;
      }, 1000);
    }
    startNewsTicker();
    btn.textContent = '⏸ 暫停';
    btn.classList.remove('paused');
    overlay.classList.remove('show');
  }
}

/* =========================================================
 * BaoPan (護盤) strip
 * ========================================================= */
// Selector for all baopan buttons (now .baopan-strip-btn)
const baopanBtnSel = '#baopanButtons .baopan-strip-btn';

function enableBaopanPanel() {
  document.querySelectorAll(baopanBtnSel).forEach(b => {
    b.disabled = false;
    b.classList.remove('active');
    b.onclick = () => onBaopanClick(b);
  });
  $('baopanStatus').classList.remove('show');
}
function disableBaopanPanel() {
  document.querySelectorAll(baopanBtnSel).forEach(b => { b.disabled = true; });
}
function resetBaopanPanel() {
  document.querySelectorAll(baopanBtnSel).forEach(b => { b.disabled = true; b.classList.remove('active'); });
  $('baopanStatus').classList.remove('show');
}
// Config per group: background colour, emoji rain, accent colour
const BAOPAN_THEMES = {
  top:  { bg: 'linear-gradient(135deg,#1a237e 0%,#283593 50%,#1565c0 100%)', accent: '#82b1ff', emoji: ['💰','🏦','📈','💎','🔷'], label: '高層護盤' },
  mid:  { bg: 'linear-gradient(135deg,#1b5e20 0%,#2e7d32 50%,#388e3c 100%)', accent: '#b9f6ca', emoji: ['📊','💹','🌿','✅','🟢'], label: '中堅護盤' },
  base: { bg: 'linear-gradient(135deg,#bf360c 0%,#d84315 50%,#e64a19 100%)', accent: '#ffccbc', emoji: ['💼','⚡','🔥','📣','🚀'], label: '基層護盤' },
};

function onBaopanClick(btn) {
  if (BAOPAN) return; // single-shot
  const group = btn.dataset.group;
  const weight = parseFloat(btn.dataset.weight);
  const positions = new Set(btn.dataset.positions.split(','));
  const label = btn.childNodes[0].textContent.trim();
  BAOPAN = { weight, positions, label };

  // Disable all buttons immediately
  document.querySelectorAll(baopanBtnSel).forEach(b => { b.disabled = true; });
  btn.classList.add('active');
  $('baopanStatusText').textContent = `${label}　×${weight.toFixed(2)}`;
  $('baopanStatus').classList.add('show');

  // Screen shake
  document.querySelector('.app').classList.remove('app-shake');
  void document.querySelector('.app').offsetWidth;
  document.querySelector('.app').classList.add('app-shake');

  // Pinned feed message
  const posList = Array.from(positions).join('、');
  appendFeedMessage({
    pinned: true,
    text: `【主力進場】作手資金大舉介入，<b>${posList}</b> 族群全面拉升，市場高度關注 <span style="font-family:'SF Mono',monospace;">×${weight.toFixed(2)}</span>`
  });

  // Launch cinematic overlay
  playBaopanCinema(group, weight);

  // Golden flash on target cards (delayed slightly so cinema runs first)
  setTimeout(() => {
    cardRefs.forEach((ref) => {
      const pos = ref.card.dataset.position;
      if (positions.has(pos)) {
        ref.card.classList.remove('golden-flash');
        void ref.card.offsetWidth;
        ref.card.classList.add('golden-flash');
      }
    });
  }, 300);

  playClick();
}

function playBaopanCinema(group, weight) {
  const theme = BAOPAN_THEMES[group] || BAOPAN_THEMES.base;
  const cinema = $('baopanCinema');
  cinema.style.display = 'flex';

  cinema.innerHTML = `
    <div class="baopan-bg-flash" style="background:${theme.bg};"></div>
    <div class="baopan-scanlines"></div>
    <div class="baopan-shockwave"></div>
    <div class="baopan-shockwave2"></div>
    <div class="baopan-label-wrap">
      <div class="baopan-main-text" style="color:${theme.accent};">${theme.label}</div>
      <div class="baopan-sub-text">主力資金正式進場</div>
      <div class="baopan-weight-badge">加權 ×${weight.toFixed(2)}</div>
    </div>
  `;

  // Money/emoji rain
  const rainCount = 28;
  for (let i = 0; i < rainCount; i++) {
    const el = document.createElement('div');
    el.className = 'bp-particle';
    el.textContent = theme.emoji[i % theme.emoji.length];
    el.style.left = `${Math.random() * 100}vw`;
    el.style.top = `${-40 - Math.random() * 60}px`;
    el.style.animationDuration = `${1.2 + Math.random() * 1.2}s`;
    el.style.animationDelay = `${Math.random() * 0.6}s`;
    el.style.fontSize = `${18 + Math.random() * 20}px`;
    cinema.appendChild(el);
  }

  // Hide after animation completes
  setTimeout(() => {
    cinema.style.display = 'none';
    cinema.innerHTML = '';
  }, 2200);
}

/* =========================================================
 * News Feed (right panel) — 盤中個股快報串
 * ========================================================= */
const FEED_TYPES = {
  up:    { tag: '📈 強勢拉升',  cls: 't-up' },
  down:  { tag: '📉 跌破支撐',  cls: 't-down' },
  warn:  { tag: '⚠️ 異常警示',  cls: 't-warn' },
  hot:   { tag: '🔥 連續長紅',  cls: 't-hot' },
  rumor: { tag: '💬 市場傳聞',  cls: 't-rumor' },
  inst:  { tag: '🏦 法人動向',  cls: 't-inst' }
};
const FEED_TEMPLATES = [
  { type: 'up',    text: '{name} 五分鐘內大漲 {pct}%，買盤蜂擁而入' },
  { type: 'up',    text: '{name} 突破前波高點，量價齊揚' },
  { type: 'hot',   text: '{name} 連三根長紅，技術面轉強' },
  { type: 'hot',   text: '{name} 成交量爆大量，較昨日放大 {vol} 倍' },
  { type: 'down',  text: '{name} 跌破 10 日線支撐，短線賣壓浮現' },
  { type: 'down',  text: '{name} 遭逢獲利了結賣壓，股價回檔 {pct}%' },
  { type: 'warn',  text: '{name} 出現異常委買，主管機關關注中' },
  { type: 'warn',  text: '市場傳出 {name} 有重大訊息待公布，暫停撮合評估中' },
  { type: 'rumor', text: '盤面耳語：{name} 今日精神狀態極佳，法人解讀為利多' },
  { type: 'rumor', text: '有不具名消息指出，{name} 可能名列今日欽點名單' },
  { type: 'inst',  text: '外資小買 {name} {vol} 張，三大法人呈現買超' },
  { type: 'inst',  text: '投信連三日加碼 {name}，持股比例拉升' },
  { type: 'up',    text: '{name} 盤中直攻漲停，鎖死鎖單' },
  { type: 'warn',  text: '撮合系統偵測 {name} 委買量異常集中，啟動監控程序' }
];

let feedTimer = null;
let feedCounter = 0;

function fmtFeedTime() {
  const d = new Date();
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

function appendFeedMessage(opts = {}) {
  const feed = $('newsFeed');
  if (!feed) return;
  let html;
  if (opts.pinned) {
    html = `<div class="nf-msg pinned"><span class="nf-tag">🏦 主力進場</span><span class="nf-time">${fmtFeedTime()}</span>${opts.text}</div>`;
  } else {
    const pool = allMembers();
    if (!pool.length) return;
    const subject = pool[randInt(0, pool.length - 1)];
    const tpl = FEED_TEMPLATES[randInt(0, FEED_TEMPLATES.length - 1)];
    const type = FEED_TYPES[tpl.type];
    const nameHtml = `<b style="color:#fff;">${subject.id} ${subject.name}</b>`;
    const body = tpl.text
      .replace('{name}', nameHtml)
      .replace('{pct}', (rand(2, 9)).toFixed(2))
      .replace('{vol}', randInt(2, 9));
    html = `<div class="nf-msg ${type.cls}"><span class="nf-tag">${type.tag}</span><span class="nf-time">${fmtFeedTime()}</span>${body}</div>`;
  }
  // Insert at the top (newest first); column-reverse means prepend = visually top
  feed.insertAdjacentHTML('afterbegin', html);
  // cap messages
  while (feed.children.length > 40) feed.removeChild(feed.lastChild);
  feedCounter++;
}

function startFeedLoop() {
  stopFeedLoop();
  const feed = $('newsFeed');
  if (feed) feed.innerHTML = '';
  feedCounter = 0;
  appendFeedMessage();
  appendFeedMessage();
  feedTimer = setInterval(() => {
    if (!IS_PAUSED) appendFeedMessage();
  }, 2500);
}
function stopFeedLoop() {
  if (feedTimer) { clearInterval(feedTimer); feedTimer = null; }
}

/* =========================================================
 * Stock detail modal (bottom sheet) with Canvas K-line
 * ========================================================= */
// Seeded PRNG so each stock's chart & stats stay stable per session
function seededRand(seed) {
  let s = seed | 0;
  return function () {
    s = (s * 1664525 + 1013904223) | 0;
    return ((s >>> 0) % 100000) / 100000;
  };
}

function drawKLine(canvas, seedNum) {
  if (!canvas || !canvas.getContext) return;
  const ctx = canvas.getContext('2d');
  // Match internal resolution to display size for crispness
  const dpr = window.devicePixelRatio || 1;
  const cssW = canvas.clientWidth || canvas.width;
  const cssH = canvas.clientHeight || canvas.height;
  canvas.width  = Math.round(cssW * dpr);
  canvas.height = Math.round(cssH * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  const rng = seededRand(seedNum);

  // Generate 30 candles: random walk, last 10 trend up
  const N = 30;
  const candles = [];
  let v = 100 + rng() * 40;
  for (let i = 0; i < N; i++) {
    const trendUp = i >= N - 10;
    const drift = trendUp ? (0.8 + rng() * 1.8) : ((rng() - 0.5) * 3);
    const open = v;
    const close = Math.max(30, open + drift);
    const high = Math.max(open, close) + rng() * 1.4;
    const low  = Math.min(open, close) - rng() * 1.4;
    const vol  = 30 + rng() * 70 + (trendUp ? rng() * 60 : 0);
    candles.push({ open, close, high, low, vol });
    v = close;
  }

  // Layout: price pane on top (70%), volume pane on bottom (30%) — 160/40
  const padL = 6, padR = 6, padT = 6, padB = 4;
  const volH = 40;
  const gap  = 6;
  const priceH = cssH - volH - gap - padT - padB;
  const priceTop = padT;
  const volTop   = padT + priceH + gap;
  const plotW = cssW - padL - padR;

  const highs = candles.map(c => c.high);
  const lows  = candles.map(c => c.low);
  const pMax = Math.max(...highs);
  const pMin = Math.min(...lows);
  const pRange = Math.max(0.5, pMax - pMin);
  const vols = candles.map(c => c.vol);
  const vMax = Math.max(...vols);

  // Background grid
  ctx.strokeStyle = '#1f1f1f';
  ctx.lineWidth = 1;
  for (let g = 0; g <= 4; g++) {
    const y = priceTop + (priceH / 4) * g;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + plotW, y); ctx.stroke();
  }

  const cw = plotW / N;
  const bw = Math.max(2, cw * 0.62);

  // Draw candles
  candles.forEach((c, i) => {
    const up = c.close >= c.open;
    const color = up ? '#ff6b72' : '#4fd4b0';
    const cx = padL + cw * i + cw / 2;
    const yH = priceTop + (1 - (c.high - pMin) / pRange) * priceH;
    const yL = priceTop + (1 - (c.low  - pMin) / pRange) * priceH;
    const yO = priceTop + (1 - (c.open - pMin) / pRange) * priceH;
    const yC = priceTop + (1 - (c.close- pMin) / pRange) * priceH;

    // wick
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(cx, yH); ctx.lineTo(cx, yL); ctx.stroke();

    // body
    ctx.fillStyle = color;
    const bodyTop = Math.min(yO, yC);
    const bodyH = Math.max(1.5, Math.abs(yC - yO));
    ctx.fillRect(cx - bw / 2, bodyTop, bw, bodyH);

    // volume bar
    const vh = (c.vol / vMax) * (volH - 2);
    ctx.fillStyle = up ? 'rgba(255,107,114,0.7)' : 'rgba(79,212,176,0.7)';
    ctx.fillRect(cx - bw / 2, volTop + (volH - vh), bw, vh);
  });

  // Price axis labels
  ctx.fillStyle = '#666';
  ctx.font = '10px "SF Mono", monospace';
  ctx.textAlign = 'left';
  ctx.fillText(pMax.toFixed(2), padL + 2, priceTop + 9);
  ctx.fillText(pMin.toFixed(2), padL + 2, priceTop + priceH - 2);

  // Volume label
  ctx.fillStyle = '#555';
  ctx.fillText('VOL', padL + 2, volTop + 10);
}

const COMMENTARY_TEMPLATES = [
  '{name} 近期表現亮眼，技術面多頭排列，建議投資人持續關注後續動向。',
  '{name} 量價配合良好，外資連續買超，短線有望挑戰前波高點。',
  '{name} 今日出現爆量長紅，顯示主力資金進場跡象，可偏多操作。',
  '{name} 基本面穩健，搭配本季作手題材發酵，具中長線投資價值。',
  '{name} 技術線型突破三角收斂，成交量明顯放大，買進訊號浮現。',
  '{name} 盤中多次試探漲停，委買單大幅高於委賣，走勢偏強。'
];

function openStockModal(id) {
  if (!animating) return;
  const ref = cardRefs.get(id);
  if (!ref) return;
  const pool = allMembers();
  const member = pool.find(m => m.id === id);
  if (!member) return;

  const seed = (parseInt(id, 10) || 1) * 9973 + 1;
  const rng = seededRand(seed);

  // Current price from DOM (live-updating)
  const priceTxt = ref.price.textContent;
  const pctTxt = ref.change.textContent;
  const up = !ref.price.classList.contains('down-color');
  const priceCls = up ? 'up-color' : 'down-color';
  const arrow = up ? '▲' : '▼';

  // Header
  $('stockModalHeader').innerHTML = `
    <div class="sm-id-name">
      <div class="sm-id">${member.id} · ${member.div || ''}</div>
      <div class="sm-name">${member.name}<span class="sm-pos">${member.position}</span></div>
    </div>
    <div class="sm-price-block">
      <div class="sm-price ${priceCls}">${arrow}${priceTxt}</div>
      <div class="sm-pct ${priceCls}">${pctTxt}</div>
    </div>
  `;

  // Stats — stable per-person (seeded)
  const base = ref.basePrice;
  const high = (base * (1 + 0.04 + rng() * 0.06)).toFixed(2);
  const low  = (base * (1 - 0.03 - rng() * 0.05)).toFixed(2);
  const vol  = Math.floor(2000 + rng() * 80000).toLocaleString();
  const pe   = (8 + rng() * 22).toFixed(2);
  const mcap = (base * (0.8 + rng() * 3) * 100).toFixed(1) + ' 億';
  const turn = (0.5 + rng() * 6).toFixed(2) + ' %';

  $('stockModalStats').innerHTML = `
    <div class="sm-stat"><span class="k">今日最高</span><span class="v up-color" style="background:none;padding:0;">${high}</span></div>
    <div class="sm-stat"><span class="k">今日最低</span><span class="v down-color" style="background:none;padding:0;">${low}</span></div>
    <div class="sm-stat"><span class="k">成交量</span><span class="v">${vol}</span></div>
    <div class="sm-stat"><span class="k">本益比</span><span class="v">${pe}</span></div>
    <div class="sm-stat"><span class="k">市值</span><span class="v">${mcap}</span></div>
    <div class="sm-stat"><span class="k">週轉率</span><span class="v">${turn}</span></div>
  `;

  // Commentary (seeded pick)
  const tpl = COMMENTARY_TEMPLATES[Math.floor(rng() * COMMENTARY_TEMPLATES.length)];
  $('stockModalCommentary').innerHTML = tpl.replace('{name}', `<b>${member.name}</b>`);

  // CTA
  const cta = $('stockModalCta');
  cta.disabled = false;
  cta.textContent = '📣 加碼喊單';
  cta.onclick = () => {
    onCardClick(id);
    playClick();
    cta.disabled = true;
    cta.textContent = '委託成立 ✓';
  };

  // Show modal
  $('stockModalMask').classList.add('show');

  // Draw K-line after modal visible so clientWidth is correct
  setTimeout(() => {
    drawKLine($('stockKline'), seed);
  }, 50);
}

function closeStockModal() {
  $('stockModalMask').classList.remove('show');
}

/* =========================================================
 * Init
 * ========================================================= */
async function init() {
  startClock();
  await loadData(); // now synchronous internally, await is a no-op but kept for clarity
  PRICES = generateBasePrices();
  renderTicker();
  renderPage1();
  resetBaopanPanel();

  $('submitBtn').addEventListener('click', () => {
    playClick();
    // Capture qty now; result is resolved later (after 護盤期結束)
    PENDING_QTY = captureQty();
    BAOPAN = null;
    renderPage2();
    showPage(2);
    // kick audio
    getAudio();
    setTimeout(runTradingAnimation, 400);
  });

  $('restartBtn').addEventListener('click', reset);

  // Stock modal: click mask (but not the sheet itself) to close
  const smMask = $('stockModalMask');
  if (smMask) {
    smMask.addEventListener('click', (e) => {
      if (e.target === smMask) closeStockModal();
    });
  }
}

init();
