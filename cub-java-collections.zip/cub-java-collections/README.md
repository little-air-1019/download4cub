# Java Collections Framework 教學專案

## 📖 專案簡介

本專案是 Java Collections Framework (JCF) 的教學程式碼講義，透過可執行的 Demo Code 搭配詳細註解，幫助你深入理解 Java 集合框架。

## 🎯 目標對象

- 具備 Java 基礎語法知識的實習生
- 需要理解 JCF 架構與實務應用的初學者

## 📚 課程內容

| Part   | 主題       | 說明                                    |
| ------ | ---------- | --------------------------------------- |
| Part 1 | Array      | 陣列基礎與限制，了解為何需要 Collection |
| Part 2 | Collection | List、Set、Queue 介面體系               |
| Part 3 | Map        | 鍵值對映射，獨立於 Collection 的體系    |

### 貫穿主題
- **Generics（泛型）**：型態安全的集合
- **Auto Boxing / Unboxing**：基本型態與包裝類別的自動轉換
- **Diamond 語法**：`<>` 簡化泛型宣告

## 🗂️ 目錄結構

```
cub-java-collections/
├── pom.xml
├── README.md
├── docs/                          # 文件
│   ├── Part1_Array.md
│   ├── Part2_Collection.md
│   ├── Part3_Map.md
│   └── Appendix_Generics_AutoBoxing.md
└── src/main/java/com/tutorial/collections/
    ├── part1_array/               # Part 1: 陣列
    │   ├── A01_ArrayBasics.java
    │   ├── A02_ArrayMemoryAndAccess.java
    │   ├── A03_ArraysUtilityClass.java
    │   ├── A04_ArrayLimitations.java
    │   └── exercises/
    │       └── ArrayExercises.java
    ├── part2_collection/          # Part 2: Collection 體系
    │   ├── B01-B15 系列 Demo
    │   └── exercises/
    │       └── CollectionExercises.java
    ├── part3_map/                 # Part 3: Map 體系
    │   ├── C01-C06 系列 Demo
    │   └── exercises/
    │       └── MapExercises.java
    └── common/                    # 貫穿主題
        ├── GenericsDemo.java
        ├── AutoBoxingDemo.java
        └── DiamondSyntaxDemo.java
```

## 🚀 如何執行

### 環境需求
- **Java**: 17+
- **Maven**: 3.6+

### 編譯專案
```bash
mvn compile
```

### 執行單一 Demo
```bash
# 執行 ArrayBasics Demo
mvn exec:java -Dexec.mainClass="com.tutorial.collections.part1_array.A01_ArrayBasics"

# 執行 ArrayList Demo
mvn exec:java -Dexec.mainClass="com.tutorial.collections.part2_collection.B03_ArrayListDeepDive"
```

### 在 IDE 中執行
直接開啟任一 Demo 檔案，執行其 `main()` 方法。

## 📖 建議學習順序

```
1. common/DiamondSyntaxDemo.java     ← 先了解語法糖
2. common/AutoBoxingDemo.java        ← 了解包裝類別
3. Part 1: Array（A01 → A04）
4. Part 2: Collection
   4.1 基礎架構（B01 → B04）
   4.2 Set 系列（B05 → B07）
   4.3 Queue（B08）
   4.4 Iterator 深入（B09 → B10）
   4.5 排序機制（B11 → B13）
   4.6 空值判斷（B14）
   4.7 Collections 工具類（B15）
5. Part 3: Map（C01 → C06）
6. common/GenericsDemo.java          ← 深入泛型
7. 各 Part 的 Exercises
```

## 📝 程式碼風格

每個 Demo 都遵循統一的結構：
- 開頭有學習目標說明
- 以分段註解區分不同知識點
- 每個檔案都有獨立的 `main()` 方法可執行
- 輸出包含清楚的說明文字

## 🔗 延伸閱讀

- [Oracle Java Tutorials - Collections](https://docs.oracle.com/javase/tutorial/collections/)
- [Java Collections Framework Documentation](https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/package-summary.html)

---

**版本**：1.0  
**Java 版本**：17  
**建立日期**：2025-01-18
