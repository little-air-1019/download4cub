# Part 1：Array（陣列）

## 學習目標
- 了解陣列的基本操作
- 理解連續記憶體與 O(1) 隨機訪問
- 掌握 `java.util.Arrays` 工具類
- 認識陣列的限制，為學習 Collection 做準備

---

## 1. 陣列記憶體配置

```
假設有 int[] arr = {10, 20, 30, 40, 50};
起始位址是 1000，int 占用 4 bytes：

記憶體位址:  1000    1004    1008    1012    1016
           +-------+-------+-------+-------+-------+
           |  10   |  20   |  30   |  40   |  50   |
           +-------+-------+-------+-------+-------+
索引:        [0]     [1]     [2]     [3]     [4]
```

**O(1) 隨機訪問原理**：
```
元素位址 = 基底位址 + (index × 元素大小)
arr[3] 的位址 = 1000 + (3 × 4) = 1012
```

---

## 2. Arrays 工具類方法速查

| 方法                     | 說明                 | 範例           |
| ------------------------ | -------------------- | -------------- |
| `toString(arr)`          | 轉為可讀字串         | `[1, 2, 3]`    |
| `sort(arr)`              | 原地排序             | 升序排列       |
| `binarySearch(arr, key)` | 二分搜尋（需先排序） | 回傳索引或負數 |
| `fill(arr, value)`       | 填充陣列             | 全部設為指定值 |
| `copyOf(arr, len)`       | 複製陣列             | 可擴展或截斷   |
| `equals(arr1, arr2)`     | 比較內容             | 回傳 boolean   |
| `asList(arr)`            | 轉為 List            | ⚠️ 固定大小     |

> [!WARNING]
> `Arrays.asList()` 回傳的 List 是固定大小的，呼叫 `add()` 或 `remove()` 會拋出 `UnsupportedOperationException`。

---

## 3. 陣列的限制

| 限制         | 說明                                   |
| ------------ | -------------------------------------- |
| 固定長度     | 建立後無法動態增減                     |
| 手動擴容     | 需要建立新陣列並複製                   |
| 缺乏便利方法 | 沒有 `add()`, `remove()`, `contains()` |

**這就是為什麼我們需要 ArrayList！**

---

## 4. 重點整理

1. 陣列長度是 `arr.length`（屬性），不是方法
2. 索引從 0 開始，最大為 `length - 1`
3. 基本類型陣列預設值為 0/false，物件陣列預設為 null
4. 使用 `Arrays.binarySearch()` 前必須先排序
5. 陣列的限制引出了 Collection 的需求

---

## 5. 延伸閱讀

- [Oracle Java Tutorials - Arrays](https://docs.oracle.com/javase/tutorial/java/nutsandbolts/arrays.html)
