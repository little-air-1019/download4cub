# Part 2：Collection 介面體系

## 學習目標
- 理解 JCF 繼承體系
- 掌握 List、Set、Queue 的特性
- 學會 Iterator 迭代器
- 掌握排序機制（Comparable/Comparator）
- 了解空值判斷最佳實踐

---

## 1. JCF 繼承體系

```
                  Iterable<E>
                      │
                      ▼
                Collection<E>
               ╱     │     ╲
              ╱      │      ╲
             ▼       ▼       ▼
         List<E>  Set<E>  Queue<E>
           │        │        │
      ┌────┴────┐   │   ┌────┴────┐
      ▼         ▼   ▼   ▼         ▼
 ArrayList  LinkedList  HashSet  PriorityQueue
                 │        │
                 │        ▼
                 │     TreeSet
      (同時實作 List 和 Deque)
```

---

## 2. List / Set / Queue 特性比較

| 介面  | 有序   | 允許重複 | 可用 index | 常見實作                  |
| ----- | ------ | -------- | ---------- | ------------------------- |
| List  | ✓      | ✓        | ✓          | ArrayList, LinkedList     |
| Set   | 通常否 | ✗        | ✗          | HashSet, TreeSet          |
| Queue | ✓      | ✓        | ✗          | LinkedList, PriorityQueue |

---

## 3. ArrayList vs LinkedList

| 操作         | ArrayList | LinkedList |
| ------------ | --------- | ---------- |
| get(index)   | O(1) ✓    | O(n)       |
| add(尾端)    | O(1) 均攤 | O(1)       |
| add(頭部)    | O(n)      | O(1) ✓     |
| remove(頭部) | O(n)      | O(1) ✓     |
| 記憶體       | 較省      | 較多       |

**選擇建議**：
- 頻繁隨機訪問 → ArrayList
- 頻繁頭尾操作 → LinkedList

---

## 4. HashSet 去重原理

```
1. 計算 hashCode
2. 決定 bucket = hash % bucketCount
3. 若有 collision → 用 equals() 判斷

Bucket 0: [ ]
Bucket 1: [Apple] → [Apricot]  ← Hash Collision
Bucket 2: [Banana]
```

> [!IMPORTANT]
> 自訂物件必須覆寫 `equals()` 和 `hashCode()`，否則無法正確去重！

---

## 5. Iterator 說明

### 核心方法
| 方法        | 說明                           |
| ----------- | ------------------------------ |
| `hasNext()` | 是否還有下一個元素             |
| `next()`    | 回傳下一個元素                 |
| `remove()`  | 移除最後一次 next() 回傳的元素 |

### 特性
- **單向性**：只能往前
- **一次性**：遍歷完需重新取得
- **Fail-Fast**：遍歷中集合被修改會拋出 `ConcurrentModificationException`

### for-each 是語法糖
```java
for (String item : list) { ... }
// 編譯後等同於
Iterator<String> it = list.iterator();
while (it.hasNext()) { String item = it.next(); ... }
```

---

## 6. Comparable vs Comparator

| 特性       | Comparable       | Comparator            |
| ---------- | ---------------- | --------------------- |
| 位置       | 類別內部         | 類別外部              |
| 方法       | `compareTo(T o)` | `compare(T o1, T o2)` |
| 排序規則   | 只能一種         | 可以多種              |
| 修改原類別 | 需要             | 不需要                |

### compareTo / compare 回傳值
| 回傳值 | 意義          |
| ------ | ------------- |
| 負數   | this < other  |
| 零     | this == other |
| 正數   | this > other  |

### Java 8+ Comparator 速查
```java
Comparator.comparing(Student::getScore)           // 建構
Comparator.comparing(...).reversed()              // 反向
Comparator.comparing(...).thenComparing(...)      // 多欄位
Comparator.nullsFirst(...) / nullsLast(...)       // null 處理
```

---

## 7. 空值判斷

### null vs empty
- **null**：變數沒有指向任何物件
- **empty**：變數指向一個存在但沒有元素的集合

### 判斷方式對比
| 方式                               | null 安全 | 簡潔度 |
| ---------------------------------- | --------- | ------ |
| `list != null && !list.isEmpty()`  | ✓         | 較長   |
| `CollectionUtils.isEmpty(list)`    | ✓         | 簡潔   |
| `CollectionUtils.isNotEmpty(list)` | ✓         | 最簡潔 |

---

## 8. Collections 工具類速查

| 方法                                  | 說明        |
| ------------------------------------- | ----------- |
| `sort(list)`                          | 排序        |
| `reverse(list)`                       | 反轉        |
| `shuffle(list)`                       | 隨機打亂    |
| `binarySearch(list, key)`             | 二分搜尋    |
| `max(collection)` / `min(collection)` | 最大/最小值 |
| `unmodifiableList(list)`              | 不可修改    |
| `synchronizedList(list)`              | 執行緒安全  |
| `emptyList()`                         | 空集合      |

---

## 9. 常見誤區

1. ❌ 在 for-each 中直接呼叫 `list.remove()`
2. ❌ 忘記檢查 null 就呼叫 `isEmpty()`
3. ❌ 用 `keySet()` + `get()` 遍歷 Map
4. ❌ Integer 用 `==` 比較（應該用 `equals()`）
5. ❌ 自訂物件忘記覆寫 `equals()/hashCode()`
