# 附錄：Generics 與 Auto Boxing

## 1. 泛型語法速查

### 基本語法
| 語法            | 說明         | 範例                     |
| --------------- | ------------ | ------------------------ |
| `<T>`           | 型態參數     | `class Box<T>`           |
| `<T, U>`        | 多個型態參數 | `class Pair<K, V>`       |
| `<T extends X>` | 上界限制     | `<T extends Number>`     |
| `<?>`           | 萬用字元     | `List<?>`                |
| `<? extends X>` | 上界萬用字元 | `List<? extends Number>` |
| `<? super X>`   | 下界萬用字元 | `List<? super Integer>`  |

### 泛型方法
```java
public static <T> List<T> arrayToList(T[] array) {
    List<T> list = new ArrayList<>();
    for (T item : array) {
        list.add(item);
    }
    return list;
}
```

---

## 2. Wildcard 使用場景

| Wildcard        | 可讀   | 可寫 | 使用場景           |
| --------------- | ------ | ---- | ------------------ |
| `<?>`           | Object | ✗    | 只讀取，型態不重要 |
| `<? extends T>` | T      | ✗    | Producer（生產者） |
| `<? super T>`   | Object | T    | Consumer（消費者） |

---

## 3. PECS 原則

**PECS = Producer Extends, Consumer Super**

```java
// 範例：Collections.copy()
public static <T> void copy(
    List<? super T> dest,      // Consumer → super
    List<? extends T> src      // Producer → extends
) { ... }
```

| 情境                 | 使用              |
| -------------------- | ----------------- |
| 要從集合「讀取」資料 | `<? extends T>`   |
| 要往集合「寫入」資料 | `<? super T>`     |
| 既讀又寫             | `<T>`（精確型態） |

---

## 4. Type Erasure（型態擦除）

泛型資訊只存在於**編譯期**，執行期會被擦除！

```java
List<String>  →  編譯後  →  List
List<Integer> →  編譯後  →  List
```

### 因此無法：
| 寫法                      | 原因                |
| ------------------------- | ------------------- |
| `new T()`                 | 不知道 T 是什麼類別 |
| `new T[10]`               | 無法建立泛型陣列    |
| `instanceof List<String>` | 執行期沒有型態資訊  |

---

## 5. 基本類型與包裝類別對照

| 基本類型  | 包裝類別    | 預設值   |
| --------- | ----------- | -------- |
| `byte`    | `Byte`      | 0        |
| `short`   | `Short`     | 0        |
| `int`     | `Integer`   | 0        |
| `long`    | `Long`      | 0L       |
| `float`   | `Float`     | 0.0f     |
| `double`  | `Double`    | 0.0d     |
| `char`    | `Character` | '\u0000' |
| `boolean` | `Boolean`   | false    |

---

## 6. Auto Boxing 陷阱

### 陷阱 1：null Unboxing
```java
Integer n = null;
int value = n;  // NullPointerException!
```

### 陷阱 2：Integer 快取
```java
Integer a = 127, b = 127;
a == b  // true（快取範圍內）

Integer c = 128, d = 128;
c == d  // false（超出快取範圍）
```

> [!CAUTION]
> 比較 Integer 應該使用 `equals()`，不要用 `==`！

### 陷阱 3：效能影響
```java
// ❌ 不好
Long sum = 0L;
for (long i = 0; i < 10000; i++) {
    sum += i;  // 每次都會 Boxing/Unboxing
}

// ✓ 好
long sum = 0L;
for (long i = 0; i < 10000; i++) {
    sum += i;
}
```

---

## 7. Diamond 語法速查

| Java 版本 | 寫法                                           |
| --------- | ---------------------------------------------- |
| Java 6    | `List<String> list = new ArrayList<String>();` |
| Java 7+   | `List<String> list = new ArrayList<>();`       |
| Java 10+  | `var list = new ArrayList<String>();`          |

> [!WARNING]
> 使用 `var` 時，右邊必須明確指定型態：
> - ❌ `var list = new ArrayList<>();` → 型態會是 `ArrayList<Object>`
> - ✓ `var list = new ArrayList<String>();`
