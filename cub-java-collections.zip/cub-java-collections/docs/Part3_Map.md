# Part 3：Map 介面體系

## 學習目標
- 理解 Map 不是 Collection
- 掌握 Map 的核心操作
- 了解 HashMap 與 TreeMap 的差異
- 認識 ConcurrentHashMap

---

## 1. Map 在 JCF 中的定位

```
╔═══════════════════════════════╦═════════════════════════════╗
║      Collection 體系          ║          Map 體系           ║
╠═══════════════════════════════╬═════════════════════════════╣
║       Iterable<E>             ║                             ║
║           │                   ║                             ║
║      Collection<E>            ║         Map<K,V>            ║
║       /    |    \             ║        /    |    \          ║
║    List   Set   Queue         ║   HashMap TreeMap LinkedHM  ║
╚═══════════════════════════════╩═════════════════════════════╝
```

> [!NOTE]
> Map 與 Collection 是平行關係，不是繼承關係！

---

## 2. Map 核心方法

| 方法                       | 說明                     |
| -------------------------- | ------------------------ |
| `put(K, V)`                | 新增/更新，回傳舊值      |
| `get(K)`                   | 取值，不存在回傳 null    |
| `getOrDefault(K, default)` | 安全取值                 |
| `containsKey(K)`           | 是否包含 key             |
| `containsValue(V)`         | 是否包含 value           |
| `remove(K)`                | 移除                     |
| `keySet()`                 | 所有 key 的 Set          |
| `values()`                 | 所有 value 的 Collection |
| `entrySet()`               | 所有 Entry 的 Set        |

### Java 8+ 新增方法
| 方法                       | 說明                   |
| -------------------------- | ---------------------- |
| `putIfAbsent(K, V)`        | key 不存在時才放入     |
| `computeIfAbsent(K, func)` | key 不存在時計算並放入 |
| `merge(K, V, BiFunction)`  | 合併值                 |

---

## 3. HashMap / TreeMap / ConcurrentHashMap 比較

| 特性       | HashMap    | TreeMap  | ConcurrentHashMap |
| ---------- | ---------- | -------- | ----------------- |
| 底層結構   | Hash Table | 紅黑樹   | Hash Table        |
| 是否排序   | 否         | 是       | 否                |
| null key   | 允許一個   | 不允許   | 不允許            |
| null value | 允許       | 允許     | 不允許            |
| get/put    | O(1)       | O(log n) | O(1)              |
| 執行緒安全 | 否         | 否       | 是                |

---

## 4. HashMap Bucket 結構

```
put(key, value) 流程：
1. hash = hashCode(key) 經擾動處理
2. bucket = hash & (length - 1)
3. 空 bucket → 直接放入
4. 非空（Collision）→ 用 equals() 檢查

示意圖：
[0] → null
[1] → (K1,V1) → (K2,V2)  ← Hash Collision
[2] → (K3,V3)
[3] → null
...

Java 8+：鏈結 > 8 且陣列 >= 64 → 轉紅黑樹
```

---

## 5. Map 遍歷方式比較

| 方式                 | 效能   | 適用場景              |
| -------------------- | ------ | --------------------- |
| `keySet()` + `get()` | 較差   | 只需要 key            |
| `values()`           | 好     | 只需要 value          |
| `entrySet()`         | 最好 ✓ | 同時需要 key 和 value |
| `forEach()`          | 最好 ✓ | Java 8+，程式碼簡潔   |
| Iterator             | 好     | 需要在遍歷中移除元素  |

### 推薦寫法
```java
// Java 8+ forEach
map.forEach((key, value) -> {
    System.out.println(key + " = " + value);
});

// entrySet
for (Map.Entry<String, Integer> entry : map.entrySet()) {
    String key = entry.getKey();
    Integer value = entry.getValue();
}
```

---

## 6. TreeMap 導航方法

| 方法             | 說明              |
| ---------------- | ----------------- |
| `firstKey()`     | 最小的 key        |
| `lastKey()`      | 最大的 key        |
| `lowerKey(K)`    | < K 的最大 key    |
| `higherKey(K)`   | > K 的最小 key    |
| `floorKey(K)`    | ≤ K 的最大 key    |
| `ceilingKey(K)`  | ≥ K 的最小 key    |
| `headMap(K)`     | < K 的子 Map      |
| `tailMap(K)`     | ≥ K 的子 Map      |
| `subMap(K1, K2)` | [K1, K2) 的子 Map |

---

## 7. 常見誤區

1. ❌ 用 `keySet()` + `get()` 遍歷（效率差）
2. ❌ HashMap 自訂 key 忘記覆寫 `equals()/hashCode()`
3. ❌ 誤以為 Map 是 Collection 的一部分
4. ❌ ConcurrentHashMap 允許 null（不允許！）
5. ❌ TreeMap 放入未實作 Comparable 的物件
