package com.tutorial.collections.part2_collection;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * ============================================================
 * 【章節標題】B08 - Queue 介面
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 Queue 的 FIFO 特性
 * 2. 掌握 Queue 的核心方法（add/offer, remove/poll, element/peek）
 * 3. 認識 PriorityQueue 優先權佇列
 * 
 * ============================================================
 */
public class B08_QueueInterface {

    public static void main(String[] args) {
        System.out.println("=== B08: Queue 介面 ===\n");

        // ============================
        // 1. Queue 基本概念
        // ============================
        /*
         * Queue（佇列）是 FIFO 結構：First In, First Out
         * 
         * 想像排隊：
         * - 新來的人排在隊尾（offer/add）
         * - 最先來的人先處理（poll/remove）
         * 
         *    入隊 → [尾][...][...][頭] → 出隊
         */
        System.out.println("【1. Queue 基本概念】");
        System.out.println("Queue 是 FIFO 結構：First In, First Out");
        System.out.println();
        System.out.println("排隊示意：");
        System.out.println("  入隊 → [尾][...][...][頭] → 出隊");
        System.out.println("         新來的    先來的");
        System.out.println();

        // ============================
        // 2. Queue 核心方法對比
        // ============================
        /*
         * Queue 的方法分為兩組：
         * 
         * |  操作  |  失敗時拋例外  |  失敗時回傳特殊值  |
         * |--------|---------------|-------------------|
         * | 新增   | add(e)        | offer(e) → false  |
         * | 移除   | remove()      | poll() → null     |
         * | 查看   | element()     | peek() → null     |
         * 
         * 建議：使用 offer/poll/peek 較安全
         */
        System.out.println("【2. Queue 核心方法對比】");
        System.out.println();
        System.out.println("┌──────────┬─────────────────┬─────────────────────┐");
        System.out.println("│   操作   │ 失敗時拋例外    │ 失敗時回傳特殊值    │");
        System.out.println("├──────────┼─────────────────┼─────────────────────┤");
        System.out.println("│ 新增     │ add(e)          │ offer(e) → false    │");
        System.out.println("│ 移除     │ remove()        │ poll() → null       │");
        System.out.println("│ 查看     │ element()       │ peek() → null       │");
        System.out.println("└──────────┴─────────────────┴─────────────────────┘");
        System.out.println();
        System.out.println("💡 建議：使用 offer/poll/peek 較安全");
        System.out.println();

        // ============================
        // 3. 使用 LinkedList 作為 Queue
        // ============================
        System.out.println("【3. 使用 LinkedList 作為 Queue】");
        
        Queue<String> queue = new LinkedList<>();
        
        // 入隊
        queue.offer("First");
        queue.offer("Second");
        queue.offer("Third");
        
        System.out.println("offer: First → Second → Third");
        System.out.println("Queue: " + queue);
        System.out.println();
        
        // 查看頭部（不移除）
        String head = queue.peek();
        System.out.println("peek() = " + head);
        System.out.println("Queue after peek: " + queue);
        System.out.println();
        
        // 出隊
        String removed = queue.poll();
        System.out.println("poll() = " + removed);
        System.out.println("Queue after poll: " + queue);
        System.out.println();
        
        // 繼續出隊
        System.out.println("poll() = " + queue.poll());
        System.out.println("poll() = " + queue.poll());
        System.out.println("poll() = " + queue.poll());  // null（佇列為空）
        System.out.println();

        // ============================
        // 4. 空佇列行為對比
        // ============================
        System.out.println("【4. 空佇列行為對比】");
        
        Queue<String> emptyQueue = new LinkedList<>();
        
        // 安全方法
        System.out.println("空佇列使用安全方法：");
        System.out.println("  poll() = " + emptyQueue.poll());  // null
        System.out.println("  peek() = " + emptyQueue.peek());  // null
        
        // 危險方法
        System.out.println("\n空佇列使用危險方法：");
        try {
            emptyQueue.remove();
        } catch (java.util.NoSuchElementException e) {
            System.out.println("  remove() → NoSuchElementException");
        }
        try {
            emptyQueue.element();
        } catch (java.util.NoSuchElementException e) {
            System.out.println("  element() → NoSuchElementException");
        }
        System.out.println();

        // ============================
        // 5. PriorityQueue 優先權佇列
        // ============================
        /*
         * PriorityQueue 不是 FIFO！
         * 而是按照「優先權」決定誰先出隊。
         * 
         * 預設：自然順序（數字小的優先）
         * 也可以提供 Comparator 自訂順序
         */
        System.out.println("【5. PriorityQueue 優先權佇列】");
        
        Queue<Integer> pq = new PriorityQueue<>();
        
        pq.offer(5);
        pq.offer(2);
        pq.offer(8);
        pq.offer(1);
        pq.offer(9);
        
        System.out.println("offer 順序: 5, 2, 8, 1, 9");
        System.out.println("PriorityQueue 內部: " + pq);
        System.out.println("（內部順序不代表出隊順序！）");
        System.out.println();
        
        System.out.println("poll 出隊順序（最小的先出）：");
        while (!pq.isEmpty()) {
            System.out.print(pq.poll() + " ");
        }
        System.out.println();
        System.out.println();

        // ============================
        // 6. PriorityQueue 自訂優先權
        // ============================
        System.out.println("【6. PriorityQueue 自訂優先權】");
        
        // 最大的先出（降序）
        Queue<Integer> maxPQ = new PriorityQueue<>((a, b) -> b - a);
        
        maxPQ.offer(5);
        maxPQ.offer(2);
        maxPQ.offer(8);
        maxPQ.offer(1);
        
        System.out.println("使用 Comparator (b - a) 讓最大的先出：");
        while (!maxPQ.isEmpty()) {
            System.out.print(maxPQ.poll() + " ");
        }
        System.out.println();
        System.out.println();

        // ============================
        // 7. 使用場景
        // ============================
        System.out.println("【7. 使用場景】");
        System.out.println();
        System.out.println("Queue（FIFO）適用場景：");
        System.out.println("  ✓ 任務排程：先來的任務先處理");
        System.out.println("  ✓ 訊息佇列：先發送的訊息先處理");
        System.out.println("  ✓ 廣度優先搜尋（BFS）");
        System.out.println();
        System.out.println("PriorityQueue 適用場景：");
        System.out.println("  ✓ 任務優先權：VIP 先處理");
        System.out.println("  ✓ Top N 問題：找出前 N 大/小的元素");
        System.out.println("  ✓ 排程演算法：最短工作優先");

        System.out.println("\n=== Demo 結束 ===");
    }
}
