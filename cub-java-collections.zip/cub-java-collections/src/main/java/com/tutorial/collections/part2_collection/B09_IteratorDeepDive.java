package com.tutorial.collections.part2_collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * ============================================================
 * 【章節標題】B09 - Iterator 深入解析
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 Iterator 設計模式
 * 2. 掌握 Iterator 的三個核心方法
 * 3. 理解 Fail-Fast 機制
 * 4. 學會使用 Iterator 安全地移除元素
 * 5. 認識 ListIterator 雙向迭代器
 * 
 * ============================================================
 */
public class B09_IteratorDeepDive {

    public static void main(String[] args) {
        System.out.println("=== B09: Iterator 深入解析 ===\n");

        // ============================
        // Part A: 什麼是 Iterator
        // ============================
        /*
         * Iterator 是一種設計模式（迭代器模式）
         * 
         * 目的：
         * 1. 提供統一的方式遍歷不同資料結構
         * 2. 不需要暴露底層結構（封裝）
         * 3. 可以在遍歷時安全地移除元素
         */
        System.out.println("【Part A: 什麼是 Iterator】");
        System.out.println("Iterator 是一種設計模式（迭代器模式）");
        System.out.println();
        System.out.println("優點：");
        System.out.println("  ✓ 統一的遍歷方式（ArrayList、LinkedList、HashSet...）");
        System.out.println("  ✓ 不需要知道底層結構");
        System.out.println("  ✓ 可以安全地在遍歷時移除元素");
        System.out.println();

        // ============================
        // Part B: Iterator 核心方法
        // ============================
        /*
         * Iterator<E> 介面的三個核心方法：
         * 1. boolean hasNext()：是否還有下一個元素
         * 2. E next()：回傳下一個元素，並移動游標
         * 3. void remove()：移除 next() 最後回傳的元素
         */
        System.out.println("【Part B: Iterator 核心方法】");
        System.out.println("1. hasNext()：是否還有下一個元素");
        System.out.println("2. next()：回傳下一個元素，移動游標");
        System.out.println("3. remove()：移除最後一次 next() 回傳的元素");
        System.out.println();

        // ============================
        // Part C: 基本遍歷
        // ============================
        System.out.println("【Part C: 基本遍歷】");
        
        List<String> list = Arrays.asList("A", "B", "C", "D");
        
        Iterator<String> it = list.iterator();
        System.out.print("使用 Iterator 遍歷: ");
        while (it.hasNext()) {
            String element = it.next();
            System.out.print(element + " ");
        }
        System.out.println();
        System.out.println();

        // ============================
        // Part D: Iterator 的特性
        // ============================
        /*
         * Iterator 的重要特性：
         * 1. 單向性：只能往前，不能往後
         * 2. 一次性：遍歷完後需要重新取得 Iterator
         */
        System.out.println("【Part D: Iterator 的特性】");
        System.out.println("1. 單向性：只能往前，沒有 previous()");
        System.out.println("2. 一次性：遍歷完後 hasNext() 永遠 false");
        System.out.println();
        
        // 展示一次性
        Iterator<String> it2 = list.iterator();
        while (it2.hasNext()) {
            it2.next();  // 遍歷完
        }
        System.out.println("遍歷完後 hasNext() = " + it2.hasNext());
        System.out.println("需要重新取得 Iterator：list.iterator()");
        System.out.println();

        // ============================
        // Part E: 使用 Iterator 安全移除元素
        // ============================
        System.out.println("【Part E: 使用 Iterator 安全移除元素】");
        
        List<String> mutableList = new ArrayList<>(Arrays.asList("A", "B", "C", "B", "D"));
        System.out.println("原始 List: " + mutableList);
        System.out.println("目標：移除所有 \"B\"");
        System.out.println();
        
        // 使用 Iterator.remove()（正確方式）
        Iterator<String> iter = mutableList.iterator();
        while (iter.hasNext()) {
            if (iter.next().equals("B")) {
                iter.remove();  // 使用 Iterator 的 remove() 是安全的
            }
        }
        System.out.println("使用 Iterator.remove() 後: " + mutableList);
        System.out.println();

        // ============================
        // Part F: Fail-Fast 機制
        // ============================
        /*
         * Fail-Fast：
         * 如果在迭代過程中，集合被「其他方式」修改，
         * 會拋出 ConcurrentModificationException
         * 
         * 「其他方式」指：
         * - 直接呼叫 list.remove()
         * - 在 for-each 中呼叫 list.add()
         */
        System.out.println("【Part F: Fail-Fast 機制】");
        
        List<String> failFastList = new ArrayList<>(Arrays.asList("A", "B", "C"));
        
        System.out.println("❌ 錯誤示範：在 for-each 中直接 remove()");
        System.out.println("程式碼：");
        System.out.println("  for (String s : list) {");
        System.out.println("      if (s.equals(\"B\")) {");
        System.out.println("          list.remove(s);  // ← 錯誤！");
        System.out.println("      }");
        System.out.println("  }");
        System.out.println();
        
        try {
            for (String s : failFastList) {
                if (s.equals("B")) {
                    failFastList.remove(s);  // ConcurrentModificationException!
                }
            }
        } catch (java.util.ConcurrentModificationException e) {
            System.out.println("結果：拋出 ConcurrentModificationException！");
        }
        System.out.println();
        
        System.out.println("✓ 正確方式：使用 Iterator.remove()");
        System.out.println("✓ 或者使用 Java 8+ 的 removeIf()");
        System.out.println();

        // ============================
        // Part G: Java 8+ removeIf
        // ============================
        System.out.println("【Part G: Java 8+ removeIf】");
        
        List<Integer> numbers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6));
        System.out.println("原始: " + numbers);
        
        numbers.removeIf(n -> n % 2 == 0);  // 移除偶數
        System.out.println("removeIf(n -> n % 2 == 0) 後: " + numbers);
        System.out.println();

        // ============================
        // Part H: ListIterator（雙向迭代器）
        // ============================
        /*
         * ListIterator 是 List 專用的迭代器，提供更多功能：
         * - 雙向遍歷：hasPrevious(), previous()
         * - 取得索引：nextIndex(), previousIndex()
         * - 修改元素：set(E e)
         * - 新增元素：add(E e)
         */
        System.out.println("【Part H: ListIterator（雙向迭代器）】");
        
        List<String> letters = new ArrayList<>(Arrays.asList("A", "B", "C"));
        ListIterator<String> listIt = letters.listIterator();
        
        System.out.println("List: " + letters);
        System.out.println();
        
        // 往前遍歷
        System.out.println("往前遍歷：");
        while (listIt.hasNext()) {
            int index = listIt.nextIndex();
            String value = listIt.next();
            System.out.println("  index " + index + ": " + value);
        }
        
        // 往後遍歷
        System.out.println("\n往後遍歷：");
        while (listIt.hasPrevious()) {
            int index = listIt.previousIndex();
            String value = listIt.previous();
            System.out.println("  index " + index + ": " + value);
        }
        System.out.println();
        
        // set：修改剛遍歷的元素
        listIt.next();  // 移動到 A
        listIt.set("X");  // 把 A 改成 X
        System.out.println("set(\"X\") 後: " + letters);
        
        // add：在當前位置插入
        listIt.add("Y");  // 在 X 後面插入 Y
        System.out.println("add(\"Y\") 後: " + letters);

        System.out.println("\n=== Demo 結束 ===");
    }
}
