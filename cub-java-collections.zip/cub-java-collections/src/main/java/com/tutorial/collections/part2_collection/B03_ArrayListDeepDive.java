package com.tutorial.collections.part2_collection;

import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】B03 - ArrayList 深入解析
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 ArrayList 的底層結構（Object[]）
 * 2. 理解動態擴容機制
 * 3. 掌握適用場景與效能特性
 * 4. 認識 Auto Boxing
 * 
 * ============================================================
 */
public class B03_ArrayListDeepDive {

    public static void main(String[] args) {
        System.out.println("=== B03: ArrayList 深入解析 ===\n");

        // ============================
        // 1. ArrayList 底層結構
        // ============================
        /*
         * ArrayList 底層是一個 Object[] 陣列。
         * 
         * 簡化的內部結構：
         * public class ArrayList<E> {
         *     transient Object[] elementData;  // 儲存元素的陣列
         *     private int size;                 // 實際元素數量
         * }
         * 
         * 注意：
         * - elementData.length 是容量（capacity）
         * - size 是實際元素數量
         * - size <= capacity
         */
        System.out.println("【1. ArrayList 底層結構】");
        System.out.println("ArrayList 內部使用 Object[] 陣列儲存元素");
        System.out.println();
        System.out.println("簡化結構：");
        System.out.println("  Object[] elementData;  // 儲存元素");
        System.out.println("  int size;              // 實際元素數量");
        System.out.println();
        System.out.println("capacity（容量）vs size（大小）：");
        System.out.println("  capacity = elementData.length（陣列長度）");
        System.out.println("  size = 實際元素數量");
        System.out.println("  size <= capacity");
        System.out.println();

        // ============================
        // 2. 初始容量
        // ============================
        /*
         * ArrayList 的預設初始容量是 10。
         * 
         * 三種建構方式：
         * 1. new ArrayList<>()        → 延遲初始化，第一次 add 時分配容量 10
         * 2. new ArrayList<>(20)      → 指定初始容量 20
         * 3. new ArrayList<>(另一個Collection)  → 複製另一個集合
         */
        System.out.println("【2. 初始容量】");
        
        List<String> list1 = new ArrayList<>();       // 預設，延遲到第一次 add
        List<String> list2 = new ArrayList<>(20);     // 指定容量
        List<String> list3 = new ArrayList<>(list1);  // 從另一個集合建立
        
        System.out.println("new ArrayList<>()       → 預設容量 10（延遲初始化）");
        System.out.println("new ArrayList<>(20)     → 指定初始容量 20");
        System.out.println("new ArrayList<>(list)   → 複製另一個集合");
        System.out.println();
        System.out.println("💡 效能提示：如果知道大概需要多少元素，");
        System.out.println("   預先指定容量可以減少擴容次數！");
        System.out.println();

        // ============================
        // 3. 動態擴容機制
        // ============================
        /*
         * 當元素數量超過容量時，ArrayList 會自動擴容。
         * 
         * 擴容公式（Java 8+）：
         * newCapacity = oldCapacity + (oldCapacity >> 1)
         *             = oldCapacity * 1.5
         * 
         * 擴容過程：
         * 1. 計算新容量（約 1.5 倍）
         * 2. 建立新的更大陣列
         * 3. 複製舊陣列內容到新陣列（System.arraycopy）
         * 4. 舊陣列等待 GC 回收
         * 
         * 擴容是 O(n) 操作，但因為是均攤，add() 均攤是 O(1)
         */
        System.out.println("【3. 動態擴容機制】");
        System.out.println("擴容公式：newCapacity = oldCapacity * 1.5");
        System.out.println();
        System.out.println("擴容過程：");
        System.out.println("  1. 計算新容量（約 1.5 倍）");
        System.out.println("  2. 建立新的更大陣列");
        System.out.println("  3. 複製舊內容到新陣列");
        System.out.println("  4. 舊陣列等待 GC 回收");
        System.out.println();
        System.out.println("容量增長示例（從 10 開始）：");
        System.out.println("  10 → 15 → 22 → 33 → 49 → 73 → 109 → ...");
        System.out.println();

        // ============================
        // 4. Auto Boxing 展示
        // ============================
        /*
         * Collection 只能存放物件，不能存放基本類型。
         * 
         * Auto Boxing：基本類型 → 包裝類別（自動）
         * Auto Unboxing：包裝類別 → 基本類型（自動）
         * 
         * list.add(1)  等同於  list.add(Integer.valueOf(1))
         * int n = list.get(0)  等同於  int n = list.get(0).intValue()
         */
        System.out.println("【4. Auto Boxing 展示】");
        
        List<Integer> numbers = new ArrayList<>();
        
        // Auto Boxing: int → Integer
        numbers.add(1);   // 等同於 numbers.add(Integer.valueOf(1))
        numbers.add(2);
        numbers.add(3);
        
        System.out.println("numbers.add(1);  // int 自動裝箱為 Integer");
        System.out.println("List: " + numbers);
        
        // Auto Unboxing: Integer → int
        int first = numbers.get(0);  // 等同於 numbers.get(0).intValue()
        System.out.println("\nint first = numbers.get(0);  // Integer 自動拆箱為 int");
        System.out.println("first = " + first);
        
        // 計算總和（展示 Unboxing）
        int sum = 0;
        for (int n : numbers) {  // 每次迭代都會 Unboxing
            sum += n;
        }
        System.out.println("\n迴圈中的 Unboxing：for (int n : numbers)");
        System.out.println("總和 = " + sum);
        System.out.println();

        // ============================
        // 5. 效能特性
        // ============================
        /*
         * ArrayList 效能特性：
         * 
         * | 操作              | 時間複雜度       | 說明                      |
         * |-------------------|-----------------|---------------------------|
         * | get(index)        | O(1)            | 隨機訪問，直接計算位址    |
         * | set(index, e)     | O(1)            | 直接替換                  |
         * | add(e)            | O(1) 均攤       | 尾部新增，偶爾擴容        |
         * | add(index, e)     | O(n)            | 需要移動後面的元素        |
         * | remove(index)     | O(n)            | 需要移動後面的元素        |
         * | contains(o)       | O(n)            | 需要遍歷                  |
         * | indexOf(o)        | O(n)            | 需要遍歷                  |
         */
        System.out.println("【5. 效能特性】");
        System.out.println();
        System.out.println("┌─────────────────┬──────────────┬───────────────────────┐");
        System.out.println("│      操作       │  時間複雜度  │         說明          │");
        System.out.println("├─────────────────┼──────────────┼───────────────────────┤");
        System.out.println("│ get(index)      │ O(1)         │ 隨機訪問              │");
        System.out.println("│ set(index, e)   │ O(1)         │ 直接替換              │");
        System.out.println("│ add(e)          │ O(1) 均攤    │ 尾部新增              │");
        System.out.println("│ add(index, e)   │ O(n)         │ 需移動後面元素        │");
        System.out.println("│ remove(index)   │ O(n)         │ 需移動後面元素        │");
        System.out.println("│ contains(o)     │ O(n)         │ 需遍歷                │");
        System.out.println("└─────────────────┴──────────────┴───────────────────────┘");
        System.out.println();

        // ============================
        // 6. 適用場景
        // ============================
        System.out.println("【6. 適用場景】");
        System.out.println();
        System.out.println("✅ 適合使用 ArrayList 的場景：");
        System.out.println("   • 頻繁使用 get(index) 隨機訪問");
        System.out.println("   • 主要在尾部新增元素");
        System.out.println("   • 較少在中間插入或刪除");
        System.out.println();
        System.out.println("❌ 不適合使用 ArrayList 的場景：");
        System.out.println("   • 頻繁在頭部或中間插入元素");
        System.out.println("   • 頻繁刪除元素");
        System.out.println("   → 這些場景考慮使用 LinkedList");

        System.out.println("\n=== Demo 結束 ===");
    }
}
