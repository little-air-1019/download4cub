package com.tutorial.collections.part2_collection;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】B10 - Iterable 與 for-each
 * ============================================================
 * 
 * 【學習目標】
 * 1. 理解 Iterable 介面
 * 2. 了解 for-each 是語法糖
 * 3. 學會自訂類別實作 Iterable
 * 4. 認識 Java 8+ forEach 方法
 * 
 * ============================================================
 */
public class B10_IterableAndForEach {

    public static void main(String[] args) {
        System.out.println("=== B10: Iterable 與 for-each ===\n");

        // ============================
        // Part A: Iterable 介面
        // ============================
        /*
         * Iterable<E> 介面只有一個抽象方法：
         * - Iterator<E> iterator()
         * 
         * 所有 Collection 都實作 Iterable，所以都可以用 for-each。
         * 
         * 繼承關係：
         * Iterable<E>
         *     └── Collection<E>
         *           ├── List<E>
         *           ├── Set<E>
         *           └── Queue<E>
         */
        System.out.println("【Part A: Iterable 介面】");
        System.out.println("Iterable<E> 只有一個方法：Iterator<E> iterator()");
        System.out.println();
        System.out.println("繼承關係：");
        System.out.println("  Iterable<E>");
        System.out.println("      └── Collection<E>");
        System.out.println("            ├── List<E>");
        System.out.println("            ├── Set<E>");
        System.out.println("            └── Queue<E>");
        System.out.println();
        System.out.println("所有 Collection 都可以用 for-each！");
        System.out.println();

        // ============================
        // Part B: for-each 是語法糖
        // ============================
        /*
         * for-each 語法：
         *   for (Type item : collection) { ... }
         * 
         * 編譯器會轉換成：
         *   Iterator<Type> it = collection.iterator();
         *   while (it.hasNext()) {
         *       Type item = it.next();
         *       ...
         *   }
         */
        System.out.println("【Part B: for-each 是語法糖】");
        System.out.println();
        
        List<String> list = Arrays.asList("A", "B", "C");
        
        System.out.println("for-each 寫法：");
        System.out.println("  for (String item : list) {");
        System.out.println("      System.out.println(item);");
        System.out.println("  }");
        System.out.println();
        
        System.out.println("編譯後等同於：");
        System.out.println("  Iterator<String> it = list.iterator();");
        System.out.println("  while (it.hasNext()) {");
        System.out.println("      String item = it.next();");
        System.out.println("      System.out.println(item);");
        System.out.println("  }");
        System.out.println();
        
        // 實際執行
        System.out.println("執行結果：");
        for (String item : list) {
            System.out.println("  " + item);
        }
        System.out.println();

        // ============================
        // Part C: 自訂類別實作 Iterable
        // ============================
        System.out.println("【Part C: 自訂類別實作 Iterable】");
        System.out.println();
        
        // NumberRange 是自訂類別，實作了 Iterable
        NumberRange range = new NumberRange(1, 5);
        
        System.out.println("NumberRange(1, 5) 實作 Iterable<Integer>：");
        System.out.print("  for-each 遍歷: ");
        for (int num : range) {  // 可以使用 for-each！
            System.out.print(num + " ");
        }
        System.out.println();
        System.out.println();

        // ============================
        // Part D: Java 8+ forEach 方法
        // ============================
        /*
         * Iterable 介面新增了 default 方法：
         *   void forEach(Consumer<? super T> action)
         * 
         * 可以搭配 Lambda 使用：
         *   list.forEach(item -> System.out.println(item));
         *   list.forEach(System.out::println);  // Method Reference
         */
        System.out.println("【Part D: Java 8+ forEach 方法】");
        System.out.println();
        
        List<String> fruits = Arrays.asList("Apple", "Banana", "Cherry");
        
        // 使用 Lambda
        System.out.println("forEach + Lambda：");
        System.out.print("  ");
        fruits.forEach(item -> System.out.print(item + " "));
        System.out.println();
        System.out.println();
        
        // 使用 Method Reference
        System.out.println("forEach + Method Reference：");
        System.out.println("  fruits.forEach(System.out::println)");
        fruits.forEach(item -> System.out.println("  " + item));
        System.out.println();

        // ============================
        // Part E: for-each 的限制
        // ============================
        System.out.println("【Part E: for-each 的限制】");
        System.out.println();
        System.out.println("1. 無法在遍歷時修改集合");
        System.out.println("   → 會拋出 ConcurrentModificationException");
        System.out.println("   → 解決：使用 Iterator.remove() 或 removeIf()");
        System.out.println();
        System.out.println("2. 無法取得當前索引");
        System.out.println("   → 解決：使用傳統 for 迴圈或 IntStream");
        System.out.println();
        System.out.println("3. 只能向前遍歷");
        System.out.println("   → 解決：使用 ListIterator");
        System.out.println();

        // ============================
        // Part F: 陣列也可以用 for-each
        // ============================
        System.out.println("【Part F: 陣列也可以用 for-each】");
        System.out.println();
        
        int[] numbers = {1, 2, 3, 4, 5};
        
        System.out.print("int[] 使用 for-each: ");
        for (int n : numbers) {
            System.out.print(n + " ");
        }
        System.out.println();
        System.out.println();
        System.out.println("注意：陣列不是 Iterable，for-each 對陣列是特殊處理");

        System.out.println("\n=== Demo 結束 ===");
    }
}

// ============================
// 自訂類別：實作 Iterable
// ============================
class NumberRange implements Iterable<Integer> {
    private final int start;
    private final int end;

    public NumberRange(int start, int end) {
        this.start = start;
        this.end = end;
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>() {
            private int current = start;

            @Override
            public boolean hasNext() {
                return current <= end;
            }

            @Override
            public Integer next() {
                return current++;
            }
        };
    }
}
