package com.tutorial.collections.part3_map;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

/**
 * ============================================================
 * 【章節標題】C04 - TreeMap 有序 Map
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 TreeMap 的紅黑樹結構
 * 2. 掌握 TreeMap 的排序特性
 * 3. 學會 TreeMap 的導航方法
 * 
 * ============================================================
 */
public class C04_TreeMapDemo {

    public static void main(String[] args) {
        System.out.println("=== C04: TreeMap 有序 Map ===\n");

        // ============================
        // 1. TreeMap 底層結構
        // ============================
        /*
         * TreeMap 底層是紅黑樹（Red-Black Tree）
         * 
         * 特性：
         * - Key 自動排序
         * - 不允許 null key
         * - O(log n) 的 get/put/remove
         */
        System.out.println("【1. TreeMap 底層結構】");
        System.out.println("TreeMap 使用紅黑樹儲存");
        System.out.println();
        System.out.println("特性：");
        System.out.println("  ✓ Key 自動排序");
        System.out.println("  ✗ 不允許 null key");
        System.out.println("  ✓ get/put/remove 都是 O(log n)");
        System.out.println();

        // ============================
        // 2. 自動排序（自然順序）
        // ============================
        System.out.println("【2. 自動排序（自然順序）】");
        
        Map<String, Integer> scores = new TreeMap<>();
        scores.put("Charlie", 78);
        scores.put("Alice", 85);
        scores.put("Bob", 92);
        scores.put("David", 88);
        
        System.out.println("加入順序: Charlie, Alice, Bob, David");
        System.out.println("TreeMap: " + scores);
        System.out.println("（依 key 字典序排列）");
        System.out.println();
        
        // Integer key
        Map<Integer, String> nums = new TreeMap<>();
        nums.put(3, "Three");
        nums.put(1, "One");
        nums.put(4, "Four");
        nums.put(2, "Two");
        
        System.out.println("Integer key: " + nums);
        System.out.println("（依數值大小排列）");
        System.out.println();

        // ============================
        // 3. 自訂排序
        // ============================
        System.out.println("【3. 自訂排序（Comparator）】");
        
        // 降序排列
        Map<String, Integer> descMap = new TreeMap<>(Comparator.reverseOrder());
        descMap.put("Alice", 85);
        descMap.put("Bob", 92);
        descMap.put("Charlie", 78);
        
        System.out.println("Comparator.reverseOrder():");
        System.out.println("TreeMap: " + descMap);
        System.out.println();
        
        // 依字串長度排序
        Map<String, Integer> byLength = new TreeMap<>(Comparator.comparingInt(String::length));
        byLength.put("A", 1);
        byLength.put("BBB", 3);
        byLength.put("CC", 2);
        
        System.out.println("依字串長度排序:");
        System.out.println("TreeMap: " + byLength);
        System.out.println("⚠️ 長度相同會被視為相同 key！");
        System.out.println();

        // ============================
        // 4. TreeMap 不允許 null key
        // ============================
        System.out.println("【4. TreeMap 不允許 null key】");
        System.out.println();
        System.out.println("TreeMap 不允許 null key（因為無法比較）");
        System.out.println("嘗試 put(null, value) 會拋出 NullPointerException");
        System.out.println();

        // ============================
        // 5. TreeMap 導航方法
        // ============================
        System.out.println("【5. TreeMap 導航方法】");
        
        TreeMap<Integer, String> navMap = new TreeMap<>();
        navMap.put(10, "Ten");
        navMap.put(20, "Twenty");
        navMap.put(30, "Thirty");
        navMap.put(40, "Forty");
        navMap.put(50, "Fifty");
        
        System.out.println("TreeMap: " + navMap);
        System.out.println();
        
        System.out.println("firstKey() = " + navMap.firstKey());
        System.out.println("lastKey() = " + navMap.lastKey());
        System.out.println();
        
        System.out.println("lowerKey(30) = " + navMap.lowerKey(30));    // < 30 的最大
        System.out.println("higherKey(30) = " + navMap.higherKey(30));  // > 30 的最小
        System.out.println("floorKey(25) = " + navMap.floorKey(25));    // <= 25 的最大
        System.out.println("ceilingKey(25) = " + navMap.ceilingKey(25)); // >= 25 的最小
        System.out.println();

        // ============================
        // 6. 範圍操作
        // ============================
        System.out.println("【6. 範圍操作】");
        
        System.out.println("headMap(30) = " + navMap.headMap(30));           // < 30
        System.out.println("tailMap(30) = " + navMap.tailMap(30));           // >= 30
        System.out.println("subMap(20, 40) = " + navMap.subMap(20, 40));     // [20, 40)
        System.out.println("subMap(20, true, 40, true) = " + navMap.subMap(20, true, 40, true)); // [20, 40]
        System.out.println();

        // ============================
        // 7. HashMap vs TreeMap
        // ============================
        System.out.println("【7. HashMap vs TreeMap】");
        System.out.println();
        System.out.println("┌─────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│      特性       │    HashMap      │    TreeMap      │");
        System.out.println("├─────────────────┼─────────────────┼─────────────────┤");
        System.out.println("│ 底層結構        │ Hash Table      │ 紅黑樹          │");
        System.out.println("│ 是否排序        │ 否              │ 是              │");
        System.out.println("│ null key        │ 允許一個        │ 不允許          │");
        System.out.println("│ get/put         │ O(1) 平均       │ O(log n)        │");
        System.out.println("│ 範圍查詢        │ 不支援          │ 支援            │");
        System.out.println("│ key 要求        │ equals/hashCode │ Comparable/ator │");
        System.out.println("└─────────────────┴─────────────────┴─────────────────┘");
        System.out.println();
        System.out.println("選擇建議：");
        System.out.println("  • 需要排序或範圍查詢 → TreeMap");
        System.out.println("  • 其他情況 → HashMap（效能較好）");

        System.out.println("\n=== Demo 結束 ===");
    }
}
