package com.tutorial.collections.part2_collection;

import java.util.LinkedList;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】B04 - LinkedList 特性與使用場景
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 LinkedList 的雙向鏈結串列結構
 * 2. 認識 LinkedList 同時實作 List 和 Deque
 * 3. 掌握 LinkedList 的效能特性與適用場景
 * 4. 學會 LinkedList 的特有方法
 * 
 * ============================================================
 */
public class B04_LinkedListDemo {

    public static void main(String[] args) {
        System.out.println("=== B04: LinkedList 特性與使用場景 ===\n");

        // ============================
        // 1. LinkedList 底層結構
        // ============================
        /*
         * LinkedList 是雙向鏈結串列（Doubly Linked List）。
         * 
         * 節點結構：
         * class Node<E> {
         *     E item;        // 儲存的元素
         *     Node<E> next;  // 指向下一個節點
         *     Node<E> prev;  // 指向上一個節點
         * }
         * 
         * 示意圖：
         * null ← [A] ⇄ [B] ⇄ [C] ⇄ [D] → null
         *         ↑                   ↑
         *       first               last
         */
        System.out.println("【1. LinkedList 底層結構】");
        System.out.println("LinkedList 是雙向鏈結串列");
        System.out.println();
        System.out.println("節點結構：");
        System.out.println("  E item;        // 儲存的元素");
        System.out.println("  Node<E> next;  // 指向下一個節點");
        System.out.println("  Node<E> prev;  // 指向上一個節點");
        System.out.println();
        System.out.println("示意圖：");
        System.out.println("  null ← [A] ⇄ [B] ⇄ [C] ⇄ [D] → null");
        System.out.println("          ↑                   ↑");
        System.out.println("        first               last");
        System.out.println();

        // ============================
        // 2. 同時實作 List 和 Deque
        // ============================
        /*
         * LinkedList 實作了兩個介面：
         * - List<E>：有序、可重複、可用 index
         * - Deque<E>：雙端佇列（Double-ended Queue）
         * 
         * 因此可以用作：
         * - 普通的 List
         * - Stack（LIFO）
         * - Queue（FIFO）
         */
        System.out.println("【2. 同時實作 List 和 Deque】");
        System.out.println("LinkedList implements List<E>, Deque<E>");
        System.out.println();
        System.out.println("可用作：");
        System.out.println("  ✓ 普通 List");
        System.out.println("  ✓ Stack（LIFO：後進先出）");
        System.out.println("  ✓ Queue（FIFO：先進先出）");
        System.out.println();

        // ============================
        // 3. 基本使用（作為 List）
        // ============================
        System.out.println("【3. 基本使用（作為 List）】");
        
        List<String> list = new LinkedList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");
        
        System.out.println("List: " + list);
        System.out.println("get(1) = " + list.get(1));
        System.out.println();

        // ============================
        // 4. Deque 特有方法（頭尾操作）
        // ============================
        System.out.println("【4. Deque 特有方法（頭尾操作）】");
        
        LinkedList<String> deque = new LinkedList<>();
        
        // 新增元素
        deque.addFirst("First");    // 加到頭部
        deque.addLast("Last");      // 加到尾部
        System.out.println("addFirst(\"First\"), addLast(\"Last\")");
        System.out.println("List: " + deque);
        
        deque.add("Middle");        // 預設加到尾部
        deque.addFirst("New First");
        System.out.println("add(\"Middle\"), addFirst(\"New First\")");
        System.out.println("List: " + deque);
        System.out.println();
        
        // 取得元素
        System.out.println("getFirst() = " + deque.getFirst());
        System.out.println("getLast() = " + deque.getLast());
        System.out.println();
        
        // 移除元素
        String removedFirst = deque.removeFirst();
        String removedLast = deque.removeLast();
        System.out.println("removeFirst() = " + removedFirst);
        System.out.println("removeLast() = " + removedLast);
        System.out.println("List: " + deque);
        System.out.println();

        // ============================
        // 5. 作為 Stack（LIFO）
        // ============================
        /*
         * Stack 使用：
         * - push(e)：加入元素（等同 addFirst）
         * - pop()：移除並回傳頂端元素（等同 removeFirst）
         * - peek()：查看頂端元素但不移除（等同 getFirst）
         */
        System.out.println("【5. 作為 Stack（LIFO）】");
        
        LinkedList<String> stack = new LinkedList<>();
        
        stack.push("Bottom");
        stack.push("Middle");
        stack.push("Top");
        System.out.println("push: Bottom → Middle → Top");
        System.out.println("Stack: " + stack);
        
        System.out.println("peek() = " + stack.peek());  // 查看頂端
        System.out.println("pop() = " + stack.pop());    // 彈出頂端
        System.out.println("Stack after pop: " + stack);
        System.out.println();

        // ============================
        // 6. 作為 Queue（FIFO）
        // ============================
        /*
         * Queue 使用：
         * - offer(e)：加入元素到尾端（等同 addLast）
         * - poll()：移除並回傳頭部元素（等同 removeFirst）
         * - peek()：查看頭部元素但不移除（等同 getFirst）
         */
        System.out.println("【6. 作為 Queue（FIFO）】");
        
        LinkedList<String> queue = new LinkedList<>();
        
        queue.offer("First in line");
        queue.offer("Second in line");
        queue.offer("Third in line");
        System.out.println("offer: First → Second → Third");
        System.out.println("Queue: " + queue);
        
        System.out.println("peek() = " + queue.peek());  // 查看頭部
        System.out.println("poll() = " + queue.poll());  // 取出頭部
        System.out.println("Queue after poll: " + queue);
        System.out.println();

        // ============================
        // 7. 效能特性
        // ============================
        /*
         * LinkedList 效能特性：
         * 
         * | 操作              | 時間複雜度 | 說明                        |
         * |-------------------|-----------|----------------------------|
         * | get(index)        | O(n)      | 需要從頭或尾遍歷            |
         * | addFirst/Last()   | O(1)      | 直接操作頭尾指標            |
         * | removeFirst/Last()| O(1)      | 直接操作頭尾指標            |
         * | add(index, e)     | O(n)      | 先找到位置，插入本身 O(1)   |
         * | remove(index)     | O(n)      | 先找到位置，移除本身 O(1)   |
         * | contains(o)       | O(n)      | 需要遍歷                    |
         */
        System.out.println("【7. 效能特性】");
        System.out.println();
        System.out.println("┌──────────────────┬──────────────┬────────────────────────┐");
        System.out.println("│       操作       │  時間複雜度  │          說明          │");
        System.out.println("├──────────────────┼──────────────┼────────────────────────┤");
        System.out.println("│ get(index)       │ O(n)         │ 需從頭或尾遍歷         │");
        System.out.println("│ addFirst/Last()  │ O(1)         │ 直接操作指標           │");
        System.out.println("│ removeFirst/Last()│ O(1)        │ 直接操作指標           │");
        System.out.println("│ add(index, e)    │ O(n)         │ 找位置 O(n)，插入 O(1) │");
        System.out.println("│ contains(o)      │ O(n)         │ 需要遍歷               │");
        System.out.println("└──────────────────┴──────────────┴────────────────────────┘");
        System.out.println();

        // ============================
        // 8. ArrayList vs LinkedList
        // ============================
        System.out.println("【8. ArrayList vs LinkedList】");
        System.out.println();
        System.out.println("┌─────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│      特性       │   ArrayList     │   LinkedList    │");
        System.out.println("├─────────────────┼─────────────────┼─────────────────┤");
        System.out.println("│ 底層結構        │ 動態陣列        │ 雙向鏈結串列    │");
        System.out.println("│ get(index)      │ O(1) ✓          │ O(n)            │");
        System.out.println("│ add(尾端)       │ O(1) 均攤       │ O(1)            │");
        System.out.println("│ add(頭部)       │ O(n)            │ O(1) ✓          │");
        System.out.println("│ remove(頭部)    │ O(n)            │ O(1) ✓          │");
        System.out.println("│ 記憶體使用      │ 較省            │ 較多（含指標）  │");
        System.out.println("└─────────────────┴─────────────────┴─────────────────┘");
        System.out.println();
        System.out.println("選擇建議：");
        System.out.println("  ✓ 大多數場景：ArrayList（隨機訪問快）");
        System.out.println("  ✓ 頻繁頭尾操作：LinkedList（Stack/Queue 場景）");

        System.out.println("\n=== Demo 結束 ===");
    }
}
