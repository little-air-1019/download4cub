package com.tutorial.collections.part2_collection;

import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】B02 - List 介面
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 List 介面的核心特性：有序、可重複、可用 index
 * 2. 掌握 List 的常用方法
 * 3. 認識 Generics 與 Diamond 語法
 * 
 * ============================================================
 */
public class B02_ListInterface {

    public static void main(String[] args) {
        System.out.println("=== B02: List 介面 ===\n");

        // ============================
        // 1. List 核心特性
        // ============================
        /*
         * List 的三大特性：
         * 1. 有序（Ordered）：加入順序 = 取出順序
         * 2. 可重複（Duplicates Allowed）：同一元素可加入多次
         * 3. 可用 index 存取（Index-based Access）：類似陣列
         */
        System.out.println("【1. List 核心特性】");
        System.out.println("  ✓ 有序：加入順序 = 取出順序");
        System.out.println("  ✓ 可重複：同一元素可加入多次");
        System.out.println("  ✓ 可用 index：list.get(0), list.set(1, value)");
        System.out.println();

        // ============================
        // 2. 建立 List（Diamond 語法）
        // ============================
        /*
         * 【Diamond 語法】<>
         * Java 7 之前：List<String> list = new ArrayList<String>();
         * Java 7 之後：List<String> list = new ArrayList<>(); // 編譯器推斷型態
         * 
         * <>（鑽石符號）讓編譯器自動推斷泛型型態
         */
        System.out.println("【2. 建立 List（Diamond 語法）】");
        
        // 推薦寫法：面向介面 + Diamond 語法
        List<String> fruits = new ArrayList<>();  // Diamond 語法 <>
        
        System.out.println("List<String> fruits = new ArrayList<>();");
        System.out.println("  └─ Diamond 語法：<> 讓編譯器自動推斷型態");
        System.out.println();

        // ============================
        // 3. 新增元素 - add()
        // ============================
        System.out.println("【3. 新增元素 - add()】");
        
        fruits.add("Apple");      // 加到尾端
        fruits.add("Banana");
        fruits.add("Cherry");
        System.out.println("add(\"Apple\"), add(\"Banana\"), add(\"Cherry\")");
        System.out.println("List: " + fruits);
        
        fruits.add(1, "Blueberry");  // 插入到指定位置
        System.out.println("add(1, \"Blueberry\") - 插入到 index 1");
        System.out.println("List: " + fruits);
        System.out.println();

        // ============================
        // 4. 取得元素 - get()
        // ============================
        System.out.println("【4. 取得元素 - get()】");
        
        String first = fruits.get(0);
        String second = fruits.get(1);
        System.out.println("fruits.get(0) = " + first);
        System.out.println("fruits.get(1) = " + second);
        System.out.println();

        // ============================
        // 5. 修改元素 - set()
        // ============================
        System.out.println("【5. 修改元素 - set()】");
        
        System.out.println("修改前: " + fruits);
        String oldValue = fruits.set(1, "Blackberry");  // 回傳被取代的值
        System.out.println("fruits.set(1, \"Blackberry\")");
        System.out.println("被取代的值: " + oldValue);
        System.out.println("修改後: " + fruits);
        System.out.println();

        // ============================
        // 6. 移除元素 - remove()
        // ============================
        System.out.println("【6. 移除元素 - remove()】");
        
        System.out.println("移除前: " + fruits);
        
        // 依索引移除
        String removed = fruits.remove(0);  // 移除第一個
        System.out.println("remove(0) → 移除了: " + removed);
        System.out.println("移除後: " + fruits);
        
        // 依物件移除
        boolean success = fruits.remove("Cherry");  // 移除第一個符合的
        System.out.println("remove(\"Cherry\") → " + success);
        System.out.println("移除後: " + fruits);
        System.out.println();

        // ============================
        // 7. 搜尋 - indexOf(), contains()
        // ============================
        System.out.println("【7. 搜尋 - indexOf(), contains()】");
        
        fruits.add("Blackberry");  // 加入重複元素
        System.out.println("目前 List: " + fruits);
        
        int index = fruits.indexOf("Blackberry");
        System.out.println("indexOf(\"Blackberry\") = " + index);
        
        int lastIndex = fruits.lastIndexOf("Blackberry");
        System.out.println("lastIndexOf(\"Blackberry\") = " + lastIndex);
        
        boolean contains = fruits.contains("Banana");
        System.out.println("contains(\"Banana\") = " + contains);
        System.out.println();

        // ============================
        // 8. 其他常用方法
        // ============================
        System.out.println("【8. 其他常用方法】");
        
        System.out.println("size() = " + fruits.size());
        System.out.println("isEmpty() = " + fruits.isEmpty());
        
        // subList：取得子列表（view，非複製）
        // subList() 方法返回的是原始列表 (fruits) 的一個視圖 (view)，而不是一個獨立的新列表。這意味著：
        // 1. fruits 列表本身不會被修改。 它仍然包含所有原始元素。
        // 2. subList 和 fruits 共享相同的底層資料。
        List<String> subList = fruits.subList(0, 2);
        System.out.println("subList(0, 2) = " + subList);
        
        // clear：清空
        fruits.clear();
        System.out.println("clear() 後 isEmpty() = " + fruits.isEmpty());
        System.out.println();

        // ============================
        // 9. 有序性展示
        // ============================
        System.out.println("【9. 有序性展示】");
        
        List<String> orderedList = new ArrayList<>();
        orderedList.add("First");
        orderedList.add("Second");
        orderedList.add("Third");
        
        System.out.println("加入順序: First → Second → Third");
        System.out.println("取出順序: " + orderedList);
        System.out.println("✓ 加入順序 = 取出順序（List 是有序的）");
        System.out.println();

        // ============================
        // 10. 可重複性展示
        // ============================
        System.out.println("【10. 可重複性展示】");
        
        List<String> duplicateList = new ArrayList<>();
        duplicateList.add("Apple");
        duplicateList.add("Apple");
        duplicateList.add("Apple");
        
        System.out.println("加入 3 次 \"Apple\"");
        System.out.println("List: " + duplicateList);
        System.out.println("size() = " + duplicateList.size());
        System.out.println("✓ List 允許重複元素");

        System.out.println("\n=== Demo 結束 ===");
    }
}
