package com.tutorial.collections.part1_array;

import java.util.Arrays;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】A03 - Arrays 工具類
 * ============================================================
 * 
 * 【學習目標】
 * 1. 掌握 java.util.Arrays 的常用方法
 * 2. 了解 Arrays.asList() 的特殊行為
 * 3. 學會使用 Arrays 簡化陣列操作
 * 
 * ============================================================
 */
public class A03_ArraysUtilityClass {

    public static void main(String[] args) {
        System.out.println("=== A03: Arrays 工具類 ===\n");

        // ============================
        // 1. Arrays.toString() - 印出陣列內容
        // ============================
        /*
         * 直接印出陣列會得到類似 [I@1b6d3586 的奇怪結果
         * Arrays.toString() 可以轉換成可讀的字串格式
         */
        System.out.println("【1. Arrays.toString()】");
        int[] numbers = {5, 2, 8, 1, 9};
        
        System.out.println("直接印出陣列: " + numbers);  // 得到記憶體位址
        System.out.println("Arrays.toString(): " + Arrays.toString(numbers));  // [5, 2, 8, 1, 9]
        
        // 二維陣列要用 deepToString
        int[][] matrix = {{1, 2}, {3, 4}, {5, 6}};
        System.out.println("二維陣列 toString: " + Arrays.toString(matrix));  // 得到內層陣列的位址
        System.out.println("二維陣列 deepToString: " + Arrays.deepToString(matrix));  // [[1, 2], [3, 4], [5, 6]]
        System.out.println();

        // ============================
        // 2. Arrays.sort() - 排序
        // ============================
        /*
         * sort() 會直接修改原陣列（in-place sorting）
         * 預設為升序排列
         * 時間複雜度：O(n log n)
         */
        System.out.println("【2. Arrays.sort()】");
        int[] scores = {85, 92, 78, 95, 88};
        System.out.println("排序前: " + Arrays.toString(scores));
        
        Arrays.sort(scores);  // 原地排序
        System.out.println("排序後: " + Arrays.toString(scores));  // [78, 85, 88, 92, 95]
        
        // 部分排序：只排序索引 1 到 3（不含 4）
        int[] partial = {5, 3, 8, 1, 9, 2};
        Arrays.sort(partial, 1, 4);  // 只排索引 1, 2, 3
        System.out.println("部分排序 (index 1-3): " + Arrays.toString(partial));  // [5, 1, 3, 8, 9, 2]
        System.out.println();

        // ============================
        // 3. Arrays.binarySearch() - 二分搜尋
        // ============================
        /*
         * ⚠️ 重要：使用前必須先排序！
         * 
         * 回傳值：
         * - 找到：回傳索引位置
         * - 找不到：回傳 -(insertion point) - 1
         */
        System.out.println("【3. Arrays.binarySearch()】");
        int[] sorted = {10, 20, 30, 40, 50};  // 已排序
        
        int index = Arrays.binarySearch(sorted, 30);
        System.out.println("搜尋 30 的索引: " + index);  // 2
        
        index = Arrays.binarySearch(sorted, 35);
        System.out.println("搜尋 35 的索引: " + index);  // -4 (表示應插入位置 3)
        System.out.println("⚠️ 注意：陣列必須先排序才能使用 binarySearch！");
        System.out.println();

        // ============================
        // 4. Arrays.fill() - 填充陣列
        // ============================
        /*
         * 將陣列的所有元素設為相同值
         * 常用於初始化陣列
         */
        System.out.println("【4. Arrays.fill()】");
        int[] filled = new int[5];
        System.out.println("填充前: " + Arrays.toString(filled));  // [0, 0, 0, 0, 0]
        
        Arrays.fill(filled, 7);
        System.out.println("fill(7) 後: " + Arrays.toString(filled));  // [7, 7, 7, 7, 7]
        
        // 部分填充
        Arrays.fill(filled, 1, 4, 0);  // 索引 1 到 3 填 0
        System.out.println("部分 fill 後: " + Arrays.toString(filled));  // [7, 0, 0, 0, 7]
        System.out.println();

        // ============================
        // 5. Arrays.copyOf() - 複製陣列
        // ============================
        /*
         * 建立陣列的副本
         * 可以指定新長度（擴展或截斷）
         */
        System.out.println("【5. Arrays.copyOf()】");
        int[] original = {1, 2, 3};
        
        int[] copy = Arrays.copyOf(original, original.length);
        System.out.println("完整複製: " + Arrays.toString(copy));  // [1, 2, 3]
        
        int[] expanded = Arrays.copyOf(original, 5);
        System.out.println("擴展複製: " + Arrays.toString(expanded));  // [1, 2, 3, 0, 0]
        
        int[] truncated = Arrays.copyOf(original, 2);
        System.out.println("截斷複製: " + Arrays.toString(truncated));  // [1, 2]
        
        // copyOfRange：複製指定範圍
        int[] range = Arrays.copyOfRange(original, 1, 3);
        System.out.println("範圍複製 (1-2): " + Arrays.toString(range));  // [2, 3]
        System.out.println();

        // ============================
        // 6. Arrays.equals() - 比較陣列內容
        // ============================
        /*
         * 比較兩個陣列的「內容」是否相同
         * 不是比較記憶體位址！
         */
        System.out.println("【6. Arrays.equals()】");
        int[] arr1 = {1, 2, 3};
        int[] arr2 = {1, 2, 3};
        int[] arr3 = {1, 2, 4};
        
        System.out.println("arr1 == arr2: " + (arr1 == arr2));  // false (不同物件)
        System.out.println("Arrays.equals(arr1, arr2): " + Arrays.equals(arr1, arr2));  // true
        System.out.println("Arrays.equals(arr1, arr3): " + Arrays.equals(arr1, arr3));  // false
        System.out.println();

        // ============================
        // 7. Arrays.asList() - 轉換為 List
        // ============================
        /*
         * ⚠️ 重要：回傳的是「固定大小」的 List！
         * - 可以 get/set，但不能 add/remove
         * - 對 List 的修改會反映到原陣列
         * 
         * 如果需要可變的 List，要用 new ArrayList<>(Arrays.asList(...))
         */
        System.out.println("【7. Arrays.asList()】");
        String[] fruits = {"Apple", "Banana", "Cherry"};
        List<String> fruitList = Arrays.asList(fruits);
        
        System.out.println("轉換後的 List: " + fruitList);
        
        // 可以修改元素
        fruitList.set(1, "Blueberry");
        System.out.println("修改後: " + fruitList);
        System.out.println("原陣列也被修改了: " + Arrays.toString(fruits));
        
        // 嘗試新增（會拋出例外）
        System.out.println("\n⚠️ Arrays.asList() 回傳的 List 是固定大小的！");
        System.out.println("呼叫 add() 或 remove() 會拋出 UnsupportedOperationException");
        
        try {
            fruitList.add("Date");
        } catch (UnsupportedOperationException e) {
            System.out.println("嘗試 add() → 拋出 " + e.getClass().getSimpleName());
        }
        
        System.out.println("\n【解決方案】使用 new ArrayList<>(Arrays.asList(...))");
        // List<String> mutableList = new ArrayList<>(Arrays.asList(fruits));
        // mutableList.add("Date");  // 這樣就可以了

        System.out.println("\n=== Demo 結束 ===");
    }
}
