package com.tutorial.collections.part3_map;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * ============================================================
 * 【章節標題】C03 - HashMap 深入解析
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 HashMap 的底層結構
 * 2. 理解 hashCode 和 equals 的重要性
 * 3. 認識 LinkedHashMap
 * 
 * ============================================================
 */
public class C03_HashMapDeepDive {

    public static void main(String[] args) {
        System.out.println("=== C03: HashMap 深入解析 ===\n");

        // ============================
        // 1. HashMap 底層結構
        // ============================
        /*
         * HashMap 內部結構（簡化說明）：
         * 
         * 1. 底層是 Node<K,V>[] 陣列（稱為 table 或 buckets）
         * 2. 預設容量 16，負載因子 0.75
         * 3. 當元素數量 > 容量 × 負載因子，會擴容為 2 倍
         * 
         * Node 結構：
         * class Node<K,V> {
         *     int hash;
         *     K key;
         *     V value;
         *     Node<K,V> next;  // 處理 collision
         * }
         */
        System.out.println("【1. HashMap 底層結構】");
        System.out.println();
        System.out.println("HashMap 內部是 Node<K,V>[] 陣列");
        System.out.println();
        System.out.println("配置參數：");
        System.out.println("  • 預設容量：16");
        System.out.println("  • 負載因子：0.75");
        System.out.println("  • 擴容時機：元素數量 > 容量 × 0.75");
        System.out.println("  • 擴容大小：2 倍");
        System.out.println();

        // ============================
        // 2. Hash 與 Bucket 原理
        // ============================
        /*
         * put(key, value) 的流程：
         * 
         * 1. 計算 hash = key.hashCode() 經過擾動函數處理
         * 2. 計算 bucket index = hash & (table.length - 1)
         * 3. 如果該 bucket 是空的，直接放入
         * 4. 如果該 bucket 有元素（Hash Collision）：
         *    - 遍歷鏈結，用 equals() 檢查是否 key 相同
         *    - 相同：更新 value
         *    - 不同：加到鏈結尾端
         * 
         * Java 8 優化：
         * 當鏈結長度 > 8 且陣列長度 >= 64，轉換為紅黑樹
         */
        System.out.println("【2. Hash 與 Bucket 原理】");
        System.out.println();
        System.out.println("put(key, value) 流程：");
        System.out.println("  1. hash = hashCode(key) 經擾動處理");
        System.out.println("  2. bucket = hash & (length - 1)");
        System.out.println("  3. 空 bucket → 直接放入");
        System.out.println("  4. 非空（Collision）→ 用 equals() 檢查");
        System.out.println();
        System.out.println("示意圖：");
        System.out.println("  [0] → null");
        System.out.println("  [1] → (K1,V1) → (K2,V2)  ← Hash Collision");
        System.out.println("  [2] → (K3,V3)");
        System.out.println("  [3] → null");
        System.out.println("  ...");
        System.out.println();
        System.out.println("Java 8+：鏈結 > 8 且陣列 >= 64 → 轉紅黑樹");
        System.out.println();

        // ============================
        // 3. 為什麼 key 要覆寫 equals/hashCode
        // ============================
        System.out.println("【3. key 必須正確覆寫 equals/hashCode】");
        
        // 錯誤示範
        Map<PersonKey, String> badMap = new HashMap<>();
        badMap.put(new PersonKey("Alice"), "Engineer");
        
        // 查找失敗！因為 PersonKey 沒有覆寫 equals/hashCode
        String result1 = badMap.get(new PersonKey("Alice"));
        System.out.println("PersonKey（未覆寫）查找結果: " + result1);
        
        // 正確示範
        Map<PersonKeyGood, String> goodMap = new HashMap<>();
        goodMap.put(new PersonKeyGood("Alice"), "Engineer");
        
        String result2 = goodMap.get(new PersonKeyGood("Alice"));
        System.out.println("PersonKeyGood（已覆寫）查找結果: " + result2);
        System.out.println();

        // ============================
        // 4. HashMap 允許 null
        // ============================
        System.out.println("【4. HashMap 允許 null】");
        
        Map<String, String> map = new HashMap<>();
        map.put(null, "null key's value");  // null key 放在 bucket[0]
        map.put("key", null);               // null value
        
        System.out.println("put(null, \"value\") → 允許！");
        System.out.println("put(\"key\", null) → 允許！");
        System.out.println("get(null) = " + map.get(null));
        System.out.println();

        // ============================
        // 5. HashMap 無序
        // ============================
        System.out.println("【5. HashMap 無序】");
        
        Map<String, Integer> unordered = new HashMap<>();
        unordered.put("One", 1);
        unordered.put("Two", 2);
        unordered.put("Three", 3);
        unordered.put("Four", 4);
        
        System.out.println("加入順序: One, Two, Three, Four");
        System.out.println("遍歷順序: " + unordered.keySet());
        System.out.println("⚠️ 順序不保證！");
        System.out.println();

        // ============================
        // 6. LinkedHashMap 保持插入順序
        // ============================
        System.out.println("【6. LinkedHashMap 保持插入順序】");
        
        Map<String, Integer> ordered = new LinkedHashMap<>();
        ordered.put("One", 1);
        ordered.put("Two", 2);
        ordered.put("Three", 3);
        ordered.put("Four", 4);
        
        System.out.println("LinkedHashMap 遍歷順序: " + ordered.keySet());
        System.out.println("✓ 維持插入順序！");
        System.out.println();

        // ============================
        // 7. 效能特性
        // ============================
        System.out.println("【7. 效能特性】");
        System.out.println();
        System.out.println("┌─────────────────┬──────────────┐");
        System.out.println("│      操作       │  時間複雜度  │");
        System.out.println("├─────────────────┼──────────────┤");
        System.out.println("│ put(k, v)       │ O(1) 平均    │");
        System.out.println("│ get(k)          │ O(1) 平均    │");
        System.out.println("│ remove(k)       │ O(1) 平均    │");
        System.out.println("│ containsKey(k)  │ O(1) 平均    │");
        System.out.println("│ containsValue(v)│ O(n)         │");
        System.out.println("└─────────────────┴──────────────┘");
        System.out.println();
        System.out.println("⚠️ 最差情況（所有元素同 bucket）：O(n) 或 O(log n)");

        System.out.println("\n=== Demo 結束 ===");
    }
}

// 未覆寫 equals/hashCode
class PersonKey {
    private String name;
    
    public PersonKey(String name) {
        this.name = name;
    }
}

// 正確覆寫 equals/hashCode
class PersonKeyGood {
    private String name;
    
    public PersonKeyGood(String name) {
        this.name = name;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PersonKeyGood that = (PersonKeyGood) o;
        return Objects.equals(name, that.name);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
