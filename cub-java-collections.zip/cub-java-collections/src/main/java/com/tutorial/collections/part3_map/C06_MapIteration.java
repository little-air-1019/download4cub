package com.tutorial.collections.part3_map;

import java.util.HashMap;
import java.util.Map;

/**
 * ============================================================
 * 【章節標題】C06 - Map 遍歷方式
 * ============================================================
 * 
 * 【學習目標】
 * 1. 掌握遍歷 Map 的各種方式
 * 2. 了解各種方式的效能差異
 * 3. 學會選擇最適合的遍歷方式
 * 
 * ============================================================
 */
public class C06_MapIteration {

    public static void main(String[] args) {
        System.out.println("=== C06: Map 遍歷方式 ===\n");

        // 準備測試資料
        Map<String, Integer> scores = new HashMap<>();
        scores.put("Alice", 85);
        scores.put("Bob", 92);
        scores.put("Charlie", 78);
        
        System.out.println("Map: " + scores);
        System.out.println();

        // ============================
        // 1. 遍歷 keySet()
        // ============================
        System.out.println("【1. 遍歷 keySet()】");
        
        System.out.println("只需要 key 時使用：");
        for (String key : scores.keySet()) {
            System.out.println("  Key: " + key);
        }
        System.out.println();
        
        System.out.println("也可以透過 key 取得 value（但效率較差）：");
        for (String key : scores.keySet()) {
            Integer value = scores.get(key);  // 額外的 get() 操作
            System.out.println("  " + key + " = " + value);
        }
        System.out.println();

        // ============================
        // 2. 遍歷 values()
        // ============================
        System.out.println("【2. 遍歷 values()】");
        
        System.out.println("只需要 value 時使用：");
        for (Integer value : scores.values()) {
            System.out.println("  Value: " + value);
        }
        System.out.println();

        // ============================
        // 3. 遍歷 entrySet()（推薦）
        // ============================
        System.out.println("【3. 遍歷 entrySet()（推薦）】");
        
        System.out.println("同時需要 key 和 value 時使用：");
        for (Map.Entry<String, Integer> entry : scores.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println("  " + key + " = " + value);
        }
        System.out.println();
        System.out.println("✓ 效能最好：不需要額外的 get() 操作");
        System.out.println();

        // ============================
        // 4. Java 8+ forEach
        // ============================
        System.out.println("【4. Java 8+ forEach】");
        
        // BiConsumer 版本
        System.out.println("map.forEach((key, value) -> { ... })：");
        scores.forEach((key, value) -> 
            System.out.println("  " + key + " = " + value)
        );
        System.out.println();
        
        // Method Reference（如果邏輯複雜可定義方法）
        System.out.println("使用 Method Reference：");
        scores.forEach(C06_MapIteration::printEntry);
        System.out.println();

        // ============================
        // 5. Java 8+ Stream
        // ============================
        System.out.println("【5. Java 8+ Stream】");
        
        // entrySet().stream()
        System.out.println("使用 Stream 過濾和轉換：");
        scores.entrySet().stream()
            .filter(entry -> entry.getValue() >= 80)
            .forEach(entry -> System.out.println("  " + entry.getKey() + " >= 80"));
        System.out.println();

        // ============================
        // 6. Iterator（可安全移除）
        // ============================
        System.out.println("【6. Iterator（可安全移除）】");
        
        Map<String, Integer> mutableMap = new HashMap<>(scores);
        System.out.println("移除前: " + mutableMap);
        
        var iterator = mutableMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            if (entry.getValue() < 80) {
                iterator.remove();  // 安全移除
            }
        }
        System.out.println("移除 < 80 後: " + mutableMap);
        System.out.println();

        // ============================
        // 7. 各種遍歷方式比較
        // ============================
        System.out.println("【7. 各種遍歷方式比較】");
        System.out.println();
        System.out.println("┌───────────────────┬──────────────┬──────────────────────────┐");
        System.out.println("│       方式        │     效能     │         適用場景         │");
        System.out.println("├───────────────────┼──────────────┼──────────────────────────┤");
        System.out.println("│ keySet()          │ 較差（需get）│ 只需要 key               │");
        System.out.println("│ values()          │ 好           │ 只需要 value             │");
        System.out.println("│ entrySet()        │ 最好 ✓       │ 同時需要 key 和 value    │");
        System.out.println("│ forEach()         │ 最好 ✓       │ Java 8+，程式碼簡潔      │");
        System.out.println("│ Stream            │ 好           │ 需要過濾、轉換等操作     │");
        System.out.println("│ Iterator          │ 好           │ 需要在遍歷中移除元素     │");
        System.out.println("└───────────────────┴──────────────┴──────────────────────────┘");
        System.out.println();

        // ============================
        // 8. 最佳實踐
        // ============================
        System.out.println("【8. 最佳實踐】");
        System.out.println();
        System.out.println("1. 同時需要 key 和 value → entrySet() 或 forEach()");
        System.out.println("2. 只需要 key → keySet()");
        System.out.println("3. 只需要 value → values()");
        System.out.println("4. 需要過濾或轉換 → Stream");
        System.out.println("5. 需要在遍歷中移除 → Iterator");
        System.out.println();
        System.out.println("❌ 避免：");
        System.out.println("for (String key : map.keySet()) {");
        System.out.println("    Integer value = map.get(key);  // 不推薦！");
        System.out.println("}");

        System.out.println("\n=== Demo 結束 ===");
    }

    private static void printEntry(String key, Integer value) {
        System.out.println("  " + key + " → " + value);
    }
}
