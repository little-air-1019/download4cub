package com.tutorial.collections.part2_collection;

import java.util.*;
import java.util.stream.Collectors;

/**
 * ============================================================
 * 【章節標題】B13 - Collection 排序方式
 * ============================================================
 * 
 * 【學習目標】
 * 1. 掌握 Collections.sort() 的使用
 * 2. 學會 List.sort() 方法
 * 3. 了解 Stream.sorted() 的不可變特性
 * 4. 認識排序穩定性與效能考量
 * 
 * ============================================================
 */
public class B13_SortingCollections {

    public static void main(String[] args) {
        System.out.println("=== B13: Collection 排序方式 ===\n");

        // ============================
        // Part A: Collections.sort()
        // ============================
        System.out.println("【Part A: Collections.sort()】");
        
        List<Integer> numbers = new ArrayList<>(Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6));
        System.out.println("原始: " + numbers);
        
        // 預設升序
        Collections.sort(numbers);
        System.out.println("Collections.sort() 後: " + numbers);
        
        // 搭配 Comparator
        Collections.sort(numbers, Comparator.reverseOrder());
        System.out.println("sort(reverseOrder()) 後: " + numbers);
        System.out.println();
        System.out.println("特點：原地排序（修改原 List），回傳 void");
        System.out.println();

        // ============================
        // Part B: List.sort()（Java 8+）
        // ============================
        System.out.println("【Part B: List.sort()（Java 8+）】");
        
        List<Integer> nums = new ArrayList<>(Arrays.asList(5, 2, 8, 1, 9));
        System.out.println("原始: " + nums);
        
        nums.sort(Comparator.naturalOrder());
        System.out.println("list.sort(naturalOrder()) 後: " + nums);
        
        nums.sort((a, b) -> b - a);  // Lambda 降序
        System.out.println("list.sort((a, b) -> b - a) 後: " + nums);
        System.out.println();
        System.out.println("特點：List 介面的 default 方法，功能與 Collections.sort() 相同");
        System.out.println();

        // ============================
        // Part C: Stream.sorted()（Java 8+）
        // ============================
        System.out.println("【Part C: Stream.sorted()（Java 8+）】");
        
        List<Integer> original = Arrays.asList(3, 1, 4, 1, 5);
        System.out.println("原始 List: " + original);
        
        // sorted() 不會修改原 List，回傳新的排序結果
        List<Integer> sorted = original.stream()
            .sorted()
            .collect(Collectors.toList());
        
        System.out.println("stream().sorted() 結果: " + sorted);
        System.out.println("原始 List（不變）: " + original);
        System.out.println();
        System.out.println("特點：函數式風格，不修改原集合，回傳新結果");
        System.out.println();

        // ============================
        // Part D: 各種排序方式比較
        // ============================
        System.out.println("【Part D: 各種排序方式比較】");
        System.out.println();
        System.out.println("┌─────────────────────┬────────────────┬─────────────┬───────────────────┐");
        System.out.println("│        方法         │ 修改原集合?    │   回傳值    │     適用場景      │");
        System.out.println("├─────────────────────┼────────────────┼─────────────┼───────────────────┤");
        System.out.println("│ Collections.sort()  │ ✓ 是           │ void        │ 傳統寫法          │");
        System.out.println("│ List.sort()         │ ✓ 是           │ void        │ Java 8+ 推薦      │");
        System.out.println("│ Stream.sorted()     │ ✗ 否           │ Stream      │ 函數式，不改原集合│");
        System.out.println("└─────────────────────┴────────────────┴─────────────┴───────────────────┘");
        System.out.println();

        // ============================
        // Part E: Arrays.sort() 補充
        // ============================
        System.out.println("【Part E: Arrays.sort() 補充】");
        
        int[] arr = {5, 2, 8, 1, 9};
        System.out.println("原始陣列: " + Arrays.toString(arr));
        
        Arrays.sort(arr);
        System.out.println("Arrays.sort() 後: " + Arrays.toString(arr));
        System.out.println();

        // ============================
        // Part F: 排序穩定性
        // ============================
        System.out.println("【Part F: 排序穩定性】");
        System.out.println();
        System.out.println("穩定排序：相等元素的相對順序保持不變");
        System.out.println();
        System.out.println("• Collections.sort() → TimSort（穩定）");
        System.out.println("• Arrays.sort(T[]) → TimSort（穩定）");
        System.out.println("• Arrays.sort(int[]) → Dual-Pivot Quicksort（不穩定）");
        System.out.println();
        System.out.println("穩定性何時重要？");
        System.out.println("→ 多欄位排序時，先排次要欄位，再排主要欄位");
        System.out.println();

        // ============================
        // Part G: 效能考量
        // ============================
        System.out.println("【Part G: 效能考量】");
        System.out.println();
        System.out.println("1. 時間複雜度：O(n log n)");
        System.out.println();
        System.out.println("2. 如果只需要前 N 個最大/最小？");
        System.out.println("   → 考慮使用 PriorityQueue");
        System.out.println();
        System.out.println("3. 如果資料已經大致有序？");
        System.out.println("   → TimSort 對此優化，效能更好");

        System.out.println("\n=== Demo 結束 ===");
    }
}
