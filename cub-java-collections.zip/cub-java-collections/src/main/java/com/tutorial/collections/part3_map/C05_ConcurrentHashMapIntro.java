package com.tutorial.collections.part3_map;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ============================================================
 * 【章節標題】C05 - ConcurrentHashMap 簡介
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解為什麼 HashMap 不是執行緒安全的
 * 2. 認識 ConcurrentHashMap 的基本用法
 * 3. 學會原子操作方法
 * 
 * ============================================================
 */
public class C05_ConcurrentHashMapIntro {

    public static void main(String[] args) {
        System.out.println("=== C05: ConcurrentHashMap 簡介 ===\n");

        // ============================
        // 1. HashMap 不是執行緒安全的
        // ============================
        System.out.println("【1. HashMap 不是執行緒安全的】");
        System.out.println();
        System.out.println("問題場景：多執行緒同時操作 HashMap");
        System.out.println("  • 可能導致資料遺失");
        System.out.println("  • 可能導致無限迴圈（Java 7 以前）");
        System.out.println("  • 可能導致資料不一致");
        System.out.println();

        // ============================
        // 2. 解決方案比較
        // ============================
        System.out.println("【2. 解決方案比較】");
        System.out.println();
        System.out.println("┌─────────────────────────┬─────────────────┬───────────────┐");
        System.out.println("│         方案            │      效能       │     適用      │");
        System.out.println("├─────────────────────────┼─────────────────┼───────────────┤");
        System.out.println("│ Hashtable               │ 差（全表鎖）    │ 遺留程式      │");
        System.out.println("│ synchronizedMap()       │ 差（全表鎖）    │ 簡單場景      │");
        System.out.println("│ ConcurrentHashMap       │ 好（分段/CAS）  │ 推薦使用      │");
        System.out.println("└─────────────────────────┴─────────────────┴───────────────┘");
        System.out.println();

        // ============================
        // 3. ConcurrentHashMap 基本使用
        // ============================
        System.out.println("【3. ConcurrentHashMap 基本使用】");
        
        // API 與 HashMap 相同
        Map<String, Integer> concurrentMap = new ConcurrentHashMap<>();
        concurrentMap.put("A", 1);
        concurrentMap.put("B", 2);
        concurrentMap.put("C", 3);
        
        System.out.println("ConcurrentHashMap: " + concurrentMap);
        System.out.println("API 與 HashMap 相同");
        System.out.println();

        // ============================
        // 4. 不允許 null
        // ============================
        System.out.println("【4. ConcurrentHashMap 不允許 null】");
        System.out.println();
        System.out.println("  ❌ put(null, value) → NullPointerException");
        System.out.println("  ❌ put(key, null) → NullPointerException");
        System.out.println();
        System.out.println("原因：null 會導致並發問題");
        System.out.println("  get(key) 回傳 null 時，無法判斷是 key 不存在還是 value 是 null");
        System.out.println();

        // ============================
        // 5. 原子操作方法
        // ============================
        System.out.println("【5. 原子操作方法】");
        
        ConcurrentHashMap<String, Integer> atomicMap = new ConcurrentHashMap<>();
        
        // putIfAbsent：key 不存在時才放入
        atomicMap.putIfAbsent("count", 0);
        System.out.println("putIfAbsent(\"count\", 0) → " + atomicMap);
        
        // 再次呼叫不會更新
        atomicMap.putIfAbsent("count", 100);
        System.out.println("putIfAbsent(\"count\", 100) → " + atomicMap);
        System.out.println();
        
        // computeIfAbsent：key 不存在時計算並放入
        atomicMap.computeIfAbsent("sum", key -> 0);
        System.out.println("computeIfAbsent(\"sum\", k -> 0) → " + atomicMap);
        System.out.println();
        
        // compute：原子更新
        atomicMap.compute("count", (key, value) -> value + 1);
        System.out.println("compute 遞增 count → " + atomicMap);
        System.out.println();

        // ============================
        // 6. 與 synchronizedMap 的差異
        // ============================
        System.out.println("【6. 與 synchronizedMap 的差異】");
        
        Map<String, Integer> syncMap = Collections.synchronizedMap(new HashMap<>());
        
        System.out.println("Collections.synchronizedMap(new HashMap<>())");
        System.out.println();
        System.out.println("synchronizedMap：");
        System.out.println("  • 整個 Map 只有一把鎖");
        System.out.println("  • 遍歷時需要手動同步");
        System.out.println("  • 效能較差");
        System.out.println();
        System.out.println("ConcurrentHashMap：");
        System.out.println("  • Java 7：分段鎖（Segment Lock）");
        System.out.println("  • Java 8+：CAS + synchronized（更細粒度）");
        System.out.println("  • 遍歷時不需要額外同步");
        System.out.println("  • 效能較好");
        System.out.println();

        // ============================
        // 7. 使用場景
        // ============================
        System.out.println("【7. 使用場景】");
        System.out.println();
        System.out.println("ConcurrentHashMap 適用：");
        System.out.println("  ✓ 多執行緒環境");
        System.out.println("  ✓ 高併發讀寫");
        System.out.println("  ✓ 快取實作");
        System.out.println();
        System.out.println("注意事項：");
        System.out.println("  • 複合操作（check-then-act）仍需額外同步");
        System.out.println("  • 迭代器是弱一致性的");

        System.out.println("\n=== Demo 結束 ===");
    }
}
