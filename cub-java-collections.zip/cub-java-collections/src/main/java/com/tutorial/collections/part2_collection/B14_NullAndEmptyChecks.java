package com.tutorial.collections.part2_collection;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import java.util.*;

/**
 * ============================================================
 * 【章節標題】B14 - Null 與 Empty 判斷
 * ============================================================
 * 
 * 【學習目標】
 * 1. 區分 null 和 empty 的差異
 * 2. 掌握原生判斷方式
 * 3. 學會使用 CollectionUtils（Apache Commons）
 * 4. 了解 Optional 處理集合的方式
 * 
 * ============================================================
 */
public class B14_NullAndEmptyChecks {

    public static void main(String[] args) {
        System.out.println("=== B14: Null 與 Empty 判斷 ===\n");

        // ============================
        // Part A: null vs empty 差異
        // ============================
        System.out.println("【Part A: null vs empty 差異】");
        
        List<String> nullList = null;
        List<String> emptyList = new ArrayList<>();
        List<String> nonEmptyList = Arrays.asList("A", "B");
        
        System.out.println("null：變數沒有指向任何物件");
        System.out.println("empty：變數指向一個存在但沒有元素的集合");
        System.out.println();
        System.out.println("List<String> nullList = null;");
        System.out.println("List<String> emptyList = new ArrayList<>();");
        System.out.println("List<String> nonEmptyList = Arrays.asList(\"A\", \"B\");");
        System.out.println();

        // ============================
        // Part B: 原生判斷方式
        // ============================
        System.out.println("【Part B: 原生判斷方式】");
        System.out.println();
        
        // isEmpty()
        System.out.println("isEmpty() 方法：");
        System.out.println("  emptyList.isEmpty() = " + emptyList.isEmpty());
        System.out.println("  nonEmptyList.isEmpty() = " + nonEmptyList.isEmpty());
        System.out.println("  nullList.isEmpty() → NullPointerException！");
        System.out.println();
        
        // 安全的判斷
        System.out.println("安全的判斷方式（先檢查 null）：");
        System.out.println("  if (list != null && !list.isEmpty()) { ... }");
        System.out.println();
        
        // 示範
        if (nullList != null && !nullList.isEmpty()) {
            System.out.println("nullList 有元素");
        } else {
            System.out.println("  nullList: null 或 empty");
        }
        
        if (emptyList != null && !emptyList.isEmpty()) {
            System.out.println("emptyList 有元素");
        } else {
            System.out.println("  emptyList: null 或 empty");
        }
        
        if (nonEmptyList != null && !nonEmptyList.isEmpty()) {
            System.out.println("  nonEmptyList: 有元素");
        }
        System.out.println();

        // ============================
        // Part C: Apache Commons CollectionUtils
        // ============================
        System.out.println("【Part C: Apache Commons CollectionUtils】");
        System.out.println();
        
        // isEmpty：同時檢查 null 和 empty
        System.out.println("CollectionUtils.isEmpty()：同時檢查 null 和 empty");
        System.out.println("  isEmpty(null) = " + CollectionUtils.isEmpty(nullList));
        System.out.println("  isEmpty(emptyList) = " + CollectionUtils.isEmpty(emptyList));
        System.out.println("  isEmpty(nonEmptyList) = " + CollectionUtils.isEmpty(nonEmptyList));
        System.out.println();
        
        // isNotEmpty：更易讀的方式
        System.out.println("CollectionUtils.isNotEmpty()：");
        System.out.println("  isNotEmpty(null) = " + CollectionUtils.isNotEmpty(nullList));
        System.out.println("  isNotEmpty(nonEmptyList) = " + CollectionUtils.isNotEmpty(nonEmptyList));
        System.out.println();
        
        // 使用範例
        System.out.println("使用範例：");
        System.out.println("  if (CollectionUtils.isNotEmpty(list)) {");
        System.out.println("      // 安全地操作 list");
        System.out.println("  }");
        System.out.println();

        // ============================
        // Part D: CollectionUtils 其他方法
        // ============================
        System.out.println("【Part D: CollectionUtils 其他方法】");
        System.out.println();
        
        // emptyIfNull：將 null 轉為空集合
        Collection<String> safe = CollectionUtils.emptyIfNull(nullList);
        System.out.println("emptyIfNull(null)：回傳空集合");
        System.out.println("  結果.size() = " + safe.size());
        System.out.println();
        
        // size：安全取得大小
        System.out.println("CollectionUtils.size()：null 回傳 0");
        System.out.println("  size(null) = " + CollectionUtils.size(nullList));
        System.out.println("  size(emptyList) = " + CollectionUtils.size(emptyList));
        System.out.println("  size(nonEmptyList) = " + CollectionUtils.size(nonEmptyList));
        System.out.println();

        // ============================
        // Part E: Map 的空值判斷
        // ============================
        System.out.println("【Part E: Map 的空值判斷】");
        
        Map<String, Integer> nullMap = null;
        Map<String, Integer> emptyMap = new HashMap<>();
        Map<String, Integer> nonEmptyMap = Map.of("a", 1);
        
        System.out.println("MapUtils.isEmpty()：");
        System.out.println("  isEmpty(null) = " + MapUtils.isEmpty(nullMap));
        System.out.println("  isEmpty(emptyMap) = " + MapUtils.isEmpty(emptyMap));
        System.out.println("  isEmpty(nonEmptyMap) = " + MapUtils.isEmpty(nonEmptyMap));
        System.out.println();

        // ============================
        // Part F: Optional 處理
        // ============================
        System.out.println("【Part F: Optional 處理集合】");
        System.out.println();
        
        // 使用 Optional 包裝可能為 null 的集合
        Optional.ofNullable(nullList)
            .filter(l -> !l.isEmpty())
            .ifPresentOrElse(
                l -> System.out.println("  有元素: " + l),
                () -> System.out.println("  Optional 處理: null 或 empty")
            );
        
        // 提供預設空集合
        List<String> safeList = Optional.ofNullable(nullList)
            .orElse(Collections.emptyList());
        System.out.println("  orElse(emptyList) 後可安全遍歷: " + safeList);
        System.out.println();

        // ============================
        // Part G: 最佳實踐
        // ============================
        System.out.println("【Part G: 最佳實踐】");
        System.out.println();
        System.out.println("1. 方法回傳集合時，優先回傳空集合而非 null");
        System.out.println("   → Collections.emptyList()");
        System.out.println("   → Collections.emptySet()");
        System.out.println("   → Collections.emptyMap()");
        System.out.println("   → List.of()（Java 9+）");
        System.out.println();
        System.out.println("2. 專案內統一判斷方式");
        System.out.println("   → 有 Apache Commons：用 CollectionUtils");
        System.out.println("   → 沒有：用 list != null && !list.isEmpty()");
        System.out.println();
        System.out.println("3. 避免混淆 null 和 empty 的語意");

        System.out.println("\n=== Demo 結束 ===");
    }
}
