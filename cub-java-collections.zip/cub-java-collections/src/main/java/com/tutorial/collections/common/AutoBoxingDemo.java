package com.tutorial.collections.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ============================================================
 * 【章節標題】Auto Boxing / Unboxing 教學
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解基本類型與包裝類別的對應
 * 2. 理解 Auto Boxing 和 Auto Unboxing
 * 3. 認識常見陷阱與效能問題
 * 
 * ============================================================
 */
public class AutoBoxingDemo {

    public static void main(String[] args) {
        System.out.println("=== Auto Boxing / Unboxing 教學 ===\n");

        // ============================
        // 1. 基本類型 vs 包裝類別
        // ============================
        System.out.println("【1. 基本類型 vs 包裝類別】");
        System.out.println();
        System.out.println("┌───────────────┬─────────────────┐");
        System.out.println("│   基本類型    │    包裝類別     │");
        System.out.println("├───────────────┼─────────────────┤");
        System.out.println("│ byte          │ Byte            │");
        System.out.println("│ short         │ Short           │");
        System.out.println("│ int           │ Integer         │");
        System.out.println("│ long          │ Long            │");
        System.out.println("│ float         │ Float           │");
        System.out.println("│ double        │ Double          │");
        System.out.println("│ char          │ Character       │");
        System.out.println("│ boolean       │ Boolean         │");
        System.out.println("└───────────────┴─────────────────┘");
        System.out.println();

        // ============================
        // 2. 為什麼需要包裝類別
        // ============================
        System.out.println("【2. 為什麼需要包裝類別】");
        System.out.println();
        System.out.println("Collections 只能存放「物件」，不能存放基本類型！");
        System.out.println();
        System.out.println("  ❌ List<int> list = new ArrayList<>();  // 編譯錯誤");
        System.out.println("  ✓  List<Integer> list = new ArrayList<>();");
        System.out.println();

        // ============================
        // 3. Auto Boxing（自動裝箱）
        // ============================
        System.out.println("【3. Auto Boxing（自動裝箱）】");
        System.out.println();
        
        List<Integer> numbers = new ArrayList<>();
        numbers.add(1);   // Auto Boxing: int → Integer
        numbers.add(2);
        numbers.add(3);
        
        System.out.println("numbers.add(1);");
        System.out.println("等同於：numbers.add(Integer.valueOf(1));");
        System.out.println();
        System.out.println("List: " + numbers);
        System.out.println();

        // ============================
        // 4. Auto Unboxing（自動拆箱）
        // ============================
        System.out.println("【4. Auto Unboxing（自動拆箱）】");
        System.out.println();
        
        int first = numbers.get(0);  // Auto Unboxing: Integer → int
        System.out.println("int first = numbers.get(0);");
        System.out.println("等同於：int first = numbers.get(0).intValue();");
        System.out.println("first = " + first);
        System.out.println();
        
        // 迴圈中的 Unboxing
        int sum = 0;
        for (int n : numbers) {  // 每次迭代都會 Unboxing
            sum += n;
        }
        System.out.println("for (int n : numbers) { sum += n; }");
        System.out.println("每次迭代都會執行 Unboxing");
        System.out.println("sum = " + sum);
        System.out.println();

        // ============================
        // 5. Map 中的 Auto Boxing
        // ============================
        System.out.println("【5. Map 中的 Auto Boxing】");
        System.out.println();
        
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "one");     // key: int → Integer
        map.put(2, "two");
        
        String value = map.get(1);  // key: int → Integer
        
        System.out.println("map.put(1, \"one\");  // int 1 自動裝箱為 Integer");
        System.out.println("map.get(1);          // int 1 自動裝箱為 Integer");
        System.out.println();

        // ============================
        // 6. 注意事項：null 的 Unboxing
        // ============================
        System.out.println("【6. 注意事項：null 的 Unboxing】");
        System.out.println();
        
        Integer nullInteger = null;
        System.out.println("Integer nullInteger = null;");
        System.out.println("int n = nullInteger;  // NullPointerException!");
        System.out.println();
        System.out.println("⚠️ null 無法 Unboxing！");
        System.out.println();
        
        try {
            int n = nullInteger;  // NullPointerException
        } catch (NullPointerException e) {
            System.out.println("實際執行：拋出 NullPointerException");
        }
        System.out.println();

        // ============================
        // 7. 注意事項：Integer 快取
        // ============================
        System.out.println("【7. 注意事項：Integer 快取與 == 比較】");
        System.out.println();
        
        Integer a = 127;
        Integer b = 127;
        System.out.println("Integer a = 127; Integer b = 127;");
        System.out.println("a == b: " + (a == b));  // true（快取範圍內）
        
        Integer c = 128;
        Integer d = 128;
        System.out.println("\nInteger c = 128; Integer d = 128;");
        System.out.println("c == d: " + (c == d));  // false（超出快取範圍）
        
        System.out.println("\n解釋：");
        System.out.println("  Integer 快取範圍：-128 ~ 127");
        System.out.println("  範圍內的值會重用相同物件");
        System.out.println("  範圍外的值會建立新物件");
        System.out.println();
        System.out.println("✓ 比較 Integer 應該使用 equals()：");
        System.out.println("  c.equals(d): " + c.equals(d));
        System.out.println();

        // ============================
        // 8. 效能影響
        // ============================
        System.out.println("【8. 效能影響】");
        System.out.println();
        System.out.println("頻繁 Boxing/Unboxing 會影響效能！");
        System.out.println();
        System.out.println("❌ 不好的寫法：");
        System.out.println("  Long sum = 0L;");
        System.out.println("  for (long i = 0; i < 10000; i++) {");
        System.out.println("      sum += i;  // 每次都會 Boxing/Unboxing");
        System.out.println("  }");
        System.out.println();
        System.out.println("✓ 好的寫法：");
        System.out.println("  long sum = 0L;  // 使用基本類型");
        System.out.println("  for (long i = 0; i < 10000; i++) {");
        System.out.println("      sum += i;");
        System.out.println("  }");
        System.out.println();
        System.out.println("如果要使用 Comparator，考慮使用：");
        System.out.println("  Comparator.comparingInt() 而非 Comparator.comparing()");
        System.out.println("  可以避免 Auto Boxing");

        System.out.println("\n=== Demo 結束 ===");
    }
}
