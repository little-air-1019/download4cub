package com.tutorial.collections.part2_collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】B12 - Comparator 介面
 * ============================================================
 * 
 * 【學習目標】
 * 1. 理解 Comparator 與 Comparable 的差異
 * 2. 學會使用傳統寫法（匿名內部類別）
 * 3. 掌握 Java 8+ Lambda 和 Comparator 工具方法
 * 4. 學會多欄位排序和 null 處理
 * 
 * ============================================================
 */
public class B12_ComparatorInterface {

    public static void main(String[] args) {
        System.out.println("=== B12: Comparator 介面 ===\n");

        // ============================
        // Part A: Comparator vs Comparable
        // ============================
        System.out.println("【Part A: Comparator vs Comparable】");
        System.out.println();
        System.out.println("┌─────────────────┬──────────────────┬───────────────────┐");
        System.out.println("│      特性       │    Comparable    │    Comparator     │");
        System.out.println("├─────────────────┼──────────────────┼───────────────────┤");
        System.out.println("│ 位置            │ 定義在類別內部   │ 定義在類別外部    │");
        System.out.println("│ 方法            │ compareTo(T o)   │ compare(T o1, o2) │");
        System.out.println("│ 排序規則        │ 只能有一種       │ 可以有多種        │");
        System.out.println("│ 修改原類別      │ 需要             │ 不需要            │");
        System.out.println("└─────────────────┴──────────────────┴───────────────────┘");
        System.out.println();

        // 準備測試資料
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Alice", "HR", 50000));
        employees.add(new Employee("Bob", "IT", 60000));
        employees.add(new Employee("Charlie", "HR", 55000));
        employees.add(new Employee("David", "IT", 60000));

        // ============================
        // Part B: 傳統寫法（匿名內部類別）
        // ============================
        System.out.println("【Part B: 傳統寫法（匿名內部類別）】");
        
        Comparator<Employee> byName = new Comparator<Employee>() {
            @Override
            public int compare(Employee e1, Employee e2) {
                return e1.getName().compareTo(e2.getName());
            }
        };
        
        List<Employee> copy1 = new ArrayList<>(employees);
        Collections.sort(copy1, byName);
        
        System.out.println("依名字排序：");
        copy1.forEach(e -> System.out.println("  " + e));
        System.out.println();

        // ============================
        // Part C: Java 8+ Lambda 簡化
        // ============================
        System.out.println("【Part C: Java 8+ Lambda 簡化】");
        
        // Lambda 寫法
        Comparator<Employee> bySalary = (e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary());
        
        List<Employee> copy2 = new ArrayList<>(employees);
        Collections.sort(copy2, bySalary);
        
        System.out.println("依薪資排序（Lambda）：");
        copy2.forEach(e -> System.out.println("  " + e));
        System.out.println();

        // ============================
        // Part D: Comparator.comparing()（推薦）
        // ============================
        System.out.println("【Part D: Comparator.comparing()（推薦）】");
        
        // 使用 Comparator.comparing - 最簡潔的寫法
        List<Employee> copy3 = new ArrayList<>(employees);
        copy3.sort(Comparator.comparing(Employee::getName));
        
        System.out.println("Comparator.comparing(Employee::getName)：");
        copy3.forEach(e -> System.out.println("  " + e));
        System.out.println();

        // ============================
        // Part E: 反向排序 reversed()
        // ============================
        System.out.println("【Part E: 反向排序 reversed()】");
        
        List<Employee> copy4 = new ArrayList<>(employees);
        copy4.sort(Comparator.comparing(Employee::getSalary).reversed());
        
        System.out.println("依薪資降序（.reversed()）：");
        copy4.forEach(e -> System.out.println("  " + e));
        System.out.println();

        // ============================
        // Part F: 多欄位排序 thenComparing()
        // ============================
        System.out.println("【Part F: 多欄位排序 thenComparing()】");
        
        // 先依部門升序，部門相同依薪資降序，薪資相同依名字升序
        Comparator<Employee> multiSort = Comparator
            .comparing(Employee::getDepartment)
            .thenComparing(Comparator.comparing(Employee::getSalary).reversed())
            .thenComparing(Employee::getName);
        
        List<Employee> copy5 = new ArrayList<>(employees);
        copy5.sort(multiSort);
        
        System.out.println("多欄位排序（部門↑ → 薪資↓ → 名字↑）：");
        copy5.forEach(e -> System.out.println("  " + e));
        System.out.println();

        // ============================
        // Part G: 避免 Auto Boxing
        // ============================
        System.out.println("【Part G: 避免 Auto Boxing】");
        System.out.println();
        System.out.println("// 會產生 Auto Boxing（效能較差）");
        System.out.println("Comparator.comparing(Employee::getSalary)");
        System.out.println();
        System.out.println("// 避免 Auto Boxing（效能較好）");
        System.out.println("Comparator.comparingDouble(Employee::getSalary)");
        System.out.println("Comparator.comparingInt(...)");
        System.out.println("Comparator.comparingLong(...)");
        System.out.println();

        // ============================
        // Part H: 處理 null 值
        // ============================
        System.out.println("【Part H: 處理 null 值】");
        
        List<String> names = new ArrayList<>();
        names.add("Charlie");
        names.add(null);
        names.add("Alice");
        names.add(null);
        names.add("Bob");
        
        // nullsFirst：null 排在最前面
        names.sort(Comparator.nullsFirst(Comparator.naturalOrder()));
        System.out.println("nullsFirst: " + names);
        
        // nullsLast：null 排在最後面
        names.sort(Comparator.nullsLast(Comparator.naturalOrder()));
        System.out.println("nullsLast: " + names);
        System.out.println();

        // ============================
        // Part I: 實用靜態方法速查
        // ============================
        System.out.println("【Part I: Comparator 實用方法速查】");
        System.out.println();
        System.out.println("建構方法：");
        System.out.println("  Comparator.comparing(keyExtractor)");
        System.out.println("  Comparator.comparingInt/Long/Double(keyExtractor)");
        System.out.println();
        System.out.println("鏈式方法：");
        System.out.println("  .reversed()");
        System.out.println("  .thenComparing(...)");
        System.out.println("  .thenComparingInt/Long/Double(...)");
        System.out.println();
        System.out.println("特殊排序：");
        System.out.println("  Comparator.naturalOrder()");
        System.out.println("  Comparator.reverseOrder()");
        System.out.println("  Comparator.nullsFirst(comparator)");
        System.out.println("  Comparator.nullsLast(comparator)");

        System.out.println("\n=== Demo 結束 ===");
    }
}

// ============================
// 輔助類別
// ============================
class Employee {
    private String name;
    private String department;
    private double salary;

    public Employee(String name, String department, double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public String getName() { return name; }
    public String getDepartment() { return department; }
    public double getSalary() { return salary; }

    @Override
    public String toString() {
        return String.format("(%s, %s, %.0f)", name, department, salary);
    }
}
