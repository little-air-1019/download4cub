package com.tutorial.collections.part2_collection;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * ============================================================
 * 【章節標題】B06 - HashSet 深入解析
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 HashSet 底層結構（HashMap）
 * 2. 理解 Hash 和 Bucket 概念
 * 3. 掌握 equals() 和 hashCode() 的重要性
 * 4. 學會為自訂物件正確覆寫 equals() 和 hashCode()
 * 
 * ============================================================
 */
public class B06_HashSetDeepDive {

    public static void main(String[] args) {
        System.out.println("=== B06: HashSet 深入解析 ===\n");

        // ============================
        // 1. HashSet 底層結構
        // ============================
        /*
         * HashSet 底層其實是一個 HashMap！
         * 
         * 內部結構（簡化）：
         * public class HashSet<E> {
         *     private HashMap<E, Object> map;
         *     private static final Object PRESENT = new Object();  // dummy value
         *     
         *     public boolean add(E e) {
         *         return map.put(e, PRESENT) == null;
         *     }
         * }
         * 
         * 元素作為 key，value 是一個固定的 dummy object
         */
        System.out.println("【1. HashSet 底層結構】");
        System.out.println("HashSet 底層是一個 HashMap");
        System.out.println();
        System.out.println("簡化結構：");
        System.out.println("  HashMap<E, Object> map;  // 儲存元素");
        System.out.println("  Object PRESENT = new Object();  // dummy value");
        System.out.println();
        System.out.println("  add(e) → map.put(e, PRESENT)");
        System.out.println("  contains(e) → map.containsKey(e)");
        System.out.println();

        // ============================
        // 2. Hash 和 Bucket 概念
        // ============================
        /*
         * Hash Table 的運作原理：
         * 
         * 1. 計算 hashCode
         *    hashCode = element.hashCode()
         * 
         * 2. 決定放入哪個 bucket
         *    bucketIndex = hashCode % numberOfBuckets
         * 
         * 3. 如果該 bucket 已有元素（Hash Collision）
         *    使用 equals() 判斷是否真的相同
         * 
         * 示意圖：
         * Bucket 0: [ ]
         * Bucket 1: [Apple] → [Apricot]  ← Hash Collision
         * Bucket 2: [Banana]
         * Bucket 3: [ ]
         * Bucket 4: [Cherry]
         */
        System.out.println("【2. Hash 和 Bucket 概念】");
        System.out.println();
        System.out.println("Hash Table 運作流程：");
        System.out.println("  1. 計算 hashCode = element.hashCode()");
        System.out.println("  2. 決定 bucket = hashCode % bucketCount");
        System.out.println("  3. 若有 Hash Collision，用 equals() 判斷");
        System.out.println();
        System.out.println("示意圖：");
        System.out.println("  Bucket 0: [ ]");
        System.out.println("  Bucket 1: [Apple] → [Apricot]  ← Hash Collision");
        System.out.println("  Bucket 2: [Banana]");
        System.out.println("  Bucket 3: [ ]");
        System.out.println("  Bucket 4: [Cherry]");
        System.out.println();

        // ============================
        // 3. 為什麼需要覆寫 equals() 和 hashCode()
        // ============================
        /*
         * Object 類別的預設實作：
         * - equals()：比較記憶體位址（==）
         * - hashCode()：根據記憶體位址計算
         * 
         * 問題：對於自訂物件，「內容相同」但「不同物件」會被視為不同！
         * 
         * 規則：
         * 如果 a.equals(b) == true，則 a.hashCode() 必須等於 b.hashCode()
         * （但反過來不一定成立）
         */
        System.out.println("【3. 為什麼需要覆寫 equals() 和 hashCode()】");
        System.out.println();
        System.out.println("Object 預設實作：");
        System.out.println("  equals()：比較記憶體位址（==）");
        System.out.println("  hashCode()：根據記憶體位址計算");
        System.out.println();
        System.out.println("問題：兩個「內容相同」的物件會被視為不同！");
        System.out.println();
        System.out.println("契約規則：");
        System.out.println("  若 a.equals(b) == true，");
        System.out.println("  則必須 a.hashCode() == b.hashCode()");
        System.out.println();

        // ============================
        // 4. 未覆寫的問題展示
        // ============================
        System.out.println("【4. 未覆寫的問題展示】");
        
        // PersonBad 沒有覆寫 equals/hashCode
        Set<PersonBad> badSet = new HashSet<>();
        badSet.add(new PersonBad("Alice", 25));
        badSet.add(new PersonBad("Alice", 25));  // 內容相同，但會被當作不同物件！
        
        System.out.println("PersonBad（未覆寫）：");
        System.out.println("  add(Alice, 25) 兩次");
        System.out.println("  Set size = " + badSet.size());  // 2，不是 1！
        System.out.println("  ❌ 重複元素沒有被去重！");
        System.out.println();

        // ============================
        // 5. 正確覆寫後的行為
        // ============================
        System.out.println("【5. 正確覆寫後的行為】");
        
        // PersonGood 有覆寫 equals/hashCode
        Set<PersonGood> goodSet = new HashSet<>();
        goodSet.add(new PersonGood("Alice", 25));
        goodSet.add(new PersonGood("Alice", 25));  // 內容相同，會被視為重複
        
        System.out.println("PersonGood（已覆寫）：");
        System.out.println("  add(Alice, 25) 兩次");
        System.out.println("  Set size = " + goodSet.size());  // 1，正確去重！
        System.out.println("  ✓ 重複元素被正確去重！");
        System.out.println();
        
        // contains 也能正常運作
        boolean containsAlice = goodSet.contains(new PersonGood("Alice", 25));
        System.out.println("contains(new PersonGood(\"Alice\", 25)) = " + containsAlice);
        System.out.println();

        // ============================
        // 6. HashSet 無序
        // ============================
        System.out.println("【6. HashSet 無序】");
        
        Set<Integer> numbers = new HashSet<>();
        numbers.add(5);
        numbers.add(2);
        numbers.add(8);
        numbers.add(1);
        numbers.add(9);
        
        System.out.println("加入順序: 5, 2, 8, 1, 9");
        System.out.println("遍歷順序: " + numbers);
        System.out.println("⚠️ 順序不保證，可能每次執行都不同");
        System.out.println();
        System.out.println("如需保持插入順序 → 使用 LinkedHashSet");
        System.out.println("如需排序順序 → 使用 TreeSet");

        System.out.println("\n=== Demo 結束 ===");
    }
}

// ============================
// 輔助類別：未覆寫 equals/hashCode
// ============================
class PersonBad {
    private String name;
    private int age;

    public PersonBad(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    // 沒有覆寫 equals() 和 hashCode()
    // 使用 Object 的預設實作（比較記憶體位址）
}

// ============================
// 輔助類別：正確覆寫 equals/hashCode
// ============================
class PersonGood {
    private String name;
    private int age;

    public PersonGood(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public boolean equals(Object o) {
        // 1. 同一個物件
        if (this == o) return true;
        // 2. null 或不同類型
        if (o == null || getClass() != o.getClass()) return false;
        // 3. 比較欄位
        PersonGood that = (PersonGood) o;
        return age == that.age && Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        // 使用 Objects.hash() 計算，確保相同內容有相同 hashCode
        return Objects.hash(name, age);
    }

    @Override
    public String toString() {
        return "PersonGood{name='" + name + "', age=" + age + "}";
    }
}
