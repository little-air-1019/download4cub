package com.tutorial.collections.common;

import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】Generics 泛型完整教學
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解為什麼需要泛型
 * 2. 掌握泛型類別和泛型方法
 * 3. 學會 Bounded Type Parameters
 * 4. 理解 Wildcards 和 PECS 原則
 * 5. 認識 Type Erasure
 * 
 * ============================================================
 */
public class GenericsDemo {

    public static void main(String[] args) {
        System.out.println("=== Generics 泛型完整教學 ===\n");

        // ============================
        // Part A: 為什麼需要 Generics
        // ============================
        System.out.println("【Part A: 為什麼需要 Generics】");
        System.out.println();
        System.out.println("沒有泛型（Raw Type）的問題：");
        System.out.println();
        System.out.println("  List list = new ArrayList();");
        System.out.println("  list.add(\"hello\");");
        System.out.println("  list.add(123);  // 編譯通過！");
        System.out.println("  String s = (String) list.get(1);  // 執行期 ClassCastException！");
        System.out.println();
        System.out.println("使用泛型後：");
        System.out.println();
        System.out.println("  List<String> list = new ArrayList<>();");
        System.out.println("  list.add(\"hello\");");
        System.out.println("  list.add(123);  // 編譯錯誤！型態不符");
        System.out.println();
        System.out.println("✓ 編譯期型態檢查，避免執行期錯誤");
        System.out.println();

        // ============================
        // Part B: 泛型類別
        // ============================
        System.out.println("【Part B: 泛型類別】");
        
        // 使用泛型類別
        Box<String> stringBox = new Box<>();
        stringBox.set("Hello");
        String value = stringBox.get();  // 不需要強制轉型
        System.out.println("Box<String>.get() = " + value);
        
        Box<Integer> intBox = new Box<>();
        intBox.set(42);
        Integer num = intBox.get();
        System.out.println("Box<Integer>.get() = " + num);
        System.out.println();

        // ============================
        // Part C: 泛型方法
        // ============================
        System.out.println("【Part C: 泛型方法】");
        
        // 呼叫泛型方法
        String[] strArray = {"A", "B", "C"};
        List<String> strList = arrayToList(strArray);
        System.out.println("arrayToList(String[]) = " + strList);
        
        Integer[] intArray = {1, 2, 3};
        List<Integer> intList = arrayToList(intArray);
        System.out.println("arrayToList(Integer[]) = " + intList);
        System.out.println();

        // ============================
        // Part D: Bounded Type Parameters
        // ============================
        System.out.println("【Part D: Bounded Type Parameters】");
        System.out.println();
        System.out.println("Upper Bound：<T extends Number>");
        System.out.println("  T 必須是 Number 或其子類別");
        System.out.println();
        
        // 使用 bounded type
        System.out.println("sumOfList([1, 2, 3]) = " + sumOfList(List.of(1, 2, 3)));
        System.out.println("sumOfList([1.5, 2.5]) = " + sumOfList(List.of(1.5, 2.5)));
        System.out.println();
        
        System.out.println("多重限制：<T extends Comparable<T> & Serializable>");
        System.out.println("  T 必須同時滿足多個限制");
        System.out.println();

        // ============================
        // Part E: Wildcards
        // ============================
        System.out.println("【Part E: Wildcards 萬用字元】");
        System.out.println();
        System.out.println("1. Unbounded Wildcard: List<?>");
        System.out.println("   可以接受任何型態的 List");
        System.out.println();
        System.out.println("2. Upper Bounded: List<? extends Number>");
        System.out.println("   可以接受 Number 或其子類別的 List");
        System.out.println("   只能讀取（Producer）");
        System.out.println();
        System.out.println("3. Lower Bounded: List<? super Integer>");
        System.out.println("   可以接受 Integer 或其父類別的 List");
        System.out.println("   只能寫入（Consumer）");
        System.out.println();

        // 展示 wildcards
        List<Integer> integers = List.of(1, 2, 3);
        List<Double> doubles = List.of(1.5, 2.5, 3.5);
        
        System.out.println("printNumbers(List<Integer>) ...");
        printNumbers(integers);
        System.out.println("printNumbers(List<Double>) ...");
        printNumbers(doubles);
        System.out.println();

        // ============================
        // Part F: PECS 原則
        // ============================
        System.out.println("【Part F: PECS 原則】");
        System.out.println();
        System.out.println("PECS = Producer Extends, Consumer Super");
        System.out.println();
        System.out.println("如果要「讀取」資料（Producer）：");
        System.out.println("  → 使用 <? extends T>");
        System.out.println();
        System.out.println("如果要「寫入」資料（Consumer）：");
        System.out.println("  → 使用 <? super T>");
        System.out.println();
        System.out.println("範例：Collections.copy(List<? super T> dest, List<? extends T> src)");
        System.out.println("  src 是 Producer → extends");
        System.out.println("  dest 是 Consumer → super");
        System.out.println();

        // ============================
        // Part G: Type Erasure 型態擦除
        // ============================
        System.out.println("【Part G: Type Erasure 型態擦除】");
        System.out.println();
        System.out.println("泛型資訊只存在於「編譯期」！");
        System.out.println();
        System.out.println("編譯後：");
        System.out.println("  List<String> → List（raw type）");
        System.out.println("  Box<Integer> → Box");
        System.out.println();
        System.out.println("因此無法：");
        System.out.println("  ❌ new T()          // 不知道 T 是什麼");
        System.out.println("  ❌ new T[10]        // 無法建立泛型陣列");
        System.out.println("  ❌ instanceof List<String>  // 執行期沒有型態資訊");
        System.out.println();
        System.out.println("解決方案：傳入 Class<T> 作為參數");

        System.out.println("\n=== Demo 結束 ===");
    }

    // ============================
    // 泛型方法範例
    // ============================
    public static <T> List<T> arrayToList(T[] array) {
        List<T> list = new ArrayList<>();
        for (T item : array) {
            list.add(item);
        }
        return list;
    }

    // ============================
    // Bounded Type 範例
    // ============================
    public static <T extends Number> double sumOfList(List<T> list) {
        double sum = 0.0;
        for (T num : list) {
            sum += num.doubleValue();
        }
        return sum;
    }

    // ============================
    // Wildcard 範例
    // ============================
    public static void printNumbers(List<? extends Number> list) {
        for (Number n : list) {
            System.out.print("  " + n);
        }
        System.out.println();
    }
}

// ============================
// 泛型類別範例
// ============================
class Box<T> {
    private T content;

    public void set(T content) {
        this.content = content;
    }

    public T get() {
        return content;
    }
}
