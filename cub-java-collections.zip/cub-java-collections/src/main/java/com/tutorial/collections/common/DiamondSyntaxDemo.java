package com.tutorial.collections.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ============================================================
 * 【章節標題】Diamond 語法教學
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 Diamond 語法 (<>)
 * 2. 掌握 Diamond 語法的使用場景
 * 3. 認識 var 關鍵字（Java 10+）
 * 
 * ============================================================
 */
public class DiamondSyntaxDemo {

    public static void main(String[] args) {
        System.out.println("=== Diamond 語法教學 ===\n");

        // ============================
        // 1. Java 7 之前
        // ============================
        System.out.println("【1. Java 7 之前】");
        System.out.println();
        System.out.println("建立泛型集合需要重複寫型態：");
        System.out.println();
        System.out.println("  List<String> list = new ArrayList<String>();");
        System.out.println("  Map<String, List<Integer>> map = new HashMap<String, List<Integer>>();");
        System.out.println();
        System.out.println("型態越複雜，程式碼越冗長...");
        System.out.println();

        // ============================
        // 2. Java 7+ Diamond 語法
        // ============================
        System.out.println("【2. Java 7+ Diamond 語法】");
        System.out.println();
        
        // 使用 Diamond 語法
        List<String> list = new ArrayList<>();
        Map<String, List<Integer>> map = new HashMap<>();
        
        System.out.println("使用 Diamond 語法 <>：");
        System.out.println();
        System.out.println("  List<String> list = new ArrayList<>();");
        System.out.println("  Map<String, List<Integer>> map = new HashMap<>();");
        System.out.println();
        System.out.println("編譯器會從左邊的宣告推斷型態！");
        System.out.println();

        // ============================
        // 3. Diamond 語法的使用場景
        // ============================
        System.out.println("【3. Diamond 語法的使用場景】");
        System.out.println();
        
        // 變數宣告
        System.out.println("1. 變數宣告：");
        System.out.println("   List<String> names = new ArrayList<>();");
        System.out.println();
        
        // 方法回傳
        System.out.println("2. 方法回傳：");
        System.out.println("   public List<String> getNames() {");
        System.out.println("       return new ArrayList<>();");
        System.out.println("   }");
        System.out.println();
        
        // 集合初始化
        System.out.println("3. 巢狀泛型：");
        System.out.println("   Map<String, Map<String, List<Integer>>> data = new HashMap<>();");
        System.out.println();

        // ============================
        // 4. Diamond 語法的限制
        // ============================
        System.out.println("【4. Diamond 語法的限制（Java 8 以前）】");
        System.out.println();
        System.out.println("Java 8 以前，匿名內部類別不能使用 Diamond：");
        System.out.println();
        System.out.println("  // Java 8 以前會編譯錯誤");
        System.out.println("  Comparator<String> comp = new Comparator<>() {");
        System.out.println("      @Override");
        System.out.println("      public int compare(String s1, String s2) { ... }");
        System.out.println("  };");
        System.out.println();
        System.out.println("Java 9+ 已經解決這個限制！");
        System.out.println();

        // ============================
        // 5. Java 10+ var 關鍵字
        // ============================
        System.out.println("【5. Java 10+ var 關鍵字】");
        System.out.println();
        
        // 使用 var
        var names = new ArrayList<String>();
        var scores = new HashMap<String, Integer>();
        
        System.out.println("使用 var 自動推斷型態：");
        System.out.println();
        System.out.println("  var names = new ArrayList<String>();");
        System.out.println("  var scores = new HashMap<String, Integer>();");
        System.out.println();
        System.out.println("⚠️ 注意：右邊必須明確指定型態！");
        System.out.println();
        System.out.println("  var list = new ArrayList<>();  // ❌ 型態會是 ArrayList<Object>");
        System.out.println("  var list = new ArrayList<String>();  // ✓ OK");
        System.out.println();

        // ============================
        // 6. var 的使用建議
        // ============================
        System.out.println("【6. var 的使用建議】");
        System.out.println();
        System.out.println("✓ 適合使用 var 的情況：");
        System.out.println("  • 型態很長且明顯");
        System.out.println("  • 右邊有明確的建構式");
        System.out.println("  • 迴圈變數");
        System.out.println();
        System.out.println("❌ 不建議使用 var 的情況：");
        System.out.println("  • 方法回傳值不明確");
        System.out.println("  • 會降低可讀性");
        System.out.println("  • 團隊 coding style 不允許");
        System.out.println();
        
        // 好的使用範例
        System.out.println("範例：");
        var productMap = new HashMap<String, List<Integer>>();
        System.out.println("  var productMap = new HashMap<String, List<Integer>>();");
        System.out.println("  比起寫兩次長型態更簡潔");

        System.out.println("\n=== Demo 結束 ===");
    }
}
