package com.tutorial.collections.part2_collection;

import java.util.HashSet;
import java.util.Set;

/**
 * ============================================================
 * 【章節標題】B05 - Set 介面
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 Set 的核心特性：唯一性
 * 2. 掌握 Set 的常用方法
 * 3. 認識 Set 與 List 的差異
 * 
 * ============================================================
 */
public class B05_SetInterface {

    public static void main(String[] args) {
        System.out.println("=== B05: Set 介面 ===\n");

        // ============================
        // 1. Set 核心特性
        // ============================
        /*
         * Set 的核心特性：唯一性（不允許重複元素）
         * 
         * 與 List 的差異：
         * - Set 不保證順序（HashSet）
         * - Set 沒有 index 相關方法
         * - Set 不允許重複
         */
        System.out.println("【1. Set 核心特性】");
        System.out.println("  ✓ 唯一性：不允許重複元素");
        System.out.println("  ✓ 通常無序（HashSet）");
        System.out.println("  ✓ 沒有 index 相關方法");
        System.out.println();

        // ============================
        // 2. Set 不允許重複元素
        // ============================
        System.out.println("【2. 唯一性展示】");
        
        Set<String> fruits = new HashSet<>();
        
        boolean added1 = fruits.add("Apple");
        boolean added2 = fruits.add("Banana");
        boolean added3 = fruits.add("Apple");  // 重複，加入失敗
        
        System.out.println("add(\"Apple\") = " + added1);   // true
        System.out.println("add(\"Banana\") = " + added2);  // true
        System.out.println("add(\"Apple\") = " + added3);   // false（重複）
        System.out.println();
        System.out.println("Set: " + fruits);
        System.out.println("size() = " + fruits.size());  // 2，不是 3
        System.out.println();
        System.out.println("💡 add() 回傳 boolean：");
        System.out.println("   true = 成功加入（元素不存在）");
        System.out.println("   false = 加入失敗（元素已存在）");
        System.out.println();

        // ============================
        // 3. Set 常用方法
        // ============================
        System.out.println("【3. Set 常用方法】");
        
        Set<Integer> numbers = new HashSet<>();
        numbers.add(3);
        numbers.add(1);
        numbers.add(4);
        numbers.add(1);  // 重複，不會加入
        numbers.add(5);
        numbers.add(9);
        
        System.out.println("Set: " + numbers);
        System.out.println("size() = " + numbers.size());
        System.out.println("contains(4) = " + numbers.contains(4));
        System.out.println("contains(2) = " + numbers.contains(2));
        System.out.println("isEmpty() = " + numbers.isEmpty());
        System.out.println();
        
        // 移除元素
        boolean removed = numbers.remove(1);
        System.out.println("remove(1) = " + removed);
        System.out.println("Set after remove: " + numbers);
        System.out.println();

        // ============================
        // 4. Set 沒有 index
        // ============================
        /*
         * 與 List 不同，Set 沒有：
         * - get(index)
         * - set(index, element)
         * - add(index, element)
         * - indexOf(element)
         * 
         * 因為 Set 不保證順序，index 沒有意義。
         */
        System.out.println("【4. Set 沒有 index】");
        System.out.println("Set 沒有以下方法：");
        System.out.println("  ✗ get(index)");
        System.out.println("  ✗ set(index, element)");
        System.out.println("  ✗ add(index, element)");
        System.out.println("  ✗ indexOf(element)");
        System.out.println();
        System.out.println("原因：Set 不保證順序，index 沒有意義");
        System.out.println();

        // ============================
        // 5. 遍歷 Set
        // ============================
        System.out.println("【5. 遍歷 Set】");
        
        Set<String> colors = new HashSet<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        
        // for-each（最常用）
        System.out.println("for-each 遍歷：");
        for (String color : colors) {
            System.out.println("  " + color);
        }
        System.out.println();
        
        // forEach + Lambda（Java 8+）
        System.out.println("forEach + Lambda：");
        colors.forEach(color -> System.out.println("  " + color));
        System.out.println();

        // ============================
        // 6. 常見用途：去重
        // ============================
        System.out.println("【6. 常見用途：去重】");
        
        // 假設有一個有重複元素的 List
        java.util.List<String> listWithDuplicates = java.util.Arrays.asList(
            "Apple", "Banana", "Apple", "Cherry", "Banana", "Apple"
        );
        System.out.println("原始 List: " + listWithDuplicates);
        
        // 轉換成 Set 就能去重
        Set<String> uniqueSet = new HashSet<>(listWithDuplicates);
        System.out.println("轉成 Set: " + uniqueSet);
        
        // 如果需要回傳 List
        java.util.List<String> uniqueList = new java.util.ArrayList<>(uniqueSet);
        System.out.println("再轉回 List: " + uniqueList);
        System.out.println();

        // ============================
        // 7. Set vs List 比較
        // ============================
        System.out.println("【7. Set vs List 比較】");
        System.out.println();
        System.out.println("┌─────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│      特性       │      List       │       Set       │");
        System.out.println("├─────────────────┼─────────────────┼─────────────────┤");
        System.out.println("│ 允許重複        │ ✓ 是            │ ✗ 否            │");
        System.out.println("│ 有順序          │ ✓ 是            │ 通常否          │");
        System.out.println("│ 可用 index      │ ✓ 是            │ ✗ 否            │");
        System.out.println("│ 常見實作        │ ArrayList       │ HashSet         │");
        System.out.println("│ 使用場景        │ 需要順序、重複  │ 需要唯一性      │");
        System.out.println("└─────────────────┴─────────────────┴─────────────────┘");

        System.out.println("\n=== Demo 結束 ===");
    }
}
