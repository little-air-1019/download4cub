package com.tutorial.collections.part3_map;

import java.util.HashMap;
import java.util.Map;

/**
 * ============================================================
 * 【章節標題】C02 - Map 介面核心方法
 * ============================================================
 * 
 * 【學習目標】
 * 1. 掌握 Map 的基本操作：put, get, remove
 * 2. 學會使用 getOrDefault 和其他便利方法
 * 3. 了解 keySet, values, entrySet
 * 
 * ============================================================
 */
public class C02_MapInterface {

    public static void main(String[] args) {
        System.out.println("=== C02: Map 介面核心方法 ===\n");

        // ============================
        // 1. 建立 Map
        // ============================
        System.out.println("【1. 建立 Map】");
        
        // 使用 Diamond 語法 + 面向介面
        Map<String, Integer> scores = new HashMap<>();
        
        System.out.println("Map<String, Integer> scores = new HashMap<>();");
        System.out.println("（Generics + Diamond 語法）");
        System.out.println();

        // ============================
        // 2. put() - 新增/更新
        // ============================
        /*
         * put(K, V) 會：
         * - 如果 key 不存在：新增鍵值對
         * - 如果 key 已存在：更新 value，回傳舊的 value
         */
        System.out.println("【2. put() - 新增/更新】");
        
        scores.put("Alice", 85);
        scores.put("Bob", 92);
        scores.put("Charlie", 78);
        
        System.out.println("put(\"Alice\", 85)");
        System.out.println("put(\"Bob\", 92)");
        System.out.println("put(\"Charlie\", 78)");
        System.out.println("Map: " + scores);
        System.out.println();
        
        // 更新現有 key
        Integer oldValue = scores.put("Alice", 90);  // 更新，回傳舊值
        System.out.println("put(\"Alice\", 90) → 舊值: " + oldValue);
        System.out.println("Map: " + scores);
        System.out.println();

        // ============================
        // 3. get() - 取值
        // ============================
        System.out.println("【3. get() - 取值】");
        
        Integer aliceScore = scores.get("Alice");
        Integer unknownScore = scores.get("Unknown");
        
        System.out.println("get(\"Alice\") = " + aliceScore);
        System.out.println("get(\"Unknown\") = " + unknownScore);  // null
        System.out.println();

        // ============================
        // 4. getOrDefault() - 安全取值
        // ============================
        System.out.println("【4. getOrDefault() - 安全取值】");
        
        Integer score1 = scores.getOrDefault("Alice", 0);
        Integer score2 = scores.getOrDefault("Unknown", 0);  // 不存在，回傳預設值
        
        System.out.println("getOrDefault(\"Alice\", 0) = " + score1);
        System.out.println("getOrDefault(\"Unknown\", 0) = " + score2);
        System.out.println("（比 get() + null 檢查更簡潔）");
        System.out.println();

        // ============================
        // 5. containsKey() / containsValue()
        // ============================
        System.out.println("【5. containsKey() / containsValue()】");
        
        System.out.println("Map: " + scores);
        System.out.println("containsKey(\"Alice\") = " + scores.containsKey("Alice"));
        System.out.println("containsKey(\"Unknown\") = " + scores.containsKey("Unknown"));
        System.out.println("containsValue(90) = " + scores.containsValue(90));
        System.out.println("containsValue(100) = " + scores.containsValue(100));
        System.out.println();

        // ============================
        // 6. remove() - 移除
        // ============================
        System.out.println("【6. remove() - 移除】");
        
        System.out.println("移除前: " + scores);
        Integer removed = scores.remove("Charlie");
        System.out.println("remove(\"Charlie\") = " + removed);
        System.out.println("移除後: " + scores);
        System.out.println();
        
        // 條件移除（Java 8+）
        scores.put("David", 60);
        System.out.println("加入 David=60: " + scores);
        boolean success = scores.remove("David", 60);  // key 和 value 都要匹配
        System.out.println("remove(\"David\", 60) = " + success);
        System.out.println("移除後: " + scores);
        System.out.println();

        // ============================
        // 7. size(), isEmpty(), clear()
        // ============================
        System.out.println("【7. size(), isEmpty(), clear()】");
        
        System.out.println("size() = " + scores.size());
        System.out.println("isEmpty() = " + scores.isEmpty());
        
        scores.clear();
        System.out.println("clear() 後 isEmpty() = " + scores.isEmpty());
        System.out.println();

        // ============================
        // 8. keySet(), values(), entrySet()
        // ============================
        System.out.println("【8. keySet(), values(), entrySet()】");
        
        Map<String, Integer> grades = new HashMap<>();
        grades.put("Math", 95);
        grades.put("English", 88);
        grades.put("Science", 92);
        
        System.out.println("Map: " + grades);
        System.out.println();
        
        System.out.println("keySet(): " + grades.keySet());
        System.out.println("values(): " + grades.values());
        System.out.println("entrySet(): " + grades.entrySet());
        System.out.println();

        // ============================
        // 9. Java 8+ 便利方法
        // ============================
        System.out.println("【9. Java 8+ 便利方法】");
        
        // putIfAbsent：只在 key 不存在時才放入
        grades.putIfAbsent("Math", 100);  // Math 已存在，不會更新
        grades.putIfAbsent("History", 85);  // History 不存在，會放入
        System.out.println("putIfAbsent 後: " + grades);
        
        // computeIfAbsent：key 不存在時計算並放入
        grades.computeIfAbsent("Art", key -> 80);
        System.out.println("computeIfAbsent 後: " + grades);
        
        // merge：合併值
        grades.merge("Math", 5, (oldVal, newVal) -> oldVal + newVal);  // Math += 5
        System.out.println("merge(Math, +5) 後: " + grades);
        System.out.println();

        // ============================
        // 10. Auto Boxing in Map
        // ============================
        System.out.println("【10. Auto Boxing in Map】");
        System.out.println();
        System.out.println("Map<Integer, String> map = new HashMap<>();");
        System.out.println("map.put(1, \"one\");  // int 1 自動裝箱為 Integer");
        System.out.println();
        System.out.println("int key = ...;");
        System.out.println("String value = map.get(key);  // 自動裝箱");

        System.out.println("\n=== Demo 結束 ===");
    }
}
