package com.tutorial.collections.part3_map.exercises;

import java.util.*;

/**
 * ============================================================
 * 【練習題】Map 練習
 * ============================================================
 * 
 * 完成以下練習題，加深對 Map 操作的理解。
 * 每個方法都有 TODO 標記，請實作該方法。
 * 執行 main() 可以測試你的實作。
 * 
 * ============================================================
 */
public class MapExercises {

    /**
     * 練習 1：字元頻率統計
     * 統計字串中每個字元出現的次數
     * 
     * 範例：
     * 輸入："hello world"
     * 預期：{h=1, e=1, l=3, o=2, ' '=1, w=1, r=1, d=1}
     */
    public static Map<Character, Integer> charFrequency(String str) {
        // TODO: 請實作此方法
        // 提示：遍歷字串的每個字元，使用 getOrDefault 或 merge
        return null;
    }

    /**
     * 練習 2：反轉 Map
     * 將 Map<K, V> 轉換為 Map<V, K>
     * 注意：如果有重複的 value，後者覆蓋前者
     * 
     * 範例：
     * 輸入：{a=1, b=2, c=3}
     * 預期：{1=a, 2=b, 3=c}
     */
    public static <K, V> Map<V, K> reverseMap(Map<K, V> map) {
        // TODO: 請實作此方法
        // 提示：遍歷 entrySet，key 和 value 交換
        return null;
    }

    /**
     * 練習 3：合併兩個 Map
     * 如果 key 重複，value 相加（假設 value 是 Integer）
     * 
     * 範例：
     * 輸入：{a=1, b=2} 和 {b=3, c=4}
     * 預期：{a=1, b=5, c=4}
     */
    public static Map<String, Integer> mergeMaps(
            Map<String, Integer> map1,
            Map<String, Integer> map2) {
        // TODO: 請實作此方法
        // 提示：使用 merge() 方法或 getOrDefault()
        return null;
    }

    /**
     * 練習 4：根據 value 排序 Map
     * 回傳按照 value 升序排列的 List<Map.Entry>
     * 
     * 範例：
     * 輸入：{apple=5, banana=2, cherry=8, date=1}
     * 預期：[date=1, banana=2, apple=5, cherry=8]
     */
    public static List<Map.Entry<String, Integer>> sortByValue(
            Map<String, Integer> map) {
        // TODO: 請實作此方法
        // 提示：
        // 1. 取得 entrySet 的 List
        // 2. 使用 Comparator.comparing(Map.Entry::getValue)
        return null;
    }

    /**
     * 練習 5：找出 value 最大的 key
     * 
     * 範例：
     * 輸入：{Alice=85, Bob=92, Charlie=78}
     * 預期：Bob
     */
    public static <K, V extends Comparable<V>> K findKeyWithMaxValue(Map<K, V> map) {
        // TODO: 請實作此方法
        // 提示：遍歷 entrySet，記錄最大值和對應的 key
        return null;
    }

    /**
     * 練習 6：分組
     * 將字串列表按照首字母分組
     * 
     * 範例：
     * 輸入：["apple", "banana", "apricot", "blueberry", "cherry"]
     * 預期：{a=[apple, apricot], b=[banana, blueberry], c=[cherry]}
     */
    public static Map<Character, List<String>> groupByFirstLetter(List<String> words) {
        // TODO: 請實作此方法
        // 提示：使用 computeIfAbsent 初始化 List
        return null;
    }

    /**
     * 練習 7：使用 Map 統計單字出現次數
     * 
     * 範例：
     * 輸入："the quick brown fox jumps over the lazy dog the"
     * 預期：{the=3, quick=1, brown=1, fox=1, jumps=1, over=1, lazy=1, dog=1}
     */
    public static Map<String, Integer> wordCount(String sentence) {
        // TODO: 請實作此方法
        // 提示：先 split(" ")，再統計
        return null;
    }

    /**
     * 練習 8：實作簡易快取
     * 使用 computeIfAbsent 實作一個快取機制
     * 如果 key 存在，直接回傳 value
     * 如果 key 不存在，計算並存入後回傳
     */
    public static int getOrCompute(Map<Integer, Integer> cache, int n) {
        // TODO: 請實作此方法
        // 提示：computeIfAbsent(n, key -> expensiveComputation(key))
        // expensiveComputation 可以用 n * n 模擬
        return 0;
    }

    // ============================
    // 測試程式碼
    // ============================
    public static void main(String[] args) {
        System.out.println("=== Map 練習題測試 ===\n");

        // 測試練習 1
        System.out.println("【練習 1：字元頻率】");
        Map<Character, Integer> freq = charFrequency("hello");
        System.out.println("輸入: \"hello\"");
        System.out.println("結果: " + freq);
        System.out.println("預期: l=2, e=1, h=1, o=1\n");

        // 測試練習 2
        System.out.println("【練習 2：反轉 Map】");
        Map<String, Integer> original = new HashMap<>();
        original.put("a", 1);
        original.put("b", 2);
        original.put("c", 3);
        Map<Integer, String> reversed = reverseMap(original);
        System.out.println("輸入: " + original);
        System.out.println("結果: " + reversed);
        System.out.println("預期: {1=a, 2=b, 3=c}\n");

        // 測試練習 3
        System.out.println("【練習 3：合併 Map】");
        Map<String, Integer> m1 = new HashMap<>();
        m1.put("a", 1);
        m1.put("b", 2);
        Map<String, Integer> m2 = new HashMap<>();
        m2.put("b", 3);
        m2.put("c", 4);
        Map<String, Integer> merged = mergeMaps(m1, m2);
        System.out.println("輸入: " + m1 + " 和 " + m2);
        System.out.println("結果: " + merged);
        System.out.println("預期: {a=1, b=5, c=4}\n");

        // 測試練習 4
        System.out.println("【練習 4：依 value 排序】");
        Map<String, Integer> fruits = new HashMap<>();
        fruits.put("apple", 5);
        fruits.put("banana", 2);
        fruits.put("cherry", 8);
        fruits.put("date", 1);
        List<Map.Entry<String, Integer>> sortedEntries = sortByValue(fruits);
        System.out.println("輸入: " + fruits);
        System.out.println("結果: " + sortedEntries);
        System.out.println("預期: [date=1, banana=2, apple=5, cherry=8]\n");

        // 測試練習 6
        System.out.println("【練習 6：分組】");
        List<String> words = Arrays.asList("apple", "banana", "apricot", "blueberry", "cherry");
        Map<Character, List<String>> grouped = groupByFirstLetter(words);
        System.out.println("輸入: " + words);
        System.out.println("結果: " + grouped);
        System.out.println("預期: {a=[apple, apricot], b=[banana, blueberry], c=[cherry]}\n");

        // 測試練習 7
        System.out.println("【練習 7：單字統計】");
        String sentence = "the quick brown fox the lazy dog the";
        Map<String, Integer> wordCounts = wordCount(sentence);
        System.out.println("輸入: \"" + sentence + "\"");
        System.out.println("結果: " + wordCounts);
        System.out.println("預期: {the=3, quick=1, ...}\n");

        System.out.println("=== 測試結束 ===");
    }
}
