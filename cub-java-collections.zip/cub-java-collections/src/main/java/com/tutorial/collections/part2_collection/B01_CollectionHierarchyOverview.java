package com.tutorial.collections.part2_collection;

/**
 * ============================================================
 * 【章節標題】B01 - Collection 繼承體系總覽
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 Java Collections Framework (JCF) 的整體架構
 * 2. 理解介面（Interface）與實作（Implementation）的關係
 * 3. 掌握面向介面編程的好處
 * 
 * ============================================================
 */
public class B01_CollectionHierarchyOverview {

    public static void main(String[] args) {
        System.out.println("=== B01: Collection 繼承體系總覽 ===\n");

        // ============================
        // 1. JCF 繼承體系圖
        // ============================
        /*
         * Java Collections Framework (JCF) 的核心介面繼承體系：
         * 
         *                    Iterable<E>
         *                        │
         *                        ▼
         *                  Collection<E>
         *                  ╱     │      ╲
         *                 ╱      │       ╲
         *                ▼       ▼        ▼
         *            List<E>  Set<E>   Queue<E>
         *              │        │         │
         *         ┌────┴────┐   │    ┌────┴────┐
         *         ▼         ▼   ▼    ▼         ▼
         *    ArrayList  LinkedList  HashSet  PriorityQueue
         *                    │       │
         *                    │       ▼
         *                    │    TreeSet
         *                    │
         *                    ▼
         *          （同時實作 List 和 Deque）
         * 
         * 注意：Map<K,V> 是獨立的體系，不繼承 Collection！
         */
        System.out.println("【1. JCF 繼承體系】");
        System.out.println();
        System.out.println("                  Iterable<E>");
        System.out.println("                      │");
        System.out.println("                      ▼");
        System.out.println("                Collection<E>");
        System.out.println("               ╱     │     ╲");
        System.out.println("              ╱      │      ╲");
        System.out.println("             ▼       ▼       ▼");
        System.out.println("         List<E>  Set<E>  Queue<E>");
        System.out.println("           │        │        │");
        System.out.println("      ┌────┴────┐   │   ┌────┴────┐");
        System.out.println("      ▼         ▼   ▼   ▼         ▼");
        System.out.println(" ArrayList  LinkedList  HashSet  PriorityQueue");
        System.out.println("                 │        │");
        System.out.println("                 │        ▼");
        System.out.println("                 │     TreeSet");
        System.out.println("                 │");
        System.out.println("      (同時實作 List 和 Deque)");
        System.out.println();

        // ============================
        // 2. 介面 vs 實作
        // ============================
        /*
         * 為什麼我們寫：
         *   List<String> list = new ArrayList<>();
         * 
         * 而不是：
         *   ArrayList<String> list = new ArrayList<>();
         * 
         * 【面向介面編程的好處】
         * 1. 解耦合：程式碼只依賴介面，不依賴具體實作
         * 2. 易替換：輕易就能換成 LinkedList
         * 3. 更靈活：方法參數用 List 型態可以接受任何 List 實作
         */
        System.out.println("【2. 介面 vs 實作】");
        System.out.println();
        System.out.println("推薦寫法：");
        System.out.println("  List<String> list = new ArrayList<>();");
        System.out.println();
        System.out.println("不推薦寫法：");
        System.out.println("  ArrayList<String> list = new ArrayList<>();");
        System.out.println();
        System.out.println("原因：面向介面編程的好處");
        System.out.println("  ✓ 解耦合：程式碼只依賴介面規範");
        System.out.println("  ✓ 易替換：new ArrayList<>() → new LinkedList<>() 輕鬆切換");
        System.out.println("  ✓ 更靈活：方法參數用 List 可接受任何 List 實作");
        System.out.println();

        // ============================
        // 3. 各介面的特性
        // ============================
        /*
         * List<E>：有序、可重複、可用 index 存取
         * Set<E>：唯一性、無重複元素
         * Queue<E>：先進先出（FIFO）、用於排隊場景
         */
        System.out.println("【3. 各介面的特性】");
        System.out.println();
        System.out.println("┌───────────┬────────────────────────────────────────┐");
        System.out.println("│  介面     │  特性                                  │");
        System.out.println("├───────────┼────────────────────────────────────────┤");
        System.out.println("│ List<E>   │ 有序、可重複、可用 index 存取          │");
        System.out.println("│ Set<E>    │ 無序（通常）、不可重複                 │");
        System.out.println("│ Queue<E>  │ 先進先出（FIFO）、用於排隊場景         │");
        System.out.println("└───────────┴────────────────────────────────────────┘");
        System.out.println();

        // ============================
        // 4. 常用實作類別
        // ============================
        System.out.println("【4. 常用實作類別】");
        System.out.println();
        System.out.println("List 實作：");
        System.out.println("  • ArrayList：底層是陣列，隨機訪問快");
        System.out.println("  • LinkedList：底層是鏈結串列，插入刪除快");
        System.out.println();
        System.out.println("Set 實作：");
        System.out.println("  • HashSet：底層是 HashMap，無序");
        System.out.println("  • LinkedHashSet：維持插入順序");
        System.out.println("  • TreeSet：底層是紅黑樹，自動排序");
        System.out.println();
        System.out.println("Queue 實作：");
        System.out.println("  • LinkedList：也實作了 Queue 介面");
        System.out.println("  • PriorityQueue：優先權佇列");
        System.out.println("  • ArrayDeque：雙端佇列，效能較好");
        System.out.println();

        // ============================
        // 5. 選擇實作類別的決策樹
        // ============================
        System.out.println("【5. 如何選擇？】");
        System.out.println();
        System.out.println("需要儲存「元素」（單一值）？");
        System.out.println("  ├── 需要順序和 index → List");
        System.out.println("  │     ├── 頻繁隨機訪問 → ArrayList ✓");
        System.out.println("  │     └── 頻繁頭尾操作 → LinkedList");
        System.out.println("  │");
        System.out.println("  ├── 需要唯一性（去重）→ Set");
        System.out.println("  │     ├── 不需要順序 → HashSet ✓");
        System.out.println("  │     ├── 需要插入順序 → LinkedHashSet");
        System.out.println("  │     └── 需要排序 → TreeSet");
        System.out.println("  │");
        System.out.println("  └── 需要排隊（FIFO/優先權）→ Queue");
        System.out.println("        ├── 一般 FIFO → LinkedList / ArrayDeque");
        System.out.println("        └── 優先權處理 → PriorityQueue");
        System.out.println();
        System.out.println("需要儲存「鍵值對」？→ 請看 Part 3: Map");

        System.out.println("\n=== Demo 結束 ===");
    }
}
