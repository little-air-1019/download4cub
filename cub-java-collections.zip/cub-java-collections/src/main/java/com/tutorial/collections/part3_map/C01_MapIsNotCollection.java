package com.tutorial.collections.part3_map;

/**
 * ============================================================
 * 【章節標題】C01 - Map 不是 Collection
 * ============================================================
 * 
 * 【學習目標】
 * 1. 釐清 Map 與 Collection 的關係
 * 2. 理解為什麼 Map 是獨立的介面
 * 3. 了解 JCF 的完整架構
 * 
 * ============================================================
 */
public class C01_MapIsNotCollection {

    public static void main(String[] args) {
        System.out.println("=== C01: Map 不是 Collection ===\n");

        // ============================
        // 1. Map 不繼承 Collection
        // ============================
        /*
         * 很多人誤以為 Map 是 Collection 的一部分，
         * 實際上 Map<K, V> 是獨立的介面！
         * 
         * 完整的 JCF 架構：
         * 
         * ┌─────────────────────────────────────────────────────────┐
         * │              Java Collections Framework                  │
         * ├────────────────────────────┬────────────────────────────┤
         * │       Collection 體系      │         Map 體系           │
         * │                            │                            │
         * │        Iterable<E>         │                            │
         * │            │               │                            │
         * │       Collection<E>        │         Map<K,V>           │
         * │        /   │   \           │        /    |    \         │
         * │     List  Set  Queue       │   HashMap TreeMap LinkedH │
         * └────────────────────────────┴────────────────────────────┘
         */
        System.out.println("【1. Map 不繼承 Collection】");
        System.out.println();
        System.out.println("Collection 存放「單一元素」：List<E>, Set<E>, Queue<E>");
        System.out.println("Map 存放「鍵值對」：Map<K, V>");
        System.out.println();
        System.out.println("它們是平行關係，不是繼承關係！");
        System.out.println();

        // ============================
        // 2. 為什麼 Map 是獨立的
        // ============================
        /*
         * Collection<E> 的 add(E e) 方法：加入「一個」元素
         * Map<K, V> 的 put(K key, V value) 方法：加入「一對」鍵值
         * 
         * 兩者的操作語意完全不同，無法統一介面。
         */
        System.out.println("【2. 為什麼 Map 是獨立的】");
        System.out.println();
        System.out.println("Collection.add(E e)：加入一個元素");
        System.out.println("Map.put(K key, V value)：加入一對鍵值");
        System.out.println();
        System.out.println("兩者語意不同，無法統一介面！");
        System.out.println();

        // ============================
        // 3. JCF 完整架構圖
        // ============================
        System.out.println("【3. JCF 完整架構圖】");
        System.out.println();
        System.out.println("╔═══════════════════════════════════════════════════════════╗");
        System.out.println("║               Java Collections Framework                   ║");
        System.out.println("╠═════════════════════════════╦═════════════════════════════╣");
        System.out.println("║      Collection 體系        ║          Map 體系           ║");
        System.out.println("╠═════════════════════════════╬═════════════════════════════╣");
        System.out.println("║                             ║                             ║");
        System.out.println("║       Iterable<E>           ║                             ║");
        System.out.println("║           │                 ║                             ║");
        System.out.println("║      Collection<E>          ║         Map<K,V>            ║");
        System.out.println("║       /    |    \\           ║        /    |    \\          ║");
        System.out.println("║    List   Set   Queue       ║   HashMap TreeMap Concurrent║");
        System.out.println("║     │      │      │         ║     │       │        │      ║");
        System.out.println("║  ArrayList HashSet LinkedList│  LinkedHM       ConcurrentHM║");
        System.out.println("║  LinkedList TreeSet  ...    ║                             ║");
        System.out.println("║                             ║                             ║");
        System.out.println("╚═════════════════════════════╩═════════════════════════════╝");
        System.out.println();

        // ============================
        // 4. Map 的方法體系
        // ============================
        System.out.println("【4. Map 有自己的方法體系】");
        System.out.println();
        System.out.println("Map 特有的方法：");
        System.out.println("  • put(K key, V value) - 新增/更新");
        System.out.println("  • get(K key) - 根據 key 取值");
        System.out.println("  • containsKey(K) / containsValue(V)");
        System.out.println("  • keySet() - 所有 key 組成的 Set");
        System.out.println("  • values() - 所有 value 組成的 Collection");
        System.out.println("  • entrySet() - 所有鍵值對組成的 Set<Entry>");
        System.out.println();

        // ============================
        // 5. Map 與 Collection 的關聯
        // ============================
        /*
         * 雖然 Map 不是 Collection，但它們有關聯：
         * - Set<K> keySet()：key 組成的 Set
         * - Collection<V> values()：value 組成的 Collection
         * - Set<Map.Entry<K,V>> entrySet()：Entry 組成的 Set
         * 
         * 這些方法回傳的是 Collection 視圖（View）
         */
        System.out.println("【5. Map 與 Collection 的關聯】");
        System.out.println();
        System.out.println("Map 可以「產生」Collection 視圖：");
        System.out.println();
        System.out.println("  map.keySet()   → Set<K>");
        System.out.println("  map.values()   → Collection<V>");
        System.out.println("  map.entrySet() → Set<Map.Entry<K,V>>");
        System.out.println();
        System.out.println("所以 Map 可以透過這些視圖進行遍歷！");

        System.out.println("\n=== Demo 結束 ===");
    }
}
