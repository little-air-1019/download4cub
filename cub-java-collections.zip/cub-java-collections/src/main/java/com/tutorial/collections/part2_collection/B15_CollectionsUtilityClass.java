package com.tutorial.collections.part2_collection;

import java.util.*;

/**
 * ============================================================
 * 【章節標題】B15 - Collections 工具類
 * ============================================================
 * 
 * 【學習目標】
 * 1. 掌握 java.util.Collections 的常用方法
 * 2. 學會建立不可修改的集合
 * 3. 了解執行緒安全的集合包裝
 * 
 * ============================================================
 */
public class B15_CollectionsUtilityClass {

    public static void main(String[] args) {
        System.out.println("=== B15: Collections 工具類 ===\n");

        // ============================
        // 1. sort() - 排序
        // ============================
        System.out.println("【1. sort() - 排序】");
        
        List<Integer> numbers = new ArrayList<>(Arrays.asList(5, 2, 8, 1, 9));
        System.out.println("原始: " + numbers);
        
        Collections.sort(numbers);
        System.out.println("sort() 後: " + numbers);
        System.out.println();

        // ============================
        // 2. reverse() - 反轉
        // ============================
        System.out.println("【2. reverse() - 反轉】");
        
        List<String> letters = new ArrayList<>(Arrays.asList("A", "B", "C", "D"));
        System.out.println("原始: " + letters);
        
        Collections.reverse(letters);
        System.out.println("reverse() 後: " + letters);
        System.out.println();

        // ============================
        // 3. shuffle() - 隨機打亂
        // ============================
        System.out.println("【3. shuffle() - 隨機打亂】");
        
        List<Integer> cards = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        System.out.println("原始: " + cards);
        
        Collections.shuffle(cards);
        System.out.println("shuffle() 後: " + cards);
        System.out.println("（每次執行結果不同）");
        System.out.println();

        // ============================
        // 4. binarySearch() - 二分搜尋
        // ============================
        System.out.println("【4. binarySearch() - 二分搜尋】");
        
        List<Integer> sorted = Arrays.asList(10, 20, 30, 40, 50);
        System.out.println("已排序 List: " + sorted);
        
        int index = Collections.binarySearch(sorted, 30);
        System.out.println("binarySearch(30) = " + index);
        
        int notFound = Collections.binarySearch(sorted, 35);
        System.out.println("binarySearch(35) = " + notFound + "（負數表示找不到）");
        System.out.println("⚠️ 使用前必須先排序！");
        System.out.println();

        // ============================
        // 5. max() / min() - 最大最小值
        // ============================
        System.out.println("【5. max() / min() - 最大最小值】");
        
        List<Integer> nums = Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6);
        System.out.println("List: " + nums);
        System.out.println("max() = " + Collections.max(nums));
        System.out.println("min() = " + Collections.min(nums));
        System.out.println();

        // ============================
        // 6. frequency() - 出現次數
        // ============================
        System.out.println("【6. frequency() - 出現次數】");
        
        List<String> fruits = Arrays.asList("apple", "banana", "apple", "cherry", "apple");
        System.out.println("List: " + fruits);
        System.out.println("frequency(\"apple\") = " + Collections.frequency(fruits, "apple"));
        System.out.println();

        // ============================
        // 7. fill() - 填充
        // ============================
        System.out.println("【7. fill() - 填充】");
        
        List<String> list = new ArrayList<>(Arrays.asList("A", "B", "C"));
        System.out.println("原始: " + list);
        
        Collections.fill(list, "X");
        System.out.println("fill(\"X\") 後: " + list);
        System.out.println();

        // ============================
        // 8. unmodifiableXxx() - 不可修改
        // ============================
        System.out.println("【8. unmodifiableXxx() - 不可修改的集合】");
        
        List<String> original = new ArrayList<>(Arrays.asList("A", "B", "C"));
        List<String> unmodifiable = Collections.unmodifiableList(original);
        
        System.out.println("unmodifiableList: " + unmodifiable);
        System.out.println("嘗試修改...");
        try {
            unmodifiable.add("D");
        } catch (UnsupportedOperationException e) {
            System.out.println("→ UnsupportedOperationException！");
        }
        System.out.println();
        System.out.println("相關方法：");
        System.out.println("  Collections.unmodifiableSet(set)");
        System.out.println("  Collections.unmodifiableMap(map)");
        System.out.println();

        // ============================
        // 9. synchronizedXxx() - 執行緒安全
        // ============================
        System.out.println("【9. synchronizedXxx() - 執行緒安全】");
        System.out.println();
        System.out.println("預設的 ArrayList、HashSet、HashMap 不是執行緒安全的");
        System.out.println();
        System.out.println("包裝成執行緒安全版本：");
        System.out.println("  List<T> syncList = Collections.synchronizedList(list);");
        System.out.println("  Set<T> syncSet = Collections.synchronizedSet(set);");
        System.out.println("  Map<K,V> syncMap = Collections.synchronizedMap(map);");
        System.out.println();
        System.out.println("⚠️ 注意：遍歷時仍需手動同步");
        System.out.println("   synchronized(syncList) { for(T item : syncList) {...} }");
        System.out.println();

        // ============================
        // 10. emptyXxx() / singletonXxx()
        // ============================
        System.out.println("【10. emptyXxx() / singletonXxx()】");
        System.out.println();
        
        // 空集合（不可修改）
        List<String> emptyList = Collections.emptyList();
        Set<String> emptySet = Collections.emptySet();
        Map<String, Integer> emptyMap = Collections.emptyMap();
        
        System.out.println("空集合（不可修改）：");
        System.out.println("  Collections.emptyList()");
        System.out.println("  Collections.emptySet()");
        System.out.println("  Collections.emptyMap()");
        System.out.println();
        
        // 單元素集合（不可修改）
        List<String> singleList = Collections.singletonList("only");
        Set<String> singleSet = Collections.singleton("only");
        Map<String, Integer> singleMap = Collections.singletonMap("key", 1);
        
        System.out.println("單元素集合（不可修改）：");
        System.out.println("  Collections.singletonList(\"only\")");
        System.out.println("  Collections.singleton(\"only\")");
        System.out.println("  Collections.singletonMap(\"key\", 1)");
        System.out.println();
        System.out.println("Java 9+ 更簡潔的寫法：");
        System.out.println("  List.of(), Set.of(), Map.of()");

        System.out.println("\n=== Demo 結束 ===");
    }
}
