package com.tutorial.collections.part1_array.exercises;

import java.util.Arrays;

/**
 * ============================================================
 * 【練習題】Array 練習
 * ============================================================
 * 
 * 完成以下練習題，加深對陣列操作的理解。
 * 每個方法都有 TODO 標記，請實作該方法。
 * 執行 main() 可以測試你的實作。
 * 
 * ============================================================
 */
public class ArrayExercises {

    /**
     * 練習 1：找出陣列中的最大值
     * 
     * 範例：
     * 輸入：{3, 1, 4, 1, 5, 9, 2, 6}
     * 輸出：9
     * 
     * @param arr 整數陣列（假設不為空）
     * @return 陣列中的最大值
     */
    public static int findMax(int[] arr) {
        // TODO: 請實作此方法
        // 提示：
        // 1. 假設第一個元素是最大值
        // 2. 遍歷陣列，如果發現更大的就更新
        // 3. 回傳最大值
        return 0;
    }

    /**
     * 練習 2：反轉陣列（in-place）
     * 
     * 範例：
     * 輸入：{1, 2, 3, 4, 5}
     * 執行後：{5, 4, 3, 2, 1}
     * 
     * 要求：不要建立新陣列，直接在原陣列上操作
     * 
     * @param arr 要反轉的陣列
     */
    public static void reverseArray(int[] arr) {
        // TODO: 請實作此方法
        // 提示：
        // 1. 使用雙指標：left 從 0 開始，right 從 length-1 開始
        // 2. 交換 arr[left] 和 arr[right]
        // 3. left 往右移，right 往左移
        // 4. 當 left >= right 時停止
    }

    /**
     * 練習 3：移除陣列中的重複元素，回傳新陣列
     * 
     * 範例：
     * 輸入：{1, 2, 2, 3, 3, 3, 4}
     * 輸出：{1, 2, 3, 4}
     * 
     * 提示：可使用 Arrays 工具類
     * 
     * @param arr 可能包含重複元素的已排序陣列
     * @return 去除重複後的新陣列
     */
    public static int[] removeDuplicates(int[] arr) {
        // TODO: 請實作此方法
        // 提示（方法一 - 雙指標）：
        // 1. 建立一個足夠大的暫存陣列
        // 2. 遍歷原陣列，只有當元素與前一個不同時才加入
        // 3. 使用 Arrays.copyOf 回傳正確大小的陣列
        //
        // 提示（方法二 - 使用 Set，但這是 Part 2 的內容）：
        // 可以先用方法一，之後學到 Set 再回來用更簡潔的方式實作
        return null;
    }

    /**
     * 練習 4：計算陣列中所有元素的平均值
     * 
     * 範例：
     * 輸入：{10, 20, 30, 40, 50}
     * 輸出：30.0
     * 
     * @param arr 整數陣列（假設不為空）
     * @return 平均值
     */
    public static double calculateAverage(int[] arr) {
        // TODO: 請實作此方法
        // 提示：
        // 1. 計算總和
        // 2. 除以陣列長度
        // 3. 注意：要轉換成 double 才能得到小數
        return 0.0;
    }

    /**
     * 練習 5：合併兩個已排序的陣列，回傳新的已排序陣列
     * 
     * 範例：
     * 輸入：arr1 = {1, 3, 5}, arr2 = {2, 4, 6}
     * 輸出：{1, 2, 3, 4, 5, 6}
     * 
     * 進階挑戰：嘗試用 O(n) 時間複雜度完成（雙指標法）
     * 
     * @param arr1 第一個已排序陣列
     * @param arr2 第二個已排序陣列
     * @return 合併後的已排序陣列
     */
    public static int[] mergeSortedArrays(int[] arr1, int[] arr2) {
        // TODO: 請實作此方法
        // 
        // 簡單方法：
        // 1. 建立新陣列，長度為 arr1.length + arr2.length
        // 2. 複製兩個陣列的內容進去
        // 3. 使用 Arrays.sort() 排序
        //
        // 進階方法（雙指標，O(n)）：
        // 1. 建立結果陣列
        // 2. 使用兩個指標，分別指向 arr1 和 arr2
        // 3. 比較兩個指標指向的元素，較小的放入結果陣列
        // 4. 移動對應的指標
        // 5. 處理剩餘元素
        return null;
    }

    // ============================
    // 測試程式碼
    // ============================
    public static void main(String[] args) {
        System.out.println("=== Array 練習題測試 ===\n");

        // 測試練習 1：找最大值
        System.out.println("【練習 1：找出最大值】");
        int[] test1 = {3, 1, 4, 1, 5, 9, 2, 6};
        int max = findMax(test1);
        System.out.println("輸入: " + Arrays.toString(test1));
        System.out.println("最大值: " + max);
        System.out.println("預期結果: 9");
        System.out.println("測試" + (max == 9 ? "通過 ✓" : "失敗 ✗") + "\n");

        // 測試練習 2：反轉陣列
        System.out.println("【練習 2：反轉陣列】");
        int[] test2 = {1, 2, 3, 4, 5};
        System.out.println("輸入: " + Arrays.toString(test2));
        reverseArray(test2);
        System.out.println("反轉後: " + Arrays.toString(test2));
        System.out.println("預期結果: [5, 4, 3, 2, 1]");
        System.out.println("測試" + (Arrays.equals(test2, new int[]{5, 4, 3, 2, 1}) ? "通過 ✓" : "失敗 ✗") + "\n");

        // 測試練習 3：移除重複
        System.out.println("【練習 3：移除重複元素】");
        int[] test3 = {1, 2, 2, 3, 3, 3, 4};
        int[] result3 = removeDuplicates(test3);
        System.out.println("輸入: " + Arrays.toString(test3));
        System.out.println("結果: " + Arrays.toString(result3));
        System.out.println("預期結果: [1, 2, 3, 4]");
        System.out.println("測試" + (Arrays.equals(result3, new int[]{1, 2, 3, 4}) ? "通過 ✓" : "失敗 ✗") + "\n");

        // 測試練習 4：計算平均值
        System.out.println("【練習 4：計算平均值】");
        int[] test4 = {10, 20, 30, 40, 50};
        double avg = calculateAverage(test4);
        System.out.println("輸入: " + Arrays.toString(test4));
        System.out.println("平均值: " + avg);
        System.out.println("預期結果: 30.0");
        System.out.println("測試" + (avg == 30.0 ? "通過 ✓" : "失敗 ✗") + "\n");

        // 測試練習 5：合併排序陣列
        System.out.println("【練習 5：合併已排序陣列】");
        int[] arr1 = {1, 3, 5};
        int[] arr2 = {2, 4, 6};
        int[] merged = mergeSortedArrays(arr1, arr2);
        System.out.println("輸入: " + Arrays.toString(arr1) + " + " + Arrays.toString(arr2));
        System.out.println("合併後: " + Arrays.toString(merged));
        System.out.println("預期結果: [1, 2, 3, 4, 5, 6]");
        System.out.println("測試" + (Arrays.equals(merged, new int[]{1, 2, 3, 4, 5, 6}) ? "通過 ✓" : "失敗 ✗") + "\n");

        System.out.println("=== 測試結束 ===");
    }
}
