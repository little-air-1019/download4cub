package com.tutorial.collections.part2_collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ============================================================
 * 【章節標題】B11 - Comparable 介面
 * ============================================================
 * 
 * 【學習目標】
 * 1. 理解 Comparable 介面與自然排序
 * 2. 掌握 compareTo() 的回傳值規則
 * 3. 學會為自訂類別實作 Comparable
 * 
 * ============================================================
 */
public class B11_ComparableInterface {

    public static void main(String[] args) {
        System.out.println("=== B11: Comparable 介面 ===\n");

        // ============================
        // Part A: 什麼是 Comparable
        // ============================
        /*
         * java.lang.Comparable<T> 介面
         * 
         * 定義物件的「自然排序」（Natural Ordering）
         * 只有一個抽象方法：int compareTo(T o)
         */
        System.out.println("【Part A: 什麼是 Comparable】");
        System.out.println("Comparable<T> 介面定義物件的「自然排序」");
        System.out.println();
        System.out.println("抽象方法：int compareTo(T o)");
        System.out.println();

        // ============================
        // Part B: compareTo 回傳值規則
        // ============================
        /*
         * compareTo(other) 的回傳值：
         * - 負數：this < other（this 排在前面）
         * - 零：this == other（相等）
         * - 正數：this > other（this 排在後面）
         * 
         * 記憶技巧：想像成 this - other 的結果
         */
        System.out.println("【Part B: compareTo 回傳值規則】");
        System.out.println("┌─────────────┬─────────────────────────┐");
        System.out.println("│   回傳值    │          意義           │");
        System.out.println("├─────────────┼─────────────────────────┤");
        System.out.println("│   負數      │ this < other（排前面）  │");
        System.out.println("│   零        │ this == other（相等）   │");
        System.out.println("│   正數      │ this > other（排後面）  │");
        System.out.println("└─────────────┴─────────────────────────┘");
        System.out.println();
        System.out.println("記憶技巧：想像成 this - other");
        System.out.println();

        // ============================
        // Part C: JDK 內建的 Comparable
        // ============================
        System.out.println("【Part C: JDK 內建的 Comparable】");
        
        // String 的自然排序（字典序）
        List<String> strings = new ArrayList<>();
        strings.add("Banana");
        strings.add("Apple");
        strings.add("Cherry");
        
        System.out.println("String 排序前: " + strings);
        Collections.sort(strings);
        System.out.println("String 排序後: " + strings);
        System.out.println("（字典序）");
        System.out.println();
        
        // Integer 的自然排序（數值）
        List<Integer> numbers = new ArrayList<>();
        numbers.add(5);
        numbers.add(2);
        numbers.add(8);
        numbers.add(1);
        
        System.out.println("Integer 排序前: " + numbers);
        Collections.sort(numbers);
        System.out.println("Integer 排序後: " + numbers);
        System.out.println("（數值大小）");
        System.out.println();

        // ============================
        // Part D: 自訂類別實作 Comparable
        // ============================
        System.out.println("【Part D: 自訂類別實作 Comparable】");
        
        List<Product> products = new ArrayList<>();
        products.add(new Product("Laptop", 1200.00));
        products.add(new Product("Phone", 800.00));
        products.add(new Product("Tablet", 500.00));
        products.add(new Product("Watch", 300.00));
        
        System.out.println("Product 排序前（依價格）:");
        for (Product p : products) {
            System.out.println("  " + p);
        }
        
        Collections.sort(products);  // 使用 compareTo
        
        System.out.println("\nProduct 排序後:");
        for (Product p : products) {
            System.out.println("  " + p);
        }
        System.out.println();

        // ============================
        // Part E: compareTo 實作技巧
        // ============================
        System.out.println("【Part E: compareTo 實作技巧】");
        System.out.println();
        System.out.println("// 數值比較：使用包裝類別的 compare");
        System.out.println("return Integer.compare(this.score, other.score);");
        System.out.println();
        System.out.println("// 字串比較：呼叫 String.compareTo");
        System.out.println("return this.name.compareTo(other.name);");
        System.out.println();
        System.out.println("// 避免直接相減（可能溢位）");
        System.out.println("❌ return this.value - other.value;  // 可能溢位！");
        System.out.println("✓  return Integer.compare(this.value, other.value);");
        System.out.println();

        // ============================
        // Part F: Comparable 的限制
        // ============================
        System.out.println("【Part F: Comparable 的限制】");
        System.out.println();
        System.out.println("1. 一個類別只能有一種自然排序");
        System.out.println("   → Product 只能選擇依價格「或」依名稱");
        System.out.println();
        System.out.println("2. 如果需要多種排序方式？");
        System.out.println("   → 使用 Comparator（下一節）");
        System.out.println();
        System.out.println("3. 無法修改第三方類別的排序方式");
        System.out.println("   → 使用 Comparator（下一節）");

        System.out.println("\n=== Demo 結束 ===");
    }
}

// ============================
// 自訂類別：實作 Comparable
// ============================
class Product implements Comparable<Product> {
    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public int compareTo(Product other) {
        // 依價格升序排列
        return Double.compare(this.price, other.price);
    }

    @Override
    public String toString() {
        return name + ": $" + price;
    }
}
