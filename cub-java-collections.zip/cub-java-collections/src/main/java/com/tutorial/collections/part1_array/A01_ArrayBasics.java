package com.tutorial.collections.part1_array;

/**
 * ============================================================
 * 【章節標題】A01 - Array 基礎
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解陣列的宣告方式
 * 2. 掌握靜態初始化與動態初始化
 * 3. 學會存取陣列元素
 * 4. 理解基本類型陣列與物件陣列的差異
 * 
 * ============================================================
 */
public class A01_ArrayBasics {

    public static void main(String[] args) {
        System.out.println("=== A01: Array 基礎 ===\n");

        // ============================
        // 1. 陣列宣告的兩種方式
        // ============================
        /*
         * Java 支援兩種宣告陣列的語法：
         * - int[] arr  ← 推薦寫法（型態與變數名稱分離更清楚）
         * - int arr[]  ← C 風格寫法（也可以，但不建議）
         */
        System.out.println("【1. 陣列宣告方式】");
        int[] style1;  // 推薦：型態是「int 陣列」
        int style2[];  // C 風格：變數名後加中括號
        System.out.println("兩種宣告方式：int[] arr 或 int arr[]");
        System.out.println("推薦使用 int[] arr，語意更清晰\n");

        // ============================
        // 2. 靜態初始化
        // ============================
        /*
         * 靜態初始化：宣告時直接給定初始值
         * 陣列長度由初始值的數量決定
         */
        System.out.println("【2. 靜態初始化】");
        int[] numbers = {1, 2, 3, 4, 5};
        String[] fruits = {"Apple", "Banana", "Cherry"};

        System.out.println("int[] numbers = {1, 2, 3, 4, 5};");
        System.out.println("陣列長度: " + numbers.length);
        System.out.print("陣列內容: ");
        for (int n : numbers) {
            System.out.print(n + " ");
        }
        System.out.println("\n");

        // ============================
        // 3. 動態初始化
        // ============================
        /*
         * 動態初始化：先指定長度，之後再賦值
         * - 數值型別預設為 0
         * - boolean 預設為 false
         * - 物件參考預設為 null
         */
        System.out.println("【3. 動態初始化】");
        int[] scores = new int[5];  // 建立長度為 5 的 int 陣列，預設值為 0
        System.out.println("int[] scores = new int[5];");
        System.out.print("預設值: ");
        for (int s : scores) {
            System.out.print(s + " ");
        }
        System.out.println();

        // 賦值
        scores[0] = 85;
        scores[1] = 90;
        scores[2] = 78;
        scores[3] = 92;
        scores[4] = 88;
        System.out.print("賦值後: ");
        for (int s : scores) {
            System.out.print(s + " ");
        }
        System.out.println("\n");

        // ============================
        // 4. 存取元素
        // ============================
        /*
         * 陣列元素透過索引（index）存取
         * 索引從 0 開始，最大為 length - 1
         * 
         * arr[0] 是第一個元素
         * arr[arr.length - 1] 是最後一個元素
         */
        System.out.println("【4. 存取元素】");
        System.out.println("fruits[0] = " + fruits[0]);  // Apple
        System.out.println("fruits[1] = " + fruits[1]);  // Banana
        System.out.println("fruits[2] = " + fruits[2]);  // Cherry

        // 修改元素
        fruits[1] = "Blueberry";
        System.out.println("修改 fruits[1] = \"Blueberry\" 後: " + fruits[1]);
        System.out.println();

        // ============================
        // 5. 陣列長度：length 屬性
        // ============================
        /*
         * 【重要】arr.length 是「屬性」，不是方法！
         * - 陣列：arr.length（沒有括號）
         * - String：str.length()（有括號，是方法）
         * - Collection：list.size()（是方法）
         * 
         * 陣列長度一旦建立就固定，無法改變！
         */
        System.out.println("【5. 陣列長度】");
        System.out.println("numbers.length = " + numbers.length);
        System.out.println("⚠️ 注意：length 是屬性，不是方法，不需要加 ()");
        System.out.println("⚠️ 陣列長度建立後就固定，無法動態改變！\n");

        // ============================
        // 6. 基本類型陣列 vs 物件陣列
        // ============================
        /*
         * 基本類型陣列：直接存放數值
         * - int[], double[], boolean[], char[] 等
         * - 預設值為該類型的 zero value（0, 0.0, false, '\u0000'）
         * 
         * 物件陣列：存放物件的參考（reference）
         * - String[], Object[], 自訂類別[] 等
         * - 預設值為 null
         */
        System.out.println("【6. 基本類型陣列 vs 物件陣列】");

        // 基本類型陣列
        double[] prices = new double[3];
        System.out.println("double[] prices = new double[3];");
        System.out.println("prices[0] 預設值: " + prices[0]);  // 0.0

        // 物件陣列
        String[] names = new String[3];
        System.out.println("\nString[] names = new String[3];");
        System.out.println("names[0] 預設值: " + names[0]);  // null

        // 使用物件陣列前要注意 null 檢查
        names[0] = "Alice";
        names[1] = "Bob";
        // names[2] 未賦值，仍為 null
        System.out.println("names[2] = " + names[2] + " (未賦值，為 null)");

        System.out.println("\n=== Demo 結束 ===");
    }
}
