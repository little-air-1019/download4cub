package com.tutorial.collections.part1_array;

import java.util.Arrays;

/**
 * ============================================================
 * 【章節標題】A04 - 陣列的限制
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解陣列固定長度的限制
 * 2. 體驗手動擴容的麻煩
 * 3. 認識陣列缺乏的便利方法
 * 4. 為學習 Collection 做鋪陳
 * 
 * ============================================================
 */
public class A04_ArrayLimitations {

    public static void main(String[] args) {
        System.out.println("=== A04: 陣列的限制 ===\n");

        // ============================
        // 1. 固定長度：無法動態增減
        // ============================
        /*
         * 陣列一旦建立，長度就固定了
         * 不能動態增加或減少大小
         * 
         * 這是陣列最大的限制！
         */
        System.out.println("【1. 固定長度限制】");
        int[] arr = new int[3];
        arr[0] = 10;
        arr[1] = 20;
        arr[2] = 30;
        
        System.out.println("陣列: " + Arrays.toString(arr));
        System.out.println("長度: " + arr.length);
        System.out.println();
        System.out.println("❌ 問題：想加入第 4 個元素？");
        System.out.println("   無法！陣列長度已經固定為 3");
        System.out.println();
        
        // 嘗試存取超出範圍會拋出例外
        System.out.println("嘗試存取 arr[3]...");
        try {
            int value = arr[3];  // ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("→ 拋出 ArrayIndexOutOfBoundsException！");
        }
        System.out.println();

        // ============================
        // 2. 手動擴容的麻煩
        // ============================
        /*
         * 如果真的需要更大的陣列，必須：
         * 1. 建立新的更大的陣列
         * 2. 複製舊陣列的內容到新陣列
         * 3. 把參考指向新陣列
         * 
         * 這非常麻煩！而且每次擴容都要手動處理
         */
        System.out.println("【2. 手動擴容的麻煩】");
        
        int[] original = {1, 2, 3};
        System.out.println("原始陣列: " + Arrays.toString(original));
        System.out.println("想加入 4, 5... 需要手動擴容：");
        System.out.println();
        
        // 手動擴容過程
        System.out.println("步驟 1: 建立新的更大陣列");
        int[] newArray = new int[original.length + 2];
        System.out.println("        newArray = new int[" + newArray.length + "]");
        
        System.out.println("步驟 2: 複製舊陣列內容");
        for (int i = 0; i < original.length; i++) {
            newArray[i] = original[i];
        }
        System.out.println("        複製完成: " + Arrays.toString(newArray));
        
        System.out.println("步驟 3: 加入新元素");
        newArray[3] = 4;
        newArray[4] = 5;
        System.out.println("        加入後: " + Arrays.toString(newArray));
        
        System.out.println("步驟 4: 更新參考");
        original = newArray;
        System.out.println("        original = newArray");
        System.out.println();
        System.out.println("😓 這麼多步驟只為了加兩個元素...");
        System.out.println();

        // ============================
        // 3. 缺乏內建便利方法
        // ============================
        /*
         * 陣列沒有以下常用功能：
         * - add()：新增元素
         * - remove()：移除元素
         * - contains()：檢查是否包含
         * - indexOf()：尋找索引
         * 
         * 這些都需要自己實作！
         */
        System.out.println("【3. 缺乏內建便利方法】");
        
        int[] data = {10, 20, 30, 40, 50};
        int target = 30;
        
        // 檢查是否包含某元素 - 需要自己寫迴圈
        System.out.println("✗ 沒有 contains() 方法");
        System.out.println("  要檢查是否包含 " + target + "，必須自己寫：");
        
        boolean found = false;
        for (int item : data) {
            if (item == target) {
                found = true;
                break;
            }
        }
        System.out.println("  結果: " + found);
        System.out.println();
        
        // 尋找元素索引 - 需要自己寫迴圈
        System.out.println("✗ 沒有 indexOf() 方法");
        System.out.println("  要尋找 " + target + " 的索引，必須自己寫：");
        
        int index = -1;
        for (int i = 0; i < data.length; i++) {
            if (data[i] == target) {
                index = i;
                break;
            }
        }
        System.out.println("  索引: " + index);
        System.out.println();
        
        // 移除元素 - 非常麻煩
        System.out.println("✗ 沒有 remove() 方法");
        System.out.println("  要移除元素 30，需要：");
        System.out.println("  1. 找到該元素的位置");
        System.out.println("  2. 將後面的元素往前移");
        System.out.println("  3. 建立新的較小陣列（或留一個空位）");
        System.out.println();

        // ============================
        // 4. 引言：這就是為什麼需要 ArrayList
        // ============================
        System.out.println("【4. 為什麼需要 Collection？】");
        System.out.println();
        System.out.println("╔════════════════════════════════════════════════╗");
        System.out.println("║  陣列的限制讓日常開發變得很麻煩...              ║");
        System.out.println("║                                                ║");
        System.out.println("║  如果有個資料結構能夠：                        ║");
        System.out.println("║  ✓ 動態調整大小                                ║");
        System.out.println("║  ✓ 內建 add()、remove()、contains() 等方法    ║");
        System.out.println("║  ✓ 保持陣列的快速隨機訪問特性                  ║");
        System.out.println("║                                                ║");
        System.out.println("║  那就太好了！                                  ║");
        System.out.println("║                                                ║");
        System.out.println("║  這就是 ArrayList！                            ║");
        System.out.println("║  也是我們下一章要學習的 Collection Framework   ║");
        System.out.println("╚════════════════════════════════════════════════╝");
        System.out.println();

        // ============================
        // 5. 比較表
        // ============================
        System.out.println("【5. Array vs ArrayList 比較預覽】");
        System.out.println();
        System.out.println("┌─────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│      特性       │     Array       │   ArrayList     │");
        System.out.println("├─────────────────┼─────────────────┼─────────────────┤");
        System.out.println("│ 長度            │ 固定            │ 動態            │");
        System.out.println("│ 新增元素        │ 不支援          │ add()           │");
        System.out.println("│ 移除元素        │ 不支援          │ remove()        │");
        System.out.println("│ 是否包含        │ 手動迴圈        │ contains()      │");
        System.out.println("│ 隨機訪問        │ O(1)            │ O(1)            │");
        System.out.println("│ 基本類型支援    │ 支援            │ 需要包裝類別    │");
        System.out.println("└─────────────────┴─────────────────┴─────────────────┘");

        System.out.println("\n=== Demo 結束 ===");
    }
}
