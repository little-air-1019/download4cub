package com.tutorial.collections.part2_collection;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

/**
 * ============================================================
 * 【章節標題】B07 - TreeSet 有序 Set
 * ============================================================
 * 
 * 【學習目標】
 * 1. 了解 TreeSet 的自動排序特性
 * 2. 理解 Comparable 和 Comparator 的使用
 * 3. 認識 TreeSet 的效能特性
 * 
 * ============================================================
 */
public class B07_TreeSetDemo {

    public static void main(String[] args) {
        System.out.println("=== B07: TreeSet 有序 Set ===\n");

        // ============================
        // 1. TreeSet 底層結構
        // ============================
        /*
         * TreeSet 底層是 TreeMap（紅黑樹 Red-Black Tree）
         * 
         * 特性：
         * - 元素自動排序
         * - 不允許 null
         * - add/remove/contains 都是 O(log n)
         */
        System.out.println("【1. TreeSet 底層結構】");
        System.out.println("TreeSet 底層是 TreeMap（紅黑樹）");
        System.out.println();
        System.out.println("特性：");
        System.out.println("  ✓ 元素自動排序");
        System.out.println("  ✗ 不允許 null");
        System.out.println("  ✓ add/remove/contains 都是 O(log n)");
        System.out.println();

        // ============================
        // 2. 自動排序（自然順序）
        // ============================
        /*
         * 對於實作 Comparable 的類別，TreeSet 會使用其自然順序：
         * - String：字典序
         * - Integer：數值大小
         * - Date：時間先後
         */
        System.out.println("【2. 自動排序（自然順序）】");
        
        // Integer 的自然順序
        Set<Integer> numbers = new TreeSet<>();
        numbers.add(5);
        numbers.add(2);
        numbers.add(8);
        numbers.add(1);
        numbers.add(9);
        
        System.out.println("加入順序: 5, 2, 8, 1, 9");
        System.out.println("TreeSet: " + numbers);  // [1, 2, 5, 8, 9]
        System.out.println();
        
        // String 的自然順序（字典序）
        Set<String> fruits = new TreeSet<>();
        fruits.add("Cherry");
        fruits.add("Apple");
        fruits.add("Banana");
        
        System.out.println("加入順序: Cherry, Apple, Banana");
        System.out.println("TreeSet: " + fruits);  // [Apple, Banana, Cherry]
        System.out.println();

        // ============================
        // 3. 使用 Comparator 自訂排序
        // ============================
        /*
         * 如果不想用自然順序，可以在建立 TreeSet 時提供 Comparator
         */
        System.out.println("【3. 使用 Comparator 自訂排序】");
        
        // 降序排列
        Set<Integer> descNumbers = new TreeSet<>(Comparator.reverseOrder());
        descNumbers.add(5);
        descNumbers.add(2);
        descNumbers.add(8);
        
        System.out.println("Comparator.reverseOrder() 降序：");
        System.out.println("TreeSet: " + descNumbers);  // [8, 5, 2]
        System.out.println();
        
        // 自訂 Comparator：依字串長度排序
        Set<String> byLength = new TreeSet<>(Comparator.comparingInt(String::length));
        byLength.add("Apple");
        byLength.add("Kiwi");
        byLength.add("Strawberry");
        byLength.add("Fig");
        
        System.out.println("依字串長度排序：");
        System.out.println("TreeSet: " + byLength);
        System.out.println("⚠️ 注意：長度相同的字串會被視為重複！");
        System.out.println();

        // ============================
        // 4. 自訂物件必須可比較
        // ============================
        /*
         * 放入 TreeSet 的物件必須：
         * 1. 實作 Comparable 介面，或
         * 2. 建立 TreeSet 時提供 Comparator
         * 
         * 否則會拋出 ClassCastException
         */
        System.out.println("【4. 自訂物件必須可比較】");
        
        // 使用實作 Comparable 的 Student
        Set<Student> students = new TreeSet<>();
        students.add(new Student("Alice", 85));
        students.add(new Student("Bob", 92));
        students.add(new Student("Charlie", 78));
        
        System.out.println("Student 實作 Comparable（依分數排序）：");
        for (Student s : students) {
            System.out.println("  " + s);
        }
        System.out.println();
        
        // 使用 Comparator（不修改類別）
        Set<Student> byName = new TreeSet<>(Comparator.comparing(Student::getName));
        byName.add(new Student("Charlie", 78));
        byName.add(new Student("Alice", 85));
        byName.add(new Student("Bob", 92));
        
        System.out.println("使用 Comparator（依名字排序）：");
        for (Student s : byName) {
            System.out.println("  " + s);
        }
        System.out.println();

        // ============================
        // 5. TreeSet 特有方法
        // ============================
        System.out.println("【5. TreeSet 特有方法】");
        
        TreeSet<Integer> nums = new TreeSet<>();
        nums.add(10);
        nums.add(20);
        nums.add(30);
        nums.add(40);
        nums.add(50);
        
        System.out.println("TreeSet: " + nums);
        System.out.println("first() = " + nums.first());     // 最小值
        System.out.println("last() = " + nums.last());       // 最大值
        System.out.println("lower(30) = " + nums.lower(30)); // 小於 30 的最大值
        System.out.println("higher(30) = " + nums.higher(30)); // 大於 30 的最小值
        System.out.println("floor(25) = " + nums.floor(25)); // 小於等於 25 的最大值
        System.out.println("ceiling(25) = " + nums.ceiling(25)); // 大於等於 25 的最小值
        System.out.println();
        
        // 範圍操作
        System.out.println("headSet(30) = " + nums.headSet(30));    // < 30
        System.out.println("tailSet(30) = " + nums.tailSet(30));    // >= 30
        System.out.println("subSet(20, 40) = " + nums.subSet(20, 40)); // [20, 40)
        System.out.println();

        // ============================
        // 6. HashSet vs TreeSet
        // ============================
        System.out.println("【6. HashSet vs TreeSet】");
        System.out.println();
        System.out.println("┌─────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│      特性       │    HashSet      │    TreeSet      │");
        System.out.println("├─────────────────┼─────────────────┼─────────────────┤");
        System.out.println("│ 底層結構        │ HashMap         │ TreeMap(紅黑樹) │");
        System.out.println("│ 是否排序        │ 否              │ 是              │");
        System.out.println("│ null 允許       │ 允許一個        │ 不允許          │");
        System.out.println("│ add/contains    │ O(1)            │ O(log n)        │");
        System.out.println("│ 額外要求        │ equals/hashCode │ Comparable/ator │");
        System.out.println("└─────────────────┴─────────────────┴─────────────────┘");

        System.out.println("\n=== Demo 結束 ===");
    }
}

// ============================
// 輔助類別：實作 Comparable
// ============================
class Student implements Comparable<Student> {
    private String name;
    private int score;

    public Student(String name, int score) {
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    @Override
    public int compareTo(Student other) {
        // 依分數升序排列
        return Integer.compare(this.score, other.score);
    }

    @Override
    public String toString() {
        return name + ": " + score;
    }
}
