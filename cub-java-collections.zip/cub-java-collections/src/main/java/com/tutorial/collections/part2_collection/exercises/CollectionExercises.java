package com.tutorial.collections.part2_collection.exercises;

import java.util.*;

/**
 * ============================================================
 * 【練習題】Collection 練習
 * ============================================================
 * 
 * 完成以下練習題，加深對 Collection 操作的理解。
 * 每個方法都有 TODO 標記，請實作該方法。
 * 執行 main() 可以測試你的實作。
 * 
 * ============================================================
 */
public class CollectionExercises {

    // ============================
    // Iterator 相關練習
    // ============================

    /**
     * 練習 1：使用 Iterator 安全移除元素
     * 移除 List 中所有長度小於 3 的字串
     * 
     * 範例：
     * 輸入：["hi", "hello", "a", "world", "ok", "java"]
     * 預期結果：["hello", "world", "java"]
     * 
     * 要求：必須使用 Iterator，不可使用 removeIf()
     */
    public static void removeShortStrings(List<String> list) {
        // TODO: 請實作此方法
        // 提示：
        // 1. 取得 Iterator
        // 2. 使用 while (iter.hasNext())
        // 3. 如果 next() 的長度 < 3，呼叫 iter.remove()
    }

    /**
     * 練習 2：實作自訂 Iterator
     * 建立一個只遍歷偶數的 Iterator
     * 
     * 範例：
     * 輸入：[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
     * 遍歷結果：2, 4, 6, 8, 10
     */
    public static Iterator<Integer> createEvenIterator(List<Integer> list) {
        // TODO: 請實作此方法
        // 提示：回傳一個 new Iterator<Integer>() { ... }
        // 內部維護一個 index，hasNext() 時往前找偶數
        return null;
    }

    // ============================
    // 排序相關練習
    // ============================

    /**
     * 練習 3：使用 Comparator 多欄位排序
     * 將 Employee 列表依照以下規則排序：
     * 1. 先依部門名稱升序
     * 2. 部門相同，依薪資降序
     * 3. 薪資相同，依姓名升序
     */
    public static void sortEmployees(List<EmployeeData> employees) {
        // TODO: 請實作此方法
        // 提示：使用 Comparator.comparing().thenComparing()...
    }

    /**
     * 練習 4：找出前 N 個最高分
     * 使用 PriorityQueue 找出前 N 高分
     * 
     * 範例：
     * 輸入：scores = [85, 92, 78, 95, 88, 76, 99, 82], n = 3
     * 預期結果：[99, 95, 92]（順序可不同）
     */
    public static List<Integer> topNScores(List<Integer> scores, int n) {
        // TODO: 請實作此方法
        // 提示：使用 min-heap，維護大小為 n 的 PriorityQueue
        // 遍歷時如果新分數比堆頂大，就取代堆頂
        return null;
    }

    // ============================
    // 空值判斷相關練習
    // ============================

    /**
     * 練習 5：安全地處理可能為 null 的集合
     * 計算集合中所有數字的總和
     * 如果集合為 null 或 empty，回傳 0
     * 
     * 要求：不使用外部工具類（CollectionUtils）
     */
    public static int safeSum(List<Integer> numbers) {
        // TODO: 請實作此方法
        // 提示：先檢查 null 和 isEmpty()
        return 0;
    }

    /**
     * 練習 6：合併多個可能為 null 的 List
     * 
     * 範例：
     * 輸入：list1 = [1, 2], list2 = null, list3 = [3, 4, 5]
     * 預期結果：[1, 2, 3, 4, 5]
     */
    @SafeVarargs
    public static <T> List<T> safeMerge(List<T>... lists) {
        // TODO: 請實作此方法
        // 提示：遍歷 lists，跳過 null 的，把非 null 的加到結果
        return null;
    }

    // ============================
    // 綜合練習
    // ============================

    /**
     * 練習 7：統計字串出現次數
     * 
     * 範例：
     * 輸入：["apple", "banana", "apple", "cherry", "banana", "apple"]
     * 預期結果：{apple=3, banana=2, cherry=1}
     */
    public static Map<String, Integer> countOccurrences(List<String> list) {
        // TODO: 請實作此方法
        // 提示：遍歷 list，使用 Map.getOrDefault() 或 merge()
        return null;
    }

    /**
     * 練習 8：找出兩個 List 的交集
     * 
     * 範例：
     * 輸入：[1, 2, 3, 4, 5] 和 [4, 5, 6, 7, 8]
     * 預期結果：[4, 5]
     */
    public static <T> List<T> findIntersection(List<T> list1, List<T> list2) {
        // TODO: 請實作此方法
        // 提示：使用 Set 的 retainAll() 方法
        return null;
    }

    /**
     * 練習 9：將 List 去重並排序
     * 
     * 範例：
     * 輸入：[3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
     * 預期結果：[1, 2, 3, 4, 5, 6, 9]
     */
    public static List<Integer> distinctAndSort(List<Integer> list) {
        // TODO: 請實作此方法
        // 提示：使用 TreeSet（自動去重 + 排序）
        return null;
    }

    /**
     * 練習 10：分組
     * 將學生依照成績等級分組
     * A: 90+, B: 80-89, C: 70-79, D: 60-69, F: <60
     * 
     * 範例：
     * 輸入：[(Alice, 95), (Bob, 82), (Charlie, 68), (David, 55)]
     * 預期結果：{A=[Alice], B=[Bob], D=[Charlie], F=[David]}
     */
    public static Map<String, List<String>> groupByGrade(List<StudentScore> students) {
        // TODO: 請實作此方法
        // 提示：遍歷學生，根據分數決定等級，放入對應的 List
        return null;
    }

    // ============================
    // 測試程式碼
    // ============================
    public static void main(String[] args) {
        System.out.println("=== Collection 練習題測試 ===\n");

        // 測試練習 1
        System.out.println("【練習 1：Iterator 移除元素】");
        List<String> test1 = new ArrayList<>(Arrays.asList("hi", "hello", "a", "world", "ok", "java"));
        System.out.println("輸入: " + test1);
        removeShortStrings(test1);
        System.out.println("結果: " + test1);
        System.out.println("預期: [hello, world, java]\n");

        // 測試練習 4
        System.out.println("【練習 4：Top N】");
        List<Integer> scores = Arrays.asList(85, 92, 78, 95, 88, 76, 99, 82);
        List<Integer> top3 = topNScores(scores, 3);
        System.out.println("輸入: " + scores);
        System.out.println("Top 3: " + top3);
        System.out.println("預期: [99, 95, 92]（順序可不同）\n");

        // 測試練習 5
        System.out.println("【練習 5：安全加總】");
        System.out.println("safeSum(null) = " + safeSum(null));
        System.out.println("safeSum([]) = " + safeSum(new ArrayList<>()));
        System.out.println("safeSum([1,2,3]) = " + safeSum(Arrays.asList(1, 2, 3)));
        System.out.println("預期: 0, 0, 6\n");

        // 測試練習 7
        System.out.println("【練習 7：統計次數】");
        List<String> fruits = Arrays.asList("apple", "banana", "apple", "cherry", "banana", "apple");
        Map<String, Integer> counts = countOccurrences(fruits);
        System.out.println("輸入: " + fruits);
        System.out.println("結果: " + counts);
        System.out.println("預期: {apple=3, banana=2, cherry=1}\n");

        // 測試練習 8
        System.out.println("【練習 8：交集】");
        List<Integer> list1 = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> list2 = Arrays.asList(4, 5, 6, 7, 8);
        List<Integer> intersection = findIntersection(list1, list2);
        System.out.println("輸入: " + list1 + " 和 " + list2);
        System.out.println("交集: " + intersection);
        System.out.println("預期: [4, 5]\n");

        // 測試練習 9
        System.out.println("【練習 9：去重排序】");
        List<Integer> nums = Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5);
        List<Integer> sorted = distinctAndSort(nums);
        System.out.println("輸入: " + nums);
        System.out.println("結果: " + sorted);
        System.out.println("預期: [1, 2, 3, 4, 5, 6, 9]\n");

        System.out.println("=== 測試結束 ===");
    }
}

// ============================
// 輔助類別
// ============================
class EmployeeData {
    private String name;
    private String department;
    private double salary;

    public EmployeeData(String name, String department, double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public String getName() { return name; }
    public String getDepartment() { return department; }
    public double getSalary() { return salary; }

    @Override
    public String toString() {
        return String.format("(%s, %s, %.0f)", name, department, salary);
    }
}

class StudentScore {
    private String name;
    private int score;

    public StudentScore(String name, int score) {
        this.name = name;
        this.score = score;
    }

    public String getName() { return name; }
    public int getScore() { return score; }
}
