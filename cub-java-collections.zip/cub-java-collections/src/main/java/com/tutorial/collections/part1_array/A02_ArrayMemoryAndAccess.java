package com.tutorial.collections.part1_array;

/**
 * ============================================================
 * 【章節標題】A02 - 陣列記憶體與存取效能
 * ============================================================
 * 
 * 【學習目標】
 * 1. 理解陣列的連續記憶體配置
 * 2. 了解 O(1) 隨機訪問的原理
 * 3. 對比 LinkedList 的 O(n) 遍歷
 * 4. 實際體驗大量隨機訪問的效能差異
 * 
 * ============================================================
 */
public class A02_ArrayMemoryAndAccess {

    public static void main(String[] args) {
        System.out.println("=== A02: 陣列記憶體與存取效能 ===\n");

        // ============================
        // 1. 連續記憶體配置
        // ============================
        /*
         * 陣列在記憶體中是「連續」配置的：
         * 
         * 假設有 int[] arr = {10, 20, 30, 40, 50};
         * 假設起始位址是 1000，int 占用 4 bytes：
         * 
         * 記憶體位址:  1000    1004    1008    1012    1016
         *            +-------+-------+-------+-------+-------+
         *            |  10   |  20   |  30   |  40   |  50   |
         *            +-------+-------+-------+-------+-------+
         * 索引:        [0]     [1]     [2]     [3]     [4]
         * 
         * 這種連續配置是陣列能夠 O(1) 訪問的關鍵！
         */
        System.out.println("【1. 連續記憶體配置】");
        System.out.println("陣列在記憶體中佔用連續的空間");
        System.out.println();
        System.out.println("範例：int[] arr = {10, 20, 30, 40, 50}");
        System.out.println("假設起始位址 = 1000，每個 int = 4 bytes");
        System.out.println();
        System.out.println("位址: 1000  1004  1008  1012  1016");
        System.out.println("      +-----+-----+-----+-----+-----+");
        System.out.println("      | 10  | 20  | 30  | 40  | 50  |");
        System.out.println("      +-----+-----+-----+-----+-----+");
        System.out.println("索引:  [0]   [1]   [2]   [3]   [4]");
        System.out.println();

        // ============================
        // 2. O(1) 隨機訪問原理
        // ============================
        /*
         * 為什麼 arr[i] 是 O(1)？
         * 
         * 計算公式：
         * 元素位址 = 基底位址 + (index × 元素大小)
         * 
         * 例如：arr[3] 的位址
         * = 1000 + (3 × 4)
         * = 1000 + 12
         * = 1012
         * 
         * 不管陣列多大，計算位址都只需要一次運算！
         * 這就是 O(1) 常數時間的來源。
         */
        System.out.println("【2. O(1) 隨機訪問原理】");
        System.out.println("元素位址 = 基底位址 + (index × 元素大小)");
        System.out.println();
        System.out.println("例如存取 arr[3]:");
        System.out.println("位址 = 1000 + (3 × 4) = 1012");
        System.out.println();
        System.out.println("✅ 無論陣列大小，計算位址只需一次運算");
        System.out.println("✅ 這就是 O(1) 常數時間複雜度的原因\n");

        // ============================
        // 3. 對比 LinkedList
        // ============================
        /*
         * LinkedList 的記憶體配置是「分散」的：
         * 
         * Node1 → Node2 → Node3 → Node4 → Node5
         * (1000)  (2048)  (3072)  (4096)  (5120)
         * 
         * 要存取第 i 個元素，必須：
         * 1. 從頭節點開始
         * 2. 依序跟著 next 指標走
         * 3. 走 i 步才能到達
         * 
         * 這就是 O(n) 的原因！
         */
        System.out.println("【3. 對比 LinkedList】");
        System.out.println("LinkedList 節點分散在記憶體各處：");
        System.out.println();
        System.out.println("Node1 → Node2 → Node3 → Node4 → Node5");
        System.out.println("(1000)  (2048)  (3072)  (4096)  (5120)");
        System.out.println();
        System.out.println("要存取第 i 個元素，必須從頭走 i 步");
        System.out.println("❌ 這就是 LinkedList 隨機訪問 O(n) 的原因\n");

        // ============================
        // 4. 效能展示
        // ============================
        /*
         * 實際測量 Array vs 模擬 LinkedList 的隨機訪問效能
         * 
         * 注意：這是簡化的效能測量，實際環境會有更多變數
         * 目的是讓學生「感受」差異，而非精確 benchmark
         */
        System.out.println("【4. 效能展示】");
        
        int size = 100_000;
        int accessCount = 100_000;
        
        // 建立測試資料
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = i;
        }
        
        // 測試 Array 隨機訪問
        long startTime = System.nanoTime();
        int sum = 0;
        for (int i = 0; i < accessCount; i++) {
            int index = (int) (Math.random() * size);
            sum += array[index];  // O(1) 訪問
        }
        long arrayTime = System.nanoTime() - startTime;
        
        System.out.println("陣列大小: " + size);
        System.out.println("隨機訪問次數: " + accessCount);
        System.out.println("Array 隨機訪問耗時: " + (arrayTime / 1_000_000.0) + " ms");
        
        // 模擬 LinkedList 隨機訪問（實際使用遍歷）
        startTime = System.nanoTime();
        sum = 0;
        for (int i = 0; i < 1000; i++) {  // 減少次數，否則太慢
            int index = (int) (Math.random() * size);
            // 模擬從頭遍歷到 index 位置
            for (int j = 0; j < index; j++) {
                // 模擬 next 指標的跳轉
            }
            sum += array[index];  // 最後才能存取
        }
        long linkedTime = System.nanoTime() - startTime;
        
        System.out.println("\n模擬 LinkedList 風格訪問 (1000 次): " + (linkedTime / 1_000_000.0) + " ms");
        System.out.println("（實際 LinkedList 訪問會更慢，因為有指標解參考開銷）");
        
        System.out.println("\n【結論】");
        System.out.println("✅ 頻繁隨機訪問 → 使用 Array / ArrayList");
        System.out.println("✅ 頻繁頭尾插入刪除 → 使用 LinkedList");

        System.out.println("\n=== Demo 結束 ===");
    }
}
