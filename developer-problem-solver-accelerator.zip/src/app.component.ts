import { Component, signal, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Message {
  id: number;
  role: 'user' | 'ai';
  content: string;
  type: 'text' | 'feedback' | 'routing-card';
  timestamp: Date;
  meta?: any;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styles: []
})
export class AppComponent implements AfterViewChecked {
  @ViewChild('scrollContainer') private scrollContainer!: ElementRef;

  // State Signals
  messages = signal<Message[]>([]);
  userInput = signal<string>('');
  isTyping = signal<boolean>(false);
  scriptStep = signal<number>(0);
  
  // Defines the "Next" text to automatically fill for the demo
  nextDemoText = signal<string>(''); 

  constructor() {
    // Start the script immediately on load
    this.initScript();
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    try {
      if (this.scrollContainer) {
        this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
      }
    } catch (err) { }
  }

  async initScript() {
    // Step 1: Initial Greeting
    this.setTyping(true);
    await this.delay(1000);
    this.addAiMessage('你好，我是你的開發者助手。請問遇到什麼技術問題？');
    this.setTyping(false);
    this.scriptStep.set(1);
    this.nextDemoText.set('批次升版後，在地端執行 OK，但在 UT 啟動失敗'); // Prepare hint for next step
  }

  // Handle User Action
  async handleSend() {
    const currentStep = this.scriptStep();
    
    if (this.isTyping()) return; // Prevent interruption

    // Script Logic Branching
    if (currentStep === 1) {
      // Step 2: User Fuzzy Input
      const text = this.userInput() || '批次升版後，在地端執行 OK，但在 UT 啟動失敗'; // Fallback for demo speed
      this.addUserMessage(text);
      this.userInput.set('');
      
      this.setTyping(true);
      await this.delay(1500);
      
      // Step 3: AI Clarification
      this.addAiMessage('收到，這聽起來像是環境差異導致的配置問題。為了精準判斷，請提供以下資訊：\n1. SDK 原版本與升級後版本。\n2. 詳細報錯 Log (尤其是 Cause by 後段)。\n3. 部署環境 (例如：GCP GKE / Cloud Run)。\n4. 是否已檢查過該環境的 Secret Manager 或環境變數？');
      this.setTyping(false);
      
      this.scriptStep.set(2);
      this.nextDemoText.set('SDK 1.1.1 -> 2.0.9，Log 顯示: "datasource config cannot instantiate"，部署在 GCP');
    } 
    else if (currentStep === 2) {
      // Step 4: User Details
      const text = this.userInput() || '版本 v2.1.0，錯誤碼 503 Service Unavailable，在 UAT 環境測試時發生。';
      this.addUserMessage(text);
      this.userInput.set('');

      this.setTyping(true);
      await this.delay(2000);

      // Step 5: AI Knowledge Base & Feedback
      this.addAiMessage('檢索知識庫中... 找到相關文章：『[文件] SDK 2.x 版本資料庫配置規範』。\n提示：2.x 版本後的 datasource 配置層級有變動，請檢查 application.yml。\n請問這是否有幫助？', 'feedback');
      this.setTyping(false);
      
      this.scriptStep.set(3); // Waiting for feedback button click
      this.nextDemoText.set(''); // Clear hint as interaction is now button-based
    }
  }

  // Handle Feedback Button Clicks (Step 6)
  async handleFeedback(isHelpful: boolean) {
    if (isHelpful) {
      this.addUserMessage('✅ 有幫助，已解決');
      this.setTyping(true);
      await this.delay(1000);
      this.addAiMessage('太棒了！很高興能幫上忙。如果還有其他問題，歡迎隨時詢問。');
      this.setTyping(false);
    } else {
      // Step 6: Not Helpful
      this.addUserMessage('❌ 沒幫助，需要進一步支援');
      
      this.setTyping(true);
      await this.delay(2500); // Simulate deeper analysis

      // Step 7: Routing Card
      this.addRoutingCard();
      this.setTyping(false);
    }
    this.scriptStep.set(4); // End of demo script
  }

  // Helper: Add User Message
  addUserMessage(text: string) {
    this.messages.update(msgs => [...msgs, {
      id: Date.now(),
      role: 'user',
      content: text,
      type: 'text',
      timestamp: new Date()
    }]);
  }

  // Helper: Add AI Message
  addAiMessage(text: string, type: 'text' | 'feedback' = 'text') {
    this.messages.update(msgs => [...msgs, {
      id: Date.now(),
      role: 'ai',
      content: text,
      type: type,
      timestamp: new Date()
    }]);
  }

  // Helper: Add Routing Card
  addRoutingCard() {
    this.messages.update(msgs => [...msgs, {
      id: Date.now(),
      role: 'ai',
      content: 'Routing Analysis', // Fallback text
      type: 'routing-card',
      timestamp: new Date(),
      meta: {
        title: '已為您轉派專家處理',
        team: '應用開發科',
        reason: '使用者已嘗試根據配置指引排除故障但無效。報錯指向 datasource 實例化失敗，分析為應用端代碼與新版依賴存在衝突。此類問題涉及應用層實作邏輯，建議由開發科 (PG) 協助排查應用程式配置與依賴樹',
        ticketId: '#20260110001'
      }
    }]);
  }

  // Utility: Simulate Delay
  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  setTyping(status: boolean) {
    this.isTyping.set(status);
  }

  // Demo Utility: Auto-fill input for presentation smoothness
  autoFillDemo() {
    const text = this.nextDemoText();
    if (text) {
      this.userInput.set(text);
    }
  }
}