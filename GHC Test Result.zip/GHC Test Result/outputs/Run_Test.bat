@echo off
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0LoanAPI_Test.ps1"
pause
