﻿#Requires -RunAsAdministrator
$TaskName   = "LoanAPI_Test"
$ScriptDir  = "D:\DEVTOOLS\Projects\DevDept\GHC 使用能力快篩\驗測"
$BatPath    = Join-Path $ScriptDir "Run_Test.bat"

$times = @(
    "2026-04-17 14:00:00",
    "2026-04-17 14:30:00",
    "2026-04-17 15:00:00",
    "2026-04-17 15:30:00",
    "2026-04-17 16:00:00",
    "2026-04-17 16:30:00",
    "2026-04-17 17:00:00",
    "2026-04-17 17:30:00"
)

$triggers = @()
foreach ($t in $times) {
    $triggers += New-ScheduledTaskTrigger -Once -At $t
}

$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument ("/c `"" + $BatPath + "`"") -WorkingDirectory $ScriptDir
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)

Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $TaskName -Description "LoanAPI Exam Auto Test" -Trigger $triggers -Action $action -Settings $settings -Force

Write-Host ""
Write-Host "Schedule created: $TaskName" -ForegroundColor Green
foreach ($t in $times) { Write-Host "  - $t" }
Write-Host ""
Write-Host "Verify in taskschd.msc" -ForegroundColor Yellow
