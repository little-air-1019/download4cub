﻿#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$InputDir  = "D:\DEVTOOLS\Projects\DevDept\GHC 使用能力快篩\驗測\讀取資料",
    [string]$OutputDir = "D:\DEVTOOLS\Projects\DevDept\GHC 使用能力快篩\驗測\驗測結果"
)

$ApiPath    = "/api/loan/queryLoanEligibilit"
$Port       = 8080
$TimeoutSec = 15
$BatchLabel = (Get-Date).ToString("HH:mm")
$RunDate    = (Get-Date).ToString("yyyy-MM-dd")

$ContestantsFile = Join-Path $InputDir "Contestants.csv"
$RequestPFile    = Join-Path $InputDir "request_P.json"
$RequestCFile    = Join-Path $InputDir "request_C.json"
$ResponsePFile   = Join-Path $InputDir "response_P.json"
$ResponseCFile   = Join-Path $InputDir "response_C.json"
$StateFile       = Join-Path $OutputDir "result_state.json"
$ExcelFile       = Join-Path $OutputDir "驗測結果.xlsx"
$LogFile         = Join-Path $OutputDir "test_log_$RunDate.txt"

# === Canonical JSON for deep comparison ===
function ConvertTo-CanonicalJson {
    param($Obj)
    if ($null -eq $Obj) { return "null" }
    if ($Obj -is [System.Object[]] -or $Obj -is [System.Collections.ArrayList]) {
        if ($Obj.Count -eq 0) { return "[]" }
        $items = @()
        foreach ($item in $Obj) { $items += (ConvertTo-CanonicalJson $item) }
        return "[" + ($items -join ",") + "]"
    }
    if ($Obj -is [PSCustomObject]) {
        $sortedProps = $Obj.PSObject.Properties | Sort-Object Name
        $pairs = @()
        foreach ($prop in $sortedProps) {
            $escapedKey = $prop.Name -replace '\\', '\\' -replace '"', '\"'
            $val = ConvertTo-CanonicalJson $prop.Value
            $pairs += ('"' + $escapedKey + '":' + $val)
        }
        return "{" + ($pairs -join ",") + "}"
    }
    if ($Obj -is [bool]) { if ($Obj) { return "true" } else { return "false" } }
    if ($Obj -is [int] -or $Obj -is [long] -or $Obj -is [double] -or $Obj -is [decimal]) { return [string]$Obj }
    $str = [string]$Obj
    $str = $str -replace '\\', '\\' -replace '"', '\"' -replace "`r", '' -replace "`n", '\n' -replace "`t", '\t'
    return '"' + $str + '"'
}

# === Test single scenario ===
function Test-SingleScenario {
    param(
        [string]$IP,
        [string]$RequestBody,
        [string]$ExpectedCanonical,
        [string]$ScenarioName
    )
    $url = "http://${IP}:${Port}${ApiPath}"
    try {
        $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($RequestBody)
        $resp = Invoke-WebRequest -Uri $url -Method POST -Body $bodyBytes -ContentType "application/json; charset=utf-8" -TimeoutSec $TimeoutSec -UseBasicParsing
        $body = $resp.Content | ConvertFrom-Json
        $actualTRANRS = $body.TRANRS
        if ($null -eq $actualTRANRS) {
            return @{ Pass = $false; Code = "WRONG"; Detail = "$ScenarioName : Missing TRANRS" }
        }
        $actualCanonical = ConvertTo-CanonicalJson $actualTRANRS
        if ($actualCanonical -eq $ExpectedCanonical) {
            return @{ Pass = $true; Code = "PASS"; Detail = "" }
        } else {
            return @{ Pass = $false; Code = "WRONG"; Detail = "$ScenarioName : TRANRS mismatch" }
        }
    } catch [System.Net.WebException] {
        return @{ Pass = $false; Code = "UNREACHABLE"; Detail = "$ScenarioName : $($_.Exception.Message)" }
    } catch {
        return @{ Pass = $false; Code = "ERROR"; Detail = "$ScenarioName : $($_.Exception.Message)" }
    }
}

# === Main ===
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

$logHeader = "`n===== [$RunDate $BatchLabel] START ====="
Add-Content -Path $LogFile -Value $logHeader -Encoding UTF8
Write-Host $logHeader -ForegroundColor Cyan

if (-not (Test-Path $ContestantsFile)) {
    Write-Host "ERROR: Contestants.csv not found at $ContestantsFile" -ForegroundColor Red
    exit 1
}
$contestants = Import-Csv $ContestantsFile -Encoding UTF8

$reqPBody = Get-Content $RequestPFile -Raw -Encoding UTF8
$reqCBody = Get-Content $RequestCFile -Raw -Encoding UTF8
$expectedP_TRANRS = (Get-Content $ResponsePFile -Raw -Encoding UTF8 | ConvertFrom-Json).TRANRS
$expectedC_TRANRS = (Get-Content $ResponseCFile -Raw -Encoding UTF8 | ConvertFrom-Json).TRANRS
$canonicalP = ConvertTo-CanonicalJson $expectedP_TRANRS
$canonicalC = ConvertTo-CanonicalJson $expectedC_TRANRS

# Load persisted state
$state = @{}
if (Test-Path $StateFile) {
    try {
        $raw = Get-Content $StateFile -Raw -Encoding UTF8
        $stateArray = $raw | ConvertFrom-Json
        if ($stateArray -isnot [System.Object[]]) { $stateArray = @($stateArray) }
        foreach ($item in $stateArray) {
            $state[$item.EmpId] = @{
                EmpName  = $item.EmpName
                Result   = $item.Result
                PassTime = $item.PassTime
                Detail   = $item.Detail
            }
        }
    } catch {
        Write-Host "WARN: State file load failed, recreating." -ForegroundColor Yellow
    }
}

# === Test each contestant ===
foreach ($c in $contestants) {
    $empId   = $c.'行編'.Trim()
    $empName = $c.'姓名'.Trim()
    $empIP   = $c.'IP'.Trim()

    # Already passed => skip
    if ($state.ContainsKey($empId) -and $state[$empId].Result -eq "PASS") {
        $skipMsg = "$empId $empName >> 通過 ($($state[$empId].PassTime)), skip"
        Write-Host $skipMsg -ForegroundColor Green
        Add-Content -Path $LogFile -Value $skipMsg -Encoding UTF8
        continue
    }

    Write-Host "$empId $empName ($empIP) testing..." -NoNewline

    $resultP = Test-SingleScenario -IP $empIP -RequestBody $reqPBody -ExpectedCanonical $canonicalP -ScenarioName "P"
    $resultC = Test-SingleScenario -IP $empIP -RequestBody $reqCBody -ExpectedCanonical $canonicalC -ScenarioName "C"

    if ($resultP.Pass -and $resultC.Pass) {
        $state[$empId] = @{
            EmpName  = $empName
            Result   = "PASS"
            PassTime = $BatchLabel
            Detail   = ""
        }
        $msg = " >> 通過 ($BatchLabel)"
        Write-Host $msg -ForegroundColor Green
    }
    elseif ($resultP.Code -eq "UNREACHABLE" -and $resultC.Code -eq "UNREACHABLE") {
        $state[$empId] = @{
            EmpName  = $empName
            Result   = "FAIL_UNREACHABLE"
            PassTime = ""
            Detail   = "尚未打通"
        }
        $msg = " >> 未通過 (尚未打通)"
        Write-Host $msg -ForegroundColor Red
    }
    else {
        $failParts = @()
        if (-not $resultP.Pass) { $failParts += $resultP.Detail }
        if (-not $resultC.Pass) { $failParts += $resultC.Detail }
        $detailStr = $failParts -join "; "
        $state[$empId] = @{
            EmpName  = $empName
            Result   = "FAIL_WRONG"
            PassTime = ""
            Detail   = "答案錯誤 ($detailStr)"
        }
        $msg = " >> 未通過 (答案錯誤)"
        Write-Host $msg -ForegroundColor Yellow
    }

    Add-Content -Path $LogFile -Value ("$empId $empName" + $msg) -Encoding UTF8
}

# === Save state ===
$stateExport = @()
foreach ($key in $state.Keys) {
    $stateExport += [PSCustomObject]@{
        EmpId    = $key
        EmpName  = $state[$key].EmpName
        Result   = $state[$key].Result
        PassTime = $state[$key].PassTime
        Detail   = $state[$key].Detail
    }
}
$stateJson = "["
$first = $true
foreach ($item in $stateExport) {
    if (-not $first) { $stateJson += "," }
    $stateJson += ($item | ConvertTo-Json -Depth 5 -Compress)
    $first = $false
}
$stateJson += "]"
[System.IO.File]::WriteAllText($StateFile, $stateJson, [System.Text.Encoding]::UTF8)

# === Generate report ===
$report = @()
foreach ($c in $contestants) {
    $empId = $c.'行編'.Trim()
    if ($state.ContainsKey($empId)) {
        $s = $state[$empId]
        if ($s.Result -eq "PASS") {
            $resultText = "通過 ($($s.PassTime))"
        }
        elseif ($s.Result -eq "FAIL_UNREACHABLE") {
            $resultText = "未通過 (尚未打通)"
        }
        else {
            $resultText = "未通過 (答案錯誤)"
        }
    }
    else {
        $resultText = "未測試"
    }
    $report += [PSCustomObject]@{
        '行編'  = $empId
        '姓名'   = $c.'姓名'.Trim()
        '驗測結果' = $resultText
    }
}

# Export Excel
$excelOk = $false
try {
    if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
        Write-Host "Installing ImportExcel module..." -ForegroundColor Yellow
        Install-Module ImportExcel -Scope CurrentUser -Force -ErrorAction Stop
    }
    Import-Module ImportExcel -ErrorAction Stop
    $report | Export-Excel -Path $ExcelFile -WorksheetName "驗測結果" -AutoSize -FreezeTopRow -BoldTopRow -Force
    $excelOk = $true
    Write-Host "`nExcel: $ExcelFile" -ForegroundColor Cyan
}
catch {
    Write-Host "`nImportExcel failed, fallback to CSV" -ForegroundColor Yellow
    $csvFile = Join-Path $OutputDir "驗測結果.csv"
    $csvContent = ($report | ConvertTo-Csv -NoTypeInformation) -join "`r`n"
    $bomBytes = [System.Text.Encoding]::UTF8.GetPreamble()
    $csvBytes = [System.Text.Encoding]::UTF8.GetBytes($csvContent)
    $allBytes = New-Object byte[] ($bomBytes.Length + $csvBytes.Length)
    [Array]::Copy($bomBytes, 0, $allBytes, 0, $bomBytes.Length)
    [Array]::Copy($csvBytes, 0, $allBytes, $bomBytes.Length, $csvBytes.Length)
    [System.IO.File]::WriteAllBytes($csvFile, $allBytes)
    Write-Host "CSV: $csvFile" -ForegroundColor Cyan
}

# Summary
Write-Host "`n========== RESULT SUMMARY ==========" -ForegroundColor White
$summaryLines = @("========== [$RunDate $BatchLabel] SUMMARY ==========")
foreach ($r in $report) {
    $line = "$($r.'行編') $($r.'姓名') >> $($r.'驗測結果')"
    Write-Host $line
    $summaryLines += $line
}
$summaryLines += "====================================="
$summaryLines | ForEach-Object { Add-Content -Path $LogFile -Value $_ -Encoding UTF8 }

Write-Host "===== [$RunDate $BatchLabel] DONE =====" -ForegroundColor Cyan
Add-Content -Path $LogFile -Value "===== [$RunDate $BatchLabel] DONE =====" -Encoding UTF8
